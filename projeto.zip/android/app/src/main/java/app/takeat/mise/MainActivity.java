package app.takeat.mise;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
