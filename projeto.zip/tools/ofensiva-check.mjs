// Ofensiva conta todos os dias do calendário (como no Duolingo), não só os dias úteis.
// Simula fins de semana com e sem estudo no engine.js e confere quebra, congelamento e soma.
// Uso: node tools/ofensiva-check.mjs
import { readFileSync } from 'fs';
import vm from 'vm';

const ctx = { window: {}, console };
vm.createContext(ctx);
vm.runInContext(readFileSync('public/legacy/engine.js', 'utf8'), ctx);
const E = ctx.window.MiseEngine;

// Semana de 19 a 25/10/2026 (seg a dom); 26/10 é segunda.
const dia = n => new Date(2026, 9, n);
// Estudou de segunda (19) a sexta (23); o congelamento da semana já foi dado.
const perfil = freezes => ({ takitos: 0, streak: { count: 5, last: '2026-10-23', freezes, grantWeek: '2026-10-19', days: ['2026-10-19', '2026-10-20', '2026-10-21', '2026-10-22', '2026-10-23'], best: 5 } });

let falhas = 0;
const confere = (nome, obtido, esperado) => {
  const ok = JSON.stringify(obtido) === JSON.stringify(esperado);
  if (!ok) falhas++;
  console.log((ok ? 'ok   ' : 'FALHOU') + ' ' + nome + (ok ? '' : ` (esperado ${JSON.stringify(esperado)}, veio ${JSON.stringify(obtido)})`));
};

// 1. Fim de semana sem estudo e sem congelamento: a ofensiva quebra.
let p = perfil(0);
confere('sábado, sem lição ainda: ofensiva segue em 5', E.streakNow(p, dia(24)), 5);
confere('domingo, sábado perdido: ofensiva zera', E.streakNow(p, dia(25)), 0);
confere('segunda, antes de estudar: ofensiva zerada', E.streakNow(p, dia(26)), 0);
let r = E.extendStreak(p, dia(26));
confere('segunda, estuda: recomeça em 1 (2 dias perdidos > 1 congelamento da semana)', [p.streak.count, r.used], [1, 0]);

// 2. Fim de semana sem estudo com 2 congelamentos: gasta os dois e mantém.
p = perfil(2);
confere('segunda, antes de estudar: ofensiva protegida', E.streakNow(p, dia(26)), 5);
r = E.extendStreak(p, dia(26));
confere('segunda, estuda: soma 1 e gasta 2 congelamentos', [p.streak.count, r.used, p.streak.freezes], [6, 2, 0]);

// 3. Só o sábado sem estudo, com 1 congelamento: gasta 1 no domingo.
p = perfil(1);
r = E.extendStreak(p, dia(25));
confere('domingo, estuda após sábado perdido: gasta 1 congelamento', [p.streak.count, r.used, p.streak.freezes], [6, 1, 0]);

// 4. Fim de semana com estudo: soma todos os dias e paga o marco de 7.
p = perfil(0);
const seq = [24, 25, 26].map(n => { const x = E.extendStreak(p, dia(n)); return [p.streak.count, x.used]; });
confere('sábado, domingo e segunda com estudo: 6, 7, 8 sem congelamento', seq, [[6, 0], [7, 0], [8, 0]]);
confere('marco de 7 dias cai no domingo: +20 Takitos', p.takitos, 20);

console.log(falhas ? `FALHOU (${falhas})` : 'OK: ofensiva conta todos os dias');
process.exit(falhas ? 1 : 0);
