// Com Novidades, módulo novo e lição encaixada, as fases que já existiam mantêm chave e perguntas.
import { readFileSync } from 'fs';
import vm from 'vm';
const carregar = c => { const ctx = { window: {}, console }; vm.createContext(ctx); vm.runInContext(c, ctx); return ctx.window; };
const L = f => readFileSync('public/legacy/' + f, 'utf8');
const w = carregar(L('config.js') + L('bank.js') + L('atendimento.js') + L('engine.js'));
const E = w.MiseEngine, C = w.MISE_CFG, p = { team: 'Suporte', leader: { disabled: {}, rules: {} } };
const fases = bank => E.flat((E._uc = {}, E.getUnits(C, bank, w.MISE_ATD, p, 'OPE'))).map(n => n.key + '|' + (n.qs || []).map(q => q.id).join(','));
const antes = fases(w.MISE_BANK);
const mk = (id, extra) => Object.assign({ id, trilha: 'Operação/PDV', unidade: 'Novidades do produto', licao: 'Teste', tipo: 'verdadeiro_falso', dificuldade: 2, enunciado: 'x', opcoes: ['Verdadeiro', 'Falso'], resposta: 'Falso', explicacao: '' }, extra);
const depois = fases(w.MISE_BANK.concat([mk('OPE-901', { novidade: true }), mk('OPE-902', { unidade: 'Pix na mesa', modulo_chave: 'OPE:pix-na-mesa' }), mk('OPE-903', { unidade: 'Caixa', extra_de: 'Caixa', licao: 'Sangria nova' })]));
const perdidas = antes.filter(f => !depois.includes(f));
console.log('fases antes', antes.length, '| depois', depois.length, '| perdidas', perdidas.length);
console.log(depois.filter(f => !antes.includes(f)).map(f => f.split('|')[0]).join('  '));
process.exit(perdidas.length ? 1 : 0);
