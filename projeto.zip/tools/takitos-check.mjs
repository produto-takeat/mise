// Teste dos Takitos ganhos na Mise: roda a lógica real (MiseLogic) e confere que cada ganho vai pro saldo do
// Hub com o MOTIVO na ref (missao/bau/bau-diario/marco/promocao), uma vez só, e que a senha não fica no app.
// O servidor simulado só registra e deduplica por ref; as regras e tetos do servidor real (mise_takitos)
// são testados contra o SQL da migration.
// Uso: node tools/takitos-check.mjs
import { build } from 'esbuild';
import { readFileSync } from 'node:fs';
import vm from 'node:vm';
import { fileURLToPath } from 'node:url';

const raiz = fileURLToPath(new URL('..', import.meta.url));

// ---------- servidor simulado ----------
const SRV = { saldo: 100, ledger: [], chamadas: 0, senha: null };
const hubMock = {
  movimentarTakitos: async (delta, ref) => {
    SRV.chamadas++;
    if (SRV.ledger.some(x => x.ref === ref)) return { ok: true, repetido: true, saldo: SRV.saldo };
    if (delta < 0 && SRV.saldo + delta < 0) return { ok: false, erro: 'saldo insuficiente', saldo: SRV.saldo };
    if (ref.startsWith('recusar')) return { ok: false, erro: 'limite diário de Takitos da Mise', saldo: SRV.saldo };
    SRV.saldo += delta; SRV.ledger.push({ delta, ref }); return { ok: true, saldo: SRV.saldo };
  },
  salvarNuvem: async r => { SRV.dados = r.dados; return true; },
  estadoNuvem: async () => ({ dados: null, saldo: SRV.saldo }), rankingSemana: async () => [], questoesNuvem: async () => [],
  erroSenha: s => (s.length >= 8 && /[a-z]/.test(s) && /[A-Z]/.test(s) && /\d/.test(s) && /[^A-Za-z0-9]/.test(s)) ? '' : 'A senha precisa ter: …',
  trocarSenha: async pwd => { SRV.senha = pwd; return { ok: true }; },
};

// ---------- ambiente de navegador mínimo ----------
const store = {};
const win = { localStorage: { getItem: k => store[k] ?? null, setItem: (k, v) => { store[k] = String(v); }, removeItem: k => { delete store[k]; } },
  navigator: { onLine: true }, location: { search: '', pathname: '/', hostname: 'localhost' }, addEventListener() {}, removeEventListener() {} };
win.window = win;
const ctx = vm.createContext(Object.assign(win, { console, setTimeout: () => 0, clearTimeout() {}, Date, Math, JSON, Promise, URLSearchParams }));
for (const f of ['public/legacy/config.js', 'public/legacy/engine.js']) vm.runInContext(readFileSync(raiz + f, 'utf8'), ctx);

const out = await build({
  entryPoints: [raiz + 'src/MiseLogic.js'], bundle: true, write: false, format: 'iife', globalName: 'MiseLogicMod', platform: 'neutral',
  define: { 'import.meta.env': '{"DEV":false}' },
  plugins: [{ name: 'mocks', setup(b) {
    b.onResolve({ filter: /^\.\/(hub|update)\.js$/ }, a => ({ path: a.path, namespace: 'mock' }));
    b.onResolve({ filter: /^react$/ }, () => ({ path: 'react', namespace: 'mock' }));
    b.onLoad({ filter: /.*/, namespace: 'mock' }, a => ({ contents: a.path === 'react' ? 'export default { createRef: () => ({ current: null }) };' : a.path.includes('hub') ? 'module.exports = globalThis.__hubMock;' : 'export const VERSION="t", BUILD=0; export const ehNativo=()=>false; export async function buscarAtualizacao(){return {}}; export function baixar(){}', loader: 'js' }));
  } }],
});
ctx.__hubMock = hubMock;
vm.runInContext(out.outputFiles[0].text, ctx);
const Logic = ctx.MiseLogicMod.default;

const L = new Logic({});
L.__host = { __setLogicState(u, cb) { const prev = L.state; L.state = { ...prev, ...(typeof u === 'function' ? u(prev) : u) }; cb && cb(); }, forceUpdate() {} };
const p = L.defaults();
Object.assign(p, { uid: 'u1', session: { email: 't@takeat.app' }, name: 'Teste', takitos: SRV.saldo });
L._p = p; L.state.p = p; L._tkReady = true; L._nuvemPronta = true;
L.agendarNuvem = () => {}; L.fly = () => {};

let falhas = 0;
const ok = (cond, msg) => { console.log((cond ? '  ok  ' : '  FALHOU ') + msg); if (!cond) falhas++; };
const fila = () => (L._p.tkFila || []).map(x => x.ref);
const hoje = L.tk();
const enviar = async () => { const c0 = SRV.chamadas; await L.enviarNuvem(); return SRV.chamadas - c0; };

console.log('Missões do dia');
const ms = L.E.missionsFor(L.C, hoje);
L.upd(q => { const dr = L.E.dayRec(q, hoje); dr.xp = 999; dr.maxCombo = 9; dr.reviews = 9; dr.lessons = 9; dr.perfect = 9; dr.whys = 9; L.checkMissions(q); });
ok(fila().length === 3 && fila().every(r => r.startsWith('missao:' + hoje + ':')), '3 missões viram 3 movimentos "missao:<dia>:<missão>"');
ok(ms.every(m => fila().includes('missao:' + hoje + ':' + m.k)) && L._p.tkFila.every(x => x.delta === 10), 'uma por missão, +10 cada');
L.upd(q => L.checkMissions(q));
ok(fila().length === 3, 'checar de novo não duplica');

console.log('Baús');
L.state.chest = { source: 'daily', reward: { k: 'takitos', n: 20 } }; L.collectChest();
ok(fila().includes('bau-diario:' + hoje) && L._p.tkFila.find(x => x.ref === 'bau-diario:' + hoje).delta === 20, 'baú diário: "bau-diario:<dia>" com o valor sorteado');
L.state.chest = { source: 'path', key: 'FUN:0:1', reward: { k: 'takitos', n: 30 } }; L.collectChest();
ok(fila().includes('bau:FUN:0:1'), 'baú do caminho: "bau:<fase>"');
L.state.chest = { source: 'path', key: 'FUN:1:1', reward: { k: 'freeze' } }; L.collectChest();
ok(fila().length === 5, 'baú sem Takitos não gera movimento');

console.log('Marco de ofensiva');
const ontem = new Date(L.today()); ontem.setDate(ontem.getDate() - 1);
L.upd(q => { q.streak = { count: 6, last: L.E.dkey(ontem), freezes: 0, grantWeek: L.E.dkey(L.E.monday(L.today())), days: [], best: 6 }; });
const tk0 = L._p.takitos;
L.upd(q => { const st = L.E.extendStreak(q, L.today()); L.marcoOfensiva(q, st); });
ok(fila().includes('marco:7:' + hoje) && L._p.tkFila.find(x => x.ref === 'marco:7:' + hoje).delta === 20, '7 dias: "marco:7:<dia>" com +20');
ok(L._p.takitos - tk0 === 20, 'o saldo do app sobe 20 uma vez só (não soma em dobro)');

console.log('Promoção de liga');
const segPassada = new Date(L.E.monday(L.today())); segPassada.setDate(segPassada.getDate() - 7);
L.C.REAL_RANK = [{ nome: 'A', xp: 5, idx: 0 }, { nome: 'B', xp: 3, idx: 0 }, { nome: 'C', xp: 1, idx: 0 }];
L.upd(q => { q.league = { idx: 0, week: L.E.dkey(segPassada), seed: 1, xp: 50 }; });
L._rankOk = true; L.endWeek();
const seg = L.E.dkey(L.E.monday(L.today()));
ok(L._p.league.idx === 1 && fila().includes('promocao:' + seg) && L._p.tkFila.find(x => x.ref === 'promocao:' + seg).delta === 30, 'subiu de liga: "promocao:<segunda>" com +30');

console.log('Envio pro Hub');
L.aplicarSaldo(SRV.saldo); // o app mostra o saldo do servidor antes de mandar a fila
const pend = L._p.tkFila.reduce((a, x) => a + x.delta, 0), saldo0 = SRV.saldo;
const n = await enviar();
ok(n === 7 && SRV.saldo === saldo0 + pend, 'fila de 7 ganhos sai inteira, cada um uma vez, mesmo com o saldo mudando no meio [' + n + ' envios]');
ok(!fila().length && L._p.takitos === SRV.saldo, 'fila vazia e saldo do app = saldo do Hub');
L.upd(q => { q.tkFila = [{ delta: 10, ref: 'missao:' + hoje + ':' + ms[0].k }]; });
await enviar();
ok(SRV.saldo === saldo0 + pend && !fila().length, 'reenviar o mesmo ganho não credita de novo');
L.upd(q => { q.tkFila = [{ delta: 10, ref: 'recusar:x' }, { delta: 20, ref: 'bau:FUN:2:1' }]; });
await enviar();
ok(!fila().length && SRV.ledger.some(x => x.ref === 'bau:FUN:2:1'), 'ganho recusado sai da fila e não trava os seguintes');
ok(L.state.toasts.some(t => /limite de Takitos/.test(t.text)), 'aviso de limite do dia');

console.log('Senha');
store['mise-v1'] = JSON.stringify(Object.assign(L.defaults(), { uid: 'u1', users: { 't@takeat.app': { pwd: 'Segredo#123' } } }));
const L2 = new Logic({}); L2.__host = L.__host; ctx.MISE_BANK = []; ctx.MISE_ATD = [];
ok(!('users' in L.defaults()), 'o estado novo não tem campo de senha');
L2.componentDidMount = Logic.prototype.componentDidMount; // roda a abertura real
try { L2.componentDidMount(); } catch (e) {}
ok(!/Segredo/.test(store['mise-v1'] || ''), 'senha antiga gravada no aparelho é apagada ao abrir');
ok(!/users/.test(JSON.stringify(SRV.dados || {})), 'progresso enviado à nuvem não leva campo de senha');
const pf = { name: 'Teste', phone: '', pwd: 'fraca', pwd2: 'fraca' };
await L.trocarSenha(pf);
ok(SRV.senha === null && L.state.toasts.some(t => /A senha precisa ter/.test(t.text)), 'senha fraca: regra do Hub, nada é trocado');
await L.trocarSenha({ ...pf, pwd: 'Forte#2026', pwd2: 'Forte#2026' });
ok(SRV.senha === 'Forte#2026', 'senha válida: troca na conta do Hub');
ok(!/Forte#2026/.test(JSON.stringify(L._p)) && !/Forte#2026/.test(store['mise-v1'] || ''), 'a senha nova não fica no app nem no aparelho');

console.log(falhas ? '\n' + falhas + ' falha(s)' : '\nTudo certo.');
process.exit(falhas ? 1 : 0);
