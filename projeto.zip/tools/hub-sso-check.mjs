// Mise aberta no domínio do TakeatHub (takeathub.vercel.app/mise/) com a sessão do Hub já no navegador:
// deve entrar direto (sem tela de login), usar a chave de sessão do Hub e esconder o "Sair".
// Serve o build (dist/) no endereço do Hub via interceptação; Supabase simulado. Rode `npm run build` antes.
import { chromium } from 'playwright-core';
import fs from 'node:fs';
import path from 'node:path';
const DIST = path.resolve('dist');
const UID = '22222222-2222-2222-2222-222222222222';
const tipos = { '.html': 'text/html', '.js': 'text/javascript', '.css': 'text/css', '.png': 'image/png', '.webp': 'image/webp', '.svg': 'image/svg+xml', '.json': 'application/json', '.webmanifest': 'application/manifest+json', '.woff2': 'font/woff2' };
const b = await chromium.launch({ channel: 'chrome' });
for (const [nome, vp, mobile] of [['celular', { width: 390, height: 844 }, true], ['pc', { width: 1280, height: 800 }, false]]) {
  const ctx = await b.newContext({ viewport: vp, hasTouch: mobile, isMobile: mobile, serviceWorkers: 'block' });
  await ctx.route('https://takeathub.vercel.app/mise/**', r => {
    let rel = new URL(r.request().url()).pathname.replace(/^\/mise\//, '') || 'index.html';
    const f = path.join(DIST, decodeURIComponent(rel));
    if (!fs.existsSync(f) || fs.statSync(f).isDirectory()) return r.fulfill({ status: 404, body: '' });
    r.fulfill({ status: 200, contentType: tipos[path.extname(f)] || 'application/octet-stream', body: fs.readFileSync(f) });
  });
  let salvo = null;
  await ctx.route('**/rest/v1/**', async route => {
    const u = route.request().url(), body = route.request().postDataJSON?.() || {};
    const j = d => route.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify(d) });
    if (u.includes('/profiles')) return j({ full_name: 'Bia Souza', team: 'Suporte', cargo: 'Analista', telefone: null, avatar_url: null, birth_date: null, force_password_change: false, onboarding_done: true, senha_temporaria_expira_em: null, moldura: null });
    if (u.includes('/user_roles')) return j([{ role: 'viewer' }]);
    if (u.includes('/documentos_time_membros')) return j([]);
    if (u.includes('rpc/mise_estado')) return j({ dados: { v: 1, uid: UID, onboarded: true, name: 'Bia Souza', xpTotal: 50, tourVisto: true, league: { idx: 0, week: null, seed: 1, xp: 10 } }, atualizado_em: new Date().toISOString(), saldo: 80 });
    if (u.includes('rpc/mise_salvar')) { salvo = body; return j({ ok: true }); }
    return j([]);
  });
  await ctx.addInitScript(([uid]) => {
    const exp = Math.floor(Date.now() / 1000) + 86400;
    // a sessão que o Hub grava (chave padrão do supabase-js do Hub)
    localStorage.setItem('sb-ggorwvqcqgzvcdzcmbov-auth-token', JSON.stringify({ access_token: 'x.y.z', refresh_token: 'r', expires_at: exp, expires_in: 86400, token_type: 'bearer', user: { id: uid, email: 'bia@takeat.app', user_metadata: {}, aud: 'authenticated', role: 'authenticated' } }));
  }, [UID]);
  const p = await ctx.newPage(); const errs = []; p.on('pageerror', e => errs.push(String(e)));
  await p.goto('https://takeathub.vercel.app/mise/'); await p.waitForTimeout(8000);
  const txt = await p.locator('body').innerText();
  const login = txt.includes('Acesse sua');
  const app = await p.locator('.ac-tabbar:visible, .ac-side:visible').count() > 0;
  const chaveMise = await p.evaluate(() => !!localStorage.getItem('mise-auth'));
  await p.locator('.ac-tabbar:visible, .ac-side:visible').getByText('Perfil', { exact: true }).click(); await p.waitForTimeout(800);
  await p.getByText('Configurações', { exact: true }).click().catch(() => {}); await p.waitForTimeout(800);
  const sair = await p.getByRole('button', { name: /^Sair$/ }).count();
  console.log(nome, '| entrou direto:', app && !login, '| tela de login:', login, '| usou chave própria (mise-auth):', chaveMise, '| botão Sair visível:', sair > 0, '| erros', errs);
  await p.screenshot({ path: `tools/sso-${nome}.png` });
  await ctx.close();
}
await b.close();
