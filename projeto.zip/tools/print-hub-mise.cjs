// Prints da página "Mise dentro do Hub" e do pop-up novo (página de teste local do Hub, porta 5214).
const { chromium } = require('playwright-core');
(async () => {
  const out = process.argv[2];
  const b = await chromium.launch({ channel: 'chrome' });
  for (const [nome, vp] of [['cel', { width: 390, height: 844 }], ['pc', { width: 1280, height: 800 }]]) {
    for (const v of ['pagina', 'popup']) {
      const p = await b.newPage({ viewport: vp, deviceScaleFactor: 1 });
      const errs = []; p.on('pageerror', e => errs.push(String(e)));
      await p.goto('http://localhost:5214/preview-mise.html?v=' + v, { waitUntil: 'load' });
      await p.waitForTimeout(v === 'popup' ? 4200 : 7000);
      await p.screenshot({ path: `${out}/${v}-${nome}.png` });
      console.log(v, nome, errs);
      await p.close();
    }
  }
  await b.close();
})();
