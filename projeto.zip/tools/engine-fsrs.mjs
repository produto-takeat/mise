// Testes do motor da Revisão do dia (src/fsrs.js). Uso: node tools/engine-fsrs.mjs
import { chance, responder, iniciarDeHl, revisaoDoDia, origemDe, enfileirar, lote, semEnviados, filaVazia } from '../src/fsrs.js';
let falhas = 0; const ok = (c, msg) => { console.log((c ? '  ok    ' : '  FALHOU ') + msg); if (!c) falhas++; };
const DIA = 864e5, T0 = Date.parse('2026-11-01T12:00:00Z');

// 1) resposta nova e chance
const r = responder(null, true, T0);
ok(r && r.cartao.s > 0 && r.cartao.v > T0 && r.chancePrevista === null && r.diasDesde === null, '1ª resposta cria cartão, sem chance prevista');
ok(Math.abs(chance(r.cartao, T0) - 1) < 1e-6, 'chance logo depois de responder = 100%');
const c1 = r.cartao;
ok(responder(c1, false, T0 + 3600e3) === null, 'segunda resposta no mesmo dia não conta');
const venc = c1.v;
ok(Math.abs(chance(c1, venc) - 0.9) < 0.05, `no vencimento a chance está perto de 90% (${chance(c1, venc).toFixed(3)})`);
const acertou = responder(c1, true, venc), errou = responder(c1, false, venc);
ok(acertou.cartao.v - venc > errou.cartao.v - venc, 'acertar empurra a revisão mais longe que errar');
ok(acertou.cartao.s > c1.s && errou.cartao.l === c1.l + 1, 'acerto aumenta a estabilidade; erro conta lapso');
ok(acertou.cartao.f === T0 && Math.abs(acertou.diasDesde - (venc - T0) / DIA) < 1e-9 && acertou.chancePrevista > 0.8, 'guarda 1ª resposta, dias desde a anterior e chance prevista');

// 2) quem vinha da meia-vida
const fs0 = iniciarDeHl({}, { A: { h: 2, t: T0 }, B: { h: 1, t: T0 - 10 * DIA } }, { B: true });
ok(fs0.A && fs0.B && fs0.A.s > fs0.B.s, 'meia-vida vira cartão (erro pendente = esqueci)');
ok(iniciarDeHl(fs0, { A: { h: 64, t: T0 + DIA } }, {}).A === fs0.A, 'não refaz cartão que já existe');

// 3) Revisão do dia
const fs = {}, controle = new Set();
for (let i = 0; i < 30; i++) { // 30 perguntas vistas há 20–49 dias; as ímpares são controle
  const id = 'Q' + i; fs[id] = responder(null, true, T0 - (20 + i) * DIA).cartao; if (i % 2) controle.add(id);
}
fs.HOJE = responder(null, true, T0).cartao;           // respondida hoje: fora
fs.NOVA = responder(null, true, T0 - 3 * DIA).cartao;  // vista há 3 dias: fora da checagem
const cfg = { retencao: 0.9, por_dia: 8, checagem: 2, checagem_dias: 14 };
let seq = 0; const rnd = () => ((seq = (seq * 9301 + 49297) % 233280) / 233280);
const rd = revisaoDoDia(fs, controle, T0, cfg, id => id !== 'Q0', rnd);
ok(rd.revisao.length === 8, `até 8 na revisão (${rd.revisao.length})`);
ok(rd.revisao.every(id => !controle.has(id)), 'nenhuma pergunta da metade controle na revisão');
ok(!rd.revisao.includes('Q0') && !rd.revisao.includes('HOJE'), 'pergunta que sumiu do banco e respondida hoje ficam fora');
const chs = rd.revisao.map(id => chance(fs[id], T0));
ok(chs.every((x, i) => i === 0 || x >= chs[i - 1]), 'menor chance de lembrar primeiro');
ok(rd.checagem.length === 2 && rd.checagem.filter(id => controle.has(id)).length === 1, 'checagem: 1 de cada metade');
ok(rd.checagem.every(id => !rd.revisao.includes(id) && id !== 'NOVA' && id !== 'HOJE'), 'checagem não repete a revisão nem pega pergunta recente');
const soControle = revisaoDoDia({ Q1: fs.Q1, Q3: fs.Q3 }, controle, T0, cfg, () => true, rnd);
ok(soControle.revisao.length === 0 && soControle.checagem.length === 0, 'sem par nas duas metades: sem checagem (não desequilibra)');
const emDia = revisaoDoDia({ X: responder(null, true, T0 - DIA).cartao }, new Set(), T0, cfg, () => true, rnd);
ok(emDia.revisao.length === 0, 'pergunta em dia não entra');

// 4) origem
ok(origemDe('review', false) === 'revisao' && origemDe('review', true) === 'checagem' && origemDe('licao') === 'licao' && origemDe('xyz') === 'outro', 'origem da resposta');

// 5) fila
let fila = enfileirar(null, { resposta: { id: 'r1' }, questaoId: 'A', cartao: fs0.A, sessao: { id: 's1', perguntas: 1 } });
fila = enfileirar(fila, { resposta: { id: 'r2' } });
const lt = lote(fila);
ok(lt.respostas.length === 2 && lt.cartoes[0].questao_id === 'A' && lt.cartoes[0].estabilidade === fs0.A.s && lt.sessoes.length === 1, 'lote monta respostas, cartões e sessões');
fila = enfileirar(fila, { sessao: { id: 's1', perguntas: 5 } }); // mudou depois do envio
const resto = semEnviados(fila, lt.tira, lt);
ok(resto.r.length === 0 && !resto.c.A && resto.s.s1 && resto.s.s1.perguntas === 5, 'tira o que foi enviado e mantém o que mudou depois');
ok(filaVazia({ r: [], c: {}, s: {} }) && !filaVazia(resto), 'fila vazia');

console.log(falhas ? `\n${falhas} falha(s)` : '\nTudo certo.');
process.exit(falhas ? 1 : 0);
