// Liga sem limite de vagas e separada por nível: cada liga mostra todo mundo daquele nível, e só ele.
// Uso: node tools/liga-check.mjs
import { readFileSync } from 'fs';
import vm from 'vm';

const ctx = { window: {}, console };
vm.createContext(ctx);
vm.runInContext(readFileSync('public/legacy/config.js', 'utf8') + readFileSync('public/legacy/engine.js', 'utf8'), ctx);
const E = ctx.window.MiseEngine, C = ctx.window.MISE_CFG;
const hoje = new Date(2026, 9, 21);
const eu = idx => ({ name: 'Eu', team: 'Suporte', equipped: null, league: { idx, seed: 1, xp: 100 } });

let falhas = 0;
const confere = (nome, obtido, esperado) => {
  const ok = JSON.stringify(obtido) === JSON.stringify(esperado);
  if (!ok) falhas++;
  console.log((ok ? 'ok   ' : 'FALHOU') + ' ' + nome + (ok ? '' : ` (esperado ${JSON.stringify(esperado)}, veio ${JSON.stringify(obtido)})`));
};

// Ranking real: 40 no Bronze, 3 na Prata, 1 no Mestre (idx ausente conta como Bronze).
C.REAL_RANK = [].concat(
  Array.from({ length: 39 }, (_, i) => ({ nome: 'Bronze ' + i, team: 'T', xp: i * 5, idx: 0 })),
  [{ nome: 'Bronze sem idx', team: 'T', xp: 10 }],
  Array.from({ length: 3 }, (_, i) => ({ nome: 'Prata ' + i, team: 'T', xp: 300 + i, idx: 1 })),
  [{ nome: 'Mestre', team: 'T', xp: 999, idx: 5 }]
);
const nomes = idx => E.leagueData(C, eu(idx), hoje).rows.filter(r => !r.me).map(r => r.nome.split(' ')[0]);

confere('Bronze: 40 colegas + você, sem limite de 20', E.leagueData(C, eu(0), hoje).rows.length, 41);
confere('Bronze não vê Prata nem Mestre', nomes(0).every(n => n === 'Bronze'), true);
confere('Prata vê só os 3 da Prata', nomes(1), ['Prata', 'Prata', 'Prata']);
confere('Prata: posição conta só a Prata (100 XP fica em 4º de 4)', E.leagueData(C, eu(1), hoje).rows.find(r => r.me).rank, 4);
confere('Ouro vazio: só você', E.leagueData(C, eu(2), hoje).rows.length, 1);

// Zonas proporcionais: [quantos sobem, quantos descem] conforme o tamanho da liga.
const liga = (n, comXp = n) => Array.from({ length: n }, (_, i) => ({ xp: i < comXp ? 100 - i : 0 }));
const zonas = (n, idx, comXp) => { const z = E.leagueZones(C, liga(n, comXp), idx); return [z.up, n - z.down]; };
confere('20 pessoas na Prata: 7 sobem, 4 descem', zonas(20, 1), [7, 4]);
confere('40 pessoas na Prata: 15 sobem, 9 descem', zonas(40, 1), [15, 9]);
confere('2 pessoas na Prata: ninguém sobe nem desce', zonas(2, 1), [0, 0]);
confere('3 pessoas na Prata: 1 sobe, ninguém desce', zonas(3, 1), [1, 0]);
confere('5 pessoas na Prata: 1 sobe, 1 desce', zonas(5, 1), [1, 1]);
confere('8 pessoas na Prata: 3 sobem, 1 desce', zonas(8, 1), [3, 1]);
confere('Bronze não rebaixa', zonas(40, 0), [15, 0]);
confere('Mestre não sobe', zonas(40, 5), [0, 9]);
confere('só sobe quem fez XP: 40 pessoas, 3 com XP', zonas(40, 1, 3), [3, 9]);

// Ranking simulado (sem login no Hub): todos os colegas fictícios, sem corte em 20.
delete C.REAL_RANK;
confere('simulado: todos os ' + C.PEOPLE.length + ' colegas + você', E.leagueData(C, eu(0), hoje).rows.length, C.PEOPLE.length + 1);

console.log(falhas ? `FALHOU (${falhas})` : 'OK: liga por nível e sem limite');
process.exit(falhas ? 1 : 0);
