// Prints do pop-up de novidade do Hub (página de teste local) em instantes exatos da animação.
// Uso: node tools/print-popup.cjs <pasta-saida>
const { chromium } = require('playwright-core');
(async () => {
  const out = process.argv[2];
  const b = await chromium.launch({ channel: 'chrome' });
  for (const [nome, vp] of [['cel', { width: 390, height: 844 }], ['pc', { width: 1366, height: 768 }]]) {
    const p = await b.newPage({ viewport: vp, deviceScaleFactor: 1 });
    const errs = []; p.on('pageerror', e => errs.push(String(e)));
    await p.goto('http://localhost:5214/preview-novidade.html', { waitUntil: 'networkidle' });
    await p.waitForTimeout(400);
    for (const t of [500, 1000, 1800, 2150, 2900, 3600]) {
      await p.evaluate((t) => { for (const a of document.getAnimations()) { a.pause(); a.currentTime = t; } }, t);
      await p.waitForTimeout(60);
      await p.screenshot({ path: `${out}/${nome}-${String(t).padStart(4, '0')}.png` });
    }
    console.log(nome, errs);
  }
  await b.close();
})();
