// Regressão do mapa de fases: com o mesmo banco de perguntas, o engine atual precisa gerar
// exatamente as mesmas fases (chave + perguntas) que o engine da versão anterior (git HEAD~).
// Garante que o progresso salvo das pessoas (p.done[chave]) continua valendo.
// Uso: node tools/engine-regressao.mjs <ref-git-do-engine-antigo>
import { readFileSync } from 'fs';
import { execSync } from 'child_process';
import vm from 'vm';

const ref = process.argv[2] || 'HEAD';
const carregar = (codigo, extra = {}) => { const ctx = { window: {}, console, ...extra }; vm.createContext(ctx); vm.runInContext(codigo, ctx); return ctx.window; };
const legado = f => readFileSync('public/legacy/' + f, 'utf8');
const w = carregar(legado('config.js') + legado('bank.js') + legado('atendimento.js'));
const novo = carregar(legado('engine.js')).MiseEngine;
const antigo = carregar(execSync(`git show ${ref}:public/legacy/engine.js`).toString()).MiseEngine;

const p = { team: 'Suporte', leader: { disabled: {}, rules: {} } };
let fases = 0, difs = 0;
for (const t of w.MISE_CFG.TRACKS.map(x => x.id).concat(['ATD'])) {
  const a = antigo.flat(antigo.getUnits(w.MISE_CFG, w.MISE_BANK, w.MISE_ATD, p, t)).map(n => n.key + '|' + (n.qs || []).map(q => q.id).join(','));
  const b = novo.flat(novo.getUnits(w.MISE_CFG, w.MISE_BANK, w.MISE_ATD, p, t)).map(n => n.key + '|' + (n.qs || []).map(q => q.id).join(','));
  fases += a.length;
  if (JSON.stringify(a) !== JSON.stringify(b)) { difs++; console.log('DIFERENTE:', t, a.length, b.length); }
}
console.log(difs ? `FALHOU (${difs} trilhas)` : `OK: ${fases} fases idênticas`);
process.exit(difs ? 1 : 0);
