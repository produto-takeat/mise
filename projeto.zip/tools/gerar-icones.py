# Gera todos os ícones do app (PWA, Android legado, adaptativo e redondo) a partir da arte do Mise.
# Uso: python tools/gerar-icones.py <arte-1024.(png|jpg)>
import os, sys
from PIL import Image, ImageDraw

ARTE = Image.open(sys.argv[1]).convert('RGB').resize((1024, 1024), Image.LANCZOS)
FUNDO = ARTE.getpixel((8, 8))  # creme da própria arte
RES = 'android/app/src/main/res'

def estendido(tam, escala):
    """Arte reduzida no centro; abaixo dela, a última linha (o livro) continua até a borda,
    para o recorte do sistema (círculo, gota, quadrado arredondado) não mostrar um corte reto."""
    c = Image.new('RGB', (tam, tam), FUNDO)
    s = int(tam * escala); x0 = (tam - s) // 2; y0 = (tam - s) // 2
    a = ARTE.resize((s, s), Image.LANCZOS)
    c.paste(a, (x0, y0))
    linha = a.crop((0, s - 1, s, s))
    for y in range(y0 + s, tam):
        c.paste(linha, (x0, y))
    return c

def redondo(img):
    t = img.width
    m = Image.new('L', (t * 4, t * 4), 0); ImageDraw.Draw(m).ellipse((0, 0, t * 4 - 1, t * 4 - 1), fill=255)
    out = img.convert('RGBA'); out.putalpha(m.resize((t, t), Image.LANCZOS)); return out

# PWA
os.makedirs('public/icons', exist_ok=True)
for t in (1024, 512, 192):
    ARTE.resize((t, t), Image.LANCZOS).save(f'public/icons/icon-{t}.png')
estendido(512, 0.80).save('public/icons/maskable-512.png')

# Android
dens = {'mdpi': 1, 'hdpi': 1.5, 'xhdpi': 2, 'xxhdpi': 3, 'xxxhdpi': 4}
for d, k in dens.items():
    pasta = f'{RES}/mipmap-{d}'
    leg = estendido(int(48 * k), 0.92)
    leg.save(f'{pasta}/ic_launcher.png')
    redondo(estendido(int(48 * k), 0.84)).save(f'{pasta}/ic_launcher_round.png')
    estendido(int(108 * k), 0.66).save(f'{pasta}/ic_launcher_foreground.png')

# Fundo do ícone adaptativo = o creme da arte
hexa = '#%02X%02X%02X' % FUNDO
with open(f'{RES}/values/ic_launcher_background.xml', 'w', encoding='utf-8') as f:
    f.write(f'<?xml version="1.0" encoding="utf-8"?>\n<resources>\n    <color name="ic_launcher_background">{hexa}</color>\n</resources>')

# iOS: o template do Capacitor 6 usa um único ícone 1024 sem transparência
os.makedirs('assets', exist_ok=True)
ARTE.save('assets/icon-ios-1024.png')
print('ok', hexa)
