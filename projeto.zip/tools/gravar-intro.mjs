// Grava a intro (quadros seguidos) para revisar e mostrar.
// Uso: node gravar.mjs <url> <pasta> <largura> <altura>
import { chromium } from 'playwright-core';
const [, , url = 'http://localhost:5181/?demo=splash', pasta = 'frames', w = '390', h = '700'] = process.argv;
const b = await chromium.launch({ channel: 'chrome' });
const p = await b.newPage({ viewport: { width: +w, height: +h }, deviceScaleFactor: 1 });
await p.goto(url, { waitUntil: 'load' });
const t0 = Date.now(); let i = 0; const tempos = [];
while (Date.now() - t0 < 4200) {
  tempos.push(Date.now() - t0);
  await p.screenshot({ path: `${pasta}/f${String(i++).padStart(3, '0')}.jpg`, quality: 80, type: 'jpeg' });
}
console.log('quadros', i, 'intervalo médio', Math.round((Date.now() - t0) / i), 'ms');
await b.close();
