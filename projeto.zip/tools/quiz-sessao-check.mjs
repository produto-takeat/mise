// Nivelamento obrigatório com o login perdido/vencido (Mise dentro do TakeatHub, sessão compartilhada).
// Antes: qualquer erro da RPC virava "Sem conexão com o servidor" e o quiz obrigatório ficava travado.
// Cenários (Supabase simulado; rode `npm run build` antes):
//   perdido  → a RPC recusa (sem permissão) e a renovação do login também → tela de entrar + "Seu login expirou"
//   renova   → a RPC recusa, a renovação funciona → repete a chamada e o quiz abre
//   rede     → a RPC não responde (rede) → continua em "Sem conexão com o servidor" (sem sair)
import { chromium } from 'playwright-core';
import fs from 'node:fs';
import path from 'node:path';
const DIST = path.resolve('dist');
const UID = '22222222-2222-2222-2222-222222222222';
const USER = { id: UID, email: 'bia@takeat.app', user_metadata: {}, aud: 'authenticated', role: 'authenticated' };
const tipos = { '.html': 'text/html', '.js': 'text/javascript', '.css': 'text/css', '.png': 'image/png', '.webp': 'image/webp', '.svg': 'image/svg+xml', '.json': 'application/json', '.webmanifest': 'application/manifest+json', '.woff2': 'font/woff2' };
const PAYLOAD = { ok: true, reaberta: false, tentativa_id: '33333333-3333-3333-3333-333333333333', modo: 'nivelamento', alvo: 'iniciante', servidor_em: new Date().toISOString(), prazo: new Date(Date.now() + 900e3).toISOString(),
  perguntas: [{ id: 'q1', tipo: 'multipla_escolha', enunciado: 'Pergunta de teste do nivelamento?', opcoes: ['Alternativa A', 'Alternativa B'], trilha_id: 'FUN', unidade: 'Primeiros passos', pula_modulo: false, respondida: false }] };

const b = await chromium.launch({ channel: 'chrome' });
let falhas = 0;
for (const cenario of ['perdido', 'renova', 'rede']) {
  const ctx = await b.newContext({ viewport: { width: 1280, height: 800 }, serviceWorkers: 'block' });
  await ctx.route('https://takeathub.vercel.app/mise/**', r => {
    const rel = new URL(r.request().url()).pathname.replace(/^\/mise\//, '') || 'index.html';
    const f = path.join(DIST, decodeURIComponent(rel));
    if (!fs.existsSync(f) || fs.statSync(f).isDirectory()) return r.fulfill({ status: 404, body: '' });
    r.fulfill({ status: 200, contentType: tipos[path.extname(f)] || 'application/octet-stream', body: fs.readFileSync(f) });
  });
  let iniciar = 0, renovou = 0;
  await ctx.route('**/auth/v1/**', route => {
    const u = route.request().url();
    if (u.includes('grant_type=refresh_token')) {
      renovou++;
      if (cenario === 'renova') {
        const exp = Math.floor(Date.now() / 1000) + 3600;
        return route.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify({ access_token: 'n.o.vo', refresh_token: 'r2', expires_in: 3600, expires_at: exp, token_type: 'bearer', user: USER }) });
      }
      return route.fulfill({ status: 400, contentType: 'application/json', body: JSON.stringify({ code: 400, error_code: 'refresh_token_not_found', msg: 'Invalid Refresh Token: Refresh Token Not Found' }) });
    }
    if (u.includes('/logout')) return route.fulfill({ status: 204, body: '' });
    return route.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify(USER) });
  });
  await ctx.route('**/rest/v1/**', async route => {
    const u = route.request().url();
    const j = (d, s = 200) => route.fulfill({ status: s, contentType: 'application/json', body: JSON.stringify(d) });
    if (u.includes('/profiles')) return j({ full_name: 'Bia Souza', team: 'Suporte', cargo: 'Analista', telefone: null, avatar_url: null, birth_date: null, force_password_change: false, onboarding_done: true, senha_temporaria_expira_em: null, moldura: null });
    if (u.includes('/user_roles')) return j([{ role: 'viewer' }]);
    if (u.includes('/documentos_time_membros')) return j([]);
    if (u.includes('rpc/mise_estado')) return j({ dados: { v: 1, uid: UID, onboarded: true, name: 'Bia Souza', xpTotal: 0, tourVisto: true, league: { idx: 0, week: null, seed: 1, xp: 0 } }, atualizado_em: new Date().toISOString(), saldo: 0 });
    if (u.includes('rpc/mise_nivelamento_status')) return j({ ativo: true, mestre_servidor: false, obrigatorio: true, vezes: 0, modulos: [], certificados: [], config: {} });
    if (u.includes('rpc/mise_avaliacao_iniciar')) {
      iniciar++;
      if (cenario === 'rede') return route.abort('failed');
      if (cenario === 'renova' && iniciar > 1) return j(PAYLOAD);
      return j({ code: '42501', details: null, hint: null, message: 'permission denied for function mise_avaliacao_iniciar' }, 401);
    }
    return j([]);
  });
  await ctx.addInitScript(([user]) => {
    const exp = Math.floor(Date.now() / 1000) + 86400;
    localStorage.setItem('sb-ggorwvqcqgzvcdzcmbov-auth-token', JSON.stringify({ access_token: 'x.y.z', refresh_token: 'r', expires_at: exp, expires_in: 86400, token_type: 'bearer', user }));
  }, [USER]);
  const p = await ctx.newPage(); const errs = []; p.on('pageerror', e => errs.push(String(e)));
  await p.goto('https://takeathub.vercel.app/mise/'); await p.waitForTimeout(7000);
  const noQuiz = (await p.locator('body').innerText()).includes('Qual é o seu nível com a Takeat?');
  await p.getByText('Iniciante', { exact: false }).first().click(); await p.waitForTimeout(300);
  await p.getByRole('button', { name: /Começar o quiz/ }).click();
  // o aviso (toast) some sozinho: junta o que aparecer na tela nos 3 s seguintes
  let txt = '';
  for (let i = 0; i < 15; i++) { await p.waitForTimeout(200); txt += ' | ' + await p.locator('body').innerText(); }
  const fim = await p.locator('body').innerText();
  const login = fim.includes('Acesse sua');
  const sessaoNoStorage = await p.evaluate(() => !!localStorage.getItem('sb-ggorwvqcqgzvcdzcmbov-auth-token'));
  const r = {
    perdido: { ok: login && txt.includes('Seu login expirou') && !sessaoNoStorage && !txt.includes('Sem conexão'), visto: { login, avisoLogin: txt.includes('Seu login expirou'), sessaoNoStorage } },
    renova: { ok: renovou === 1 && iniciar === 2 && fim.includes('Pergunta de teste do nivelamento?'), visto: { renovou, iniciar, abriuQuiz: fim.includes('Pergunta de teste do nivelamento?') } },
    rede: { ok: !login && txt.includes('Sem conexão com o servidor') && renovou === 0 && sessaoNoStorage, visto: { login, semConexao: txt.includes('Sem conexão com o servidor'), renovou, sessaoNoStorage } },
  }[cenario];
  if (!noQuiz || !r.ok || errs.length) falhas++;
  console.log(cenario.padEnd(8), r.ok && noQuiz && !errs.length ? 'OK  ' : 'FALHA', '| abriu o nivelamento obrigatório:', noQuiz, '|', JSON.stringify(r.visto), errs.length ? '| erros ' + errs : '');
  await p.screenshot({ path: `tools/quiz-sessao-${cenario}.png` });
  await ctx.close();
}
await b.close();
process.exit(falhas ? 1 : 0);
