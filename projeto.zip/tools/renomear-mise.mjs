// Renomeia o app de "Academy" para "Mise" (nomes, referências, globais, banco, storage, appId).
// Uso: node tools/renomear-mise.mjs <arquivo> [<arquivo>...]
import { readFileSync, writeFileSync } from 'fs';

const TROCAS = [
  // banco e storage (tabelas/funções renomeadas na migration 20261012220000_mise_renomear.sql do Hub)
  ['academy_questoes', 'mise_questoes'], ['academy_feedback', 'mise_feedback'], ['academy-feedback', 'mise-feedback'],
  ['academy_progresso', 'mise_progresso'], ['academy_nuvem', 'mise_nuvem'], ['academy_estado', 'mise_estado'], ['academy_salvar', 'mise_salvar'],
  ['academy_takitos', 'mise_takitos'], ['academy_ranking', 'mise_ranking'],
  // identidade do app
  ['app.takeat.academy', 'app.takeat.mise'], ['app/takeat/academy', 'app/takeat/mise'], ['JwellsL/takeat-academy', 'produto-takeat/mise'],
  ['jwellsl.github.io/takeat-academy', 'produto-takeat.github.io/mise'], ['academy.keystore', 'mise.keystore'], ['ACADEMY_KEYSTORE', 'MISE_KEYSTORE'],
  ['signingConfigs.academy', 'signingConfigs.mise'], ['keyAlias "academy"', 'keyAlias "mise"'], ['        academy {', '        mise {'],
  // armazenamento no aparelho / cache
  ['takeat-academy-questoes-v1', 'mise-questoes-v1'], ['takeat-academy-feedback-v1', 'mise-feedback-v1'], ['takeat-academy-auth', 'mise-auth'],
  ['takeat-academy-v0', 'mise-v1'], ["'academy-v1'", "'mise-v1'"],
  // globais e arquivos
  ['ACADEMY_BANK', 'MISE_BANK'], ['ACADEMY_ATD', 'MISE_ATD'], ['ACADEMY_CFG', 'MISE_CFG'], ['ACADEMY_IMG', 'MISE_IMG'],
  ['AcademyEngine', 'MiseEngine'], ['AcademyHub', 'MiseHub'], ['AcademyFeedback', 'MiseFeedback'], ['AcademyLogic', 'MiseLogic'],
  ['academy-img', 'mise-img'], ['academy-book', 'mise-book'],
  ['"name": "takeat-academy"', '"name": "mise"'], ['takeat-academy-src', 'mise-src'], ['takeat-academy', 'mise'],
  // textos
  ['TakeatHub Academy', 'Mise'], ['Takeat Academy', 'Mise'], ['Academy', 'Mise'],
];

for (const f of process.argv.slice(2)) {
  let s = readFileSync(f, 'utf8');
  for (const [de, para] of TROCAS) s = s.split(de).join(para);
  writeFileSync(f, s);
}
console.log('ok', process.argv.length - 2);
