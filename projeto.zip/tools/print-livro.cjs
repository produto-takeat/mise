// Prints da abertura do livro (intro do app) em instantes exatos. Uso: node tools/print-livro.cjs <pasta> [prefixo]
const { chromium } = require('playwright-core');
(async () => {
  const [out, pre = 'l'] = process.argv.slice(2);
  const b = await chromium.launch({ channel: 'chrome' });
  const p = await b.newPage({ viewport: { width: 390, height: 844 }, deviceScaleFactor: 1 });
  await p.goto('http://localhost:5181/?demo=splash&v=' + Date.now(), { waitUntil: 'load' });
  await p.waitForSelector('.mi-livro'); await p.waitForTimeout(500);
  for (const t of [150, 350, 500, 650, 800, 950, 1100, 1300]) {
    await p.evaluate((t) => { for (const a of document.getAnimations()) { a.pause(); a.currentTime = t; } }, t);
    await p.waitForTimeout(60);
    await p.screenshot({ path: `${out}/${pre}${String(t).padStart(4, '0')}.png`, clip: { x: 0, y: 540, width: 390, height: 304 } });
  }
  await b.close();
})();
