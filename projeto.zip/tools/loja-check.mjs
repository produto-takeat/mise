// Teste da Loja: roda a lógica real (MiseLogic) contra um servidor simulado com as mesmas regras das
// RPCs do Hub (loja_visivel, comprar_item, equipar_moldura, resgatar_codigo, mise_takitos).
// Uso: node tools/loja-check.mjs
import { build } from 'esbuild';
import { readFileSync } from 'node:fs';
import vm from 'node:vm';
import { fileURLToPath } from 'node:url';

const raiz = fileURLToPath(new URL('..', import.meta.url));

// ---------- servidor simulado ----------
const SRV = {
  saldo: 150, possui: [], equipada: null, ledger: [],
  itens: [
    { id: 'u-bronze', tipo: 'moldura', asset: 'metal:bronze', nome: 'Bronze', raridade: 'comum', preco: 0 },
    { id: 'u-prata', tipo: 'moldura', asset: 'metal:prata', nome: 'Prata', raridade: 'comum', preco: 80 },
    { id: 'u-dragao', tipo: 'moldura', asset: 'rpg:dragao', nome: 'Dragão', raridade: 'lendario', preco: 900 },
    { id: 'u-talheres', tipo: 'moldura', asset: 'gastro:talheres', nome: 'Talheres de Ouro', raridade: 'lendario', preco: 0, somente_codigo: true, oculto_na_loja: true },
    { id: 'u-marca', tipo: 'moldura', asset: 'takeat:marca', nome: 'Marca Takeat', raridade: 'lendario', preco: 0, somente_codigo: true },
  ],
  codigos: { TALHERESDEOURO: 'u-talheres' }, usados: {},
};
const hubMock = {
  lojaNuvem: async () => ({ itens: SRV.itens.map(i => ({ ...i })), possui: SRV.possui.slice(), equipada: SRV.equipada }),
  comprarItem: async id => {
    const i = SRV.itens.find(x => x.id === id);
    if (!i) return { ok: false, erro: 'item invalido' };
    if (i.somente_codigo) return { ok: false, erro: 'Esta moldura só pode ser obtida por código de resgate.' };
    if (SRV.possui.includes(id)) return { ok: false, erro: 'ja possui' };
    if (SRV.saldo < i.preco) return { ok: false, erro: 'saldo insuficiente', saldo: SRV.saldo };
    SRV.saldo -= i.preco; SRV.ledger.push(['compra', -i.preco]); SRV.possui.push(id);
    return { ok: true, saldo: SRV.saldo };
  },
  equiparMoldura: async id => { if (id && !SRV.possui.includes(id)) return { ok: false, erro: 'Não foi possível aplicar a moldura agora.' }; SRV.equipada = id; return { ok: true }; },
  resgatarCodigo: async c => {
    const id = SRV.codigos[String(c).trim().toUpperCase()];
    if (!id) return { ok: false, erro: 'Código inválido.' };
    if (SRV.usados[c]) return { ok: false, erro: 'Você já resgatou este código.' };
    SRV.usados[c] = 1; if (!SRV.possui.includes(id)) SRV.possui.push(id);
    return { ok: true, item: SRV.itens.find(x => x.id === id).nome };
  },
  movimentarTakitos: async (delta, ref) => {
    if (delta < 0 && SRV.saldo + delta < 0) return { ok: false, erro: 'saldo insuficiente', saldo: SRV.saldo };
    SRV.saldo += delta; SRV.ledger.push(['ajuste', delta, ref]); return { ok: true, saldo: SRV.saldo };
  },
  estadoNuvem: async () => ({ dados: null, saldo: SRV.saldo }), salvarNuvem: async () => true, rankingSemana: async () => [], questoesNuvem: async () => [],
};

// ---------- ambiente de navegador mínimo ----------
const store = {};
const win = { localStorage: { getItem: k => store[k] ?? null, setItem: (k, v) => { store[k] = String(v); }, removeItem: k => { delete store[k]; } },
  navigator: { onLine: true }, location: { search: '', pathname: '/', hostname: 'localhost' }, addEventListener() {}, removeEventListener() {} };
win.window = win;
const ctx = vm.createContext(Object.assign(win, { console, setTimeout: () => 0, clearTimeout() {}, Date, Math, JSON, Promise, URLSearchParams }));
for (const f of ['public/legacy/config.js', 'public/legacy/engine.js']) vm.runInContext(readFileSync(raiz + f, 'utf8'), ctx);

const out = await build({
  entryPoints: [raiz + 'src/MiseLogic.js'], bundle: true, write: false, format: 'iife', globalName: 'MiseLogicMod', platform: 'neutral',
  define: { 'import.meta.env': '{"DEV":false}' },
  plugins: [{ name: 'mocks', setup(b) {
    b.onResolve({ filter: /^\.\/(hub|update)\.js$/ }, a => ({ path: a.path, namespace: 'mock' }));
    b.onResolve({ filter: /^react$/ }, () => ({ path: 'react', namespace: 'mock' }));
    b.onLoad({ filter: /.*/, namespace: 'mock' }, a => ({ contents: a.path === 'react' ? 'export default { createRef: () => ({ current: null }) };' : a.path.includes('hub') ? 'module.exports = globalThis.__hubMock;' : 'export const VERSION="t", BUILD=0; export const ehNativo=()=>false; export async function buscarAtualizacao(){return {}}; export function baixar(){}', loader: 'js' }));
  } }],
});
ctx.__hubMock = hubMock;
vm.runInContext(out.outputFiles[0].text, ctx);
const Logic = ctx.MiseLogicMod.default;

// Host síncrono (mesmo contrato do App.jsx).
const L = new Logic({});
L.__host = { __setLogicState(u, cb) { const prev = L.state; L.state = { ...prev, ...(typeof u === 'function' ? u(prev) : u) }; cb && cb(); }, forceUpdate() {} };
const p = L.defaults();
Object.assign(p, { uid: 'u1', session: { email: 't@takeat.app' }, name: 'Teste', takitos: SRV.saldo });
L._p = p; L.state.p = p; L._tkBase = SRV.saldo; L._tkReady = true; L._nuvemPronta = true;
L.agendarNuvem = () => {};

let falhas = 0;
const ok = (cond, msg) => { console.log((cond ? '  ok  ' : '  FALHOU ') + msg); if (!cond) falhas++; };
const espera = () => new Promise(r => setImmediate(r));
const loja = () => L.vLoja();
const toasts = () => L.state.toasts.map(t => t.text).join(' | ');
const card = nome => loja().lojaItems.find(i => i.nome === nome);
L.state.sub = 'loja';

console.log('Abas');
let v = loja();
ok(v.lojaTabs.map(t => t.t + (t.soon ? '*' : '')).join(',') === 'Molduras,Fundos*,Ícones*,Itens', 'Fundos e Ícones marcados como "Em breve"');
ok(v.lojaEmpty && /Carregando/.test(v.lojaEmptyMsg), 'mostra "Carregando" antes do catálogo chegar');
await espera(); await espera();
v = loja();
ok(v.lojaItems.length === 4, 'catálogo real: 4 molduras (a oculta só aparece para quem tem)');
ok(!card('Talheres de Ouro'), 'moldura oculta não aparece');
ok(card('Marca Takeat').btn === 'Só por código' && card('Marca Takeat').dis, 'moldura só por código fica travada');
ok(card('Dragão').btn === 'Takitos insuficientes' && card('Dragão').dis, 'sem saldo: botão desabilitado');

console.log('Comprar moldura paga');
card('Prata').onClick();
ok(L.state.buy === 'u-prata', 'abre a confirmação da compra');
ok(L.vBuy().bConfirmLabel === 'Confirmar compra', 'rótulo do botão de confirmar');
L.vBuy().onBuyConfirm(); await espera(); await espera(); await espera();
ok(SRV.possui.includes('u-prata') && SRV.saldo === 70, 'servidor: posse gravada e 80 Takitos debitados');
ok(SRV.equipada === 'u-prata' && L._p.equipped === 'metal:prata', 'moldura aplicada no perfil do Hub e no app');
ok(L._p.takitos === 70 && !(L._p.tkFila || []).length, 'saldo do app = saldo do Hub, sem movimento duplicado na fila');
ok(card('Prata').btn === 'Em uso · tirar', 'card mostra "Em uso"');
ok(L.state.buy === null, 'confirmação fechada');

console.log('Pegar grátis + equipar/tirar');
card('Bronze').onClick(); ok(L.vBuy().bConfirmLabel === 'Pegar grátis', 'grátis abre confirmação "Pegar grátis"');
L.vBuy().onBuyConfirm(); await espera(); await espera(); await espera();
ok(SRV.possui.includes('u-bronze') && SRV.saldo === 70 && SRV.equipada === 'u-bronze', 'grátis entra na coleção sem débito e é aplicada');
card('Prata').onClick(); await espera(); await espera();
ok(SRV.equipada === 'u-prata' && L._p.equipped === 'metal:prata', 'Equipar troca a moldura no Hub');
card('Prata').onClick(); await espera(); await espera();
ok(SRV.equipada === null && L._p.equipped === null, '"Em uso · tirar" remove a moldura do perfil');

console.log('Resgate de código');
L.setState({ sub: 'resgate', resg: { code: 'ERRADO', item: null, err: '' } });
await L.vResgate().onRsCheck();
ok(L.state.resg.err === 'Código inválido.', 'código inválido mostra o erro do servidor');
L.setState({ resg: { code: 'TALHERESDEOURO', item: null, err: '' } });
await L.vResgate().onRsCheck();
ok(SRV.possui.includes('u-talheres') && L.state.resg.item && L.state.resg.item.nome === 'Talheres de Ouro', 'resgate grava a posse e mostra o prêmio');
ok(L.vResgate().rsConfirmLabel === 'Aplicar no perfil', 'botão "Aplicar no perfil"');
await L.vResgate().onRsConfirm();
ok(SRV.equipada === 'u-talheres' && L.state.sub === 'loja', 'aplica a moldura resgatada e volta para a loja');
ok(!!card('Talheres de Ouro'), 'moldura oculta aparece depois de resgatada');
L.setState({ sub: 'resgate', resg: { code: 'TALHERESDEOURO', item: null, err: '' } });
await L.vResgate().onRsCheck();
ok(/já resgatou/.test(L.state.resg.err), 'segundo resgate do mesmo código é recusado');
L.setState({ sub: 'loja' });

console.log('Itens do app');
L.setState({ loja: { ...L.state.loja, tab: 'item' } });
const fr0 = L._p.streak.freezes;
card('Congelamento de ofensiva').onClick(); L.vBuy().onBuyConfirm(); await espera(); await espera(); await espera();
ok(SRV.saldo === 30 && L._p.takitos === 30, 'congelamento debitado no saldo do Hub (40)');
ok(L._p.streak.freezes === Math.min(2, fr0 + 1), 'congelamento entregue');
ok(card('Congelamento de ofensiva').btn === 'Você já tem 2' && card('Congelamento de ofensiva').dis, 'com 2 congelamentos o item trava');
const xp = card('XP em dobro · 15 min'); ok(xp.btn === 'Takitos insuficientes', 'XP em dobro sem saldo (60 > 30) fica travado');
SRV.saldo = 200; L.aplicarSaldo(200);
card('XP em dobro · 15 min').onClick(); L.vBuy().onBuyConfirm(); await espera(); await espera(); await espera();
const b1 = L._p.boostUntil; ok(SRV.saldo === 140 && b1 > Date.now() + 14 * 60000, 'XP em dobro debitado e ativo por 15 min');
card('XP em dobro · 15 min').onClick(); L.vBuy().onBuyConfirm(); await espera(); await espera(); await espera();
ok(L._p.boostUntil - b1 >= 15 * 60000 - 50, 'segunda compra soma +15 min (não zera o que restava)');
// servidor recusa: nada é entregue
SRV.saldo = 10; const fr1 = L._p.boostUntil; L._p.takitos = 999; L._tkBase = 999;
card('XP em dobro · 15 min').onClick(); L.vBuy().onBuyConfirm(); await espera(); await espera(); await espera();
ok(L._p.boostUntil === fr1 && L._p.takitos === 10, 'servidor sem saldo: item não é entregue e o saldo volta ao do Hub');
ok(/insuficientes/.test(toasts()), 'aviso de Takitos insuficientes');

console.log('Abas em breve');
L.setState({ loja: { ...L.state.loja, tab: 'fundo' } });
v = loja(); ok(v.lojaSoon && !v.lojaNotSoon && !v.lojaItems.length && !v.lojaEmpty && /Fundos/.test(v.lojaSoonTitle), 'Fundos mostra o aviso "em breve" sem itens');
L.setState({ loja: { ...L.state.loja, tab: 'icone' } });
v = loja(); ok(v.lojaSoon && /Ícones/.test(v.lojaSoonTitle), 'Ícones mostra o aviso "em breve"');

console.log(falhas ? '\n' + falhas + ' falha(s)' : '\nTudo certo.');
process.exit(falhas ? 1 : 0);
