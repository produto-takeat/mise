// Tutorial guiado: abre sozinho pra pessoa nova (sem progresso na nuvem), percorre os passos,
// grava "tourVisto" na nuvem e NÃO abre pra quem já tem progresso. Prints em tools/tour-*.png.
import { chromium } from 'playwright-core';
const UID = '11111111-1111-1111-1111-111111111111';
async function rodar(nome, viewport, nuvem, mobile) {
  let salvo = nuvem;
  const b = await chromium.launch({ channel: 'chrome' });
  const ctx = await b.newContext({ viewport, hasTouch: !!mobile, isMobile: !!mobile });
  await ctx.addInitScript(([uid]) => {
    const exp = Math.floor(Date.now() / 1000) + 86400;
    localStorage.setItem('mise-auth', JSON.stringify({ access_token: 'x.y.z', refresh_token: 'r', expires_at: exp, expires_in: 86400, token_type: 'bearer', user: { id: uid, email: 'ana@takeat.app', user_metadata: {}, aud: 'authenticated', role: 'authenticated' } }));
    if (!localStorage.getItem('mise-v1')) localStorage.setItem('mise-v1', JSON.stringify({ v: 1, session: { email: 'ana@takeat.app' }, uid, onboarded: true, name: 'Ana', team: 'Suporte' }));
  }, [UID]);
  await ctx.route('**/rest/v1/**', async route => {
    const u = route.request().url(), body = route.request().postDataJSON?.() || {};
    const j = d => route.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify(d) });
    if (u.includes('/profiles')) return j({ full_name: 'Ana Prado', team: 'Suporte', cargo: 'Analista', telefone: null, avatar_url: null, moldura: null });
    if (u.includes('rpc/mise_estado')) return j({ dados: salvo, atualizado_em: new Date(Date.now() - 86400000).toISOString(), saldo: 120 });
    if (u.includes('rpc/mise_salvar')) { salvo = body.p_dados; return j({ ok: true }); }
    if (u.includes('rpc/mise_ranking')) return j([]);
    return j([]);
  });
  const p = await ctx.newPage(); const errs = []; p.on('pageerror', e => errs.push(String(e)));
  await p.goto('http://localhost:5181/'); await p.waitForTimeout(7000);
  const aberto = await p.locator('[aria-label^="Tutorial:"]').count() > 0;
  const titulos = [];
  if (aberto) {
    for (let i = 0; i < 5; i++) {
      const t = await p.locator('[aria-label^="Tutorial:"]').getAttribute('aria-label');
      titulos.push(t.replace('Tutorial: ', ''));
      await p.waitForTimeout(500);
      if ([0, 1, 2, 3].includes(i)) await p.screenshot({ path: `tools/tour-${nome}-${i}.png` });
      const prox = p.getByRole('button', { name: i === 4 ? 'Explorar sozinho' : 'Próximo' });
      await prox.click(); await p.waitForTimeout(250);
    }
    await p.waitForTimeout(2000);
  }
  console.log(nome, '| abriu sozinho:', aberto, '| passos:', titulos.join(' > '), '| fechou:', await p.locator('[aria-label^="Tutorial:"]').count() === 0, '| tourVisto na nuvem:', !!(salvo && salvo.tourVisto), '| erros', errs);
  await b.close();
}
await rodar('celular', { width: 390, height: 844 }, null, true);
await rodar('pc', { width: 1366, height: 768 }, null, false);
await rodar('veterano', { width: 390, height: 844 }, { v: 1, uid: UID, onboarded: true, name: 'Ana', xpTotal: 300, done: { 'FUN:0:0': 1 }, league: { idx: 0, week: null, seed: 1, xp: 40 } }, true);
