// Mínimo de perguntas por lição (E.MIN_LICAO) sem mexer no progresso:
//  1. as CHAVES das fases são as mesmas do engine anterior (git <ref>) — p.done[chave] continua valendo;
//  2. toda lição tem >= MIN_LICAO perguntas próprias quando a unidade tem perguntas suficientes;
//  3. as unidades curtas são exatamente as que E.faltam aponta (o mise-auto completa essas).
// Uso: node tools/engine-minimo.mjs [ref-git-do-engine-antigo]
import { readFileSync } from 'fs';
import { execSync } from 'child_process';
import vm from 'vm';

const ref = process.argv[2] || 'HEAD';
const carregar = codigo => { const ctx = { window: {}, console }; vm.createContext(ctx); vm.runInContext(codigo, ctx); return ctx.window; };
const legado = f => readFileSync('public/legacy/' + f, 'utf8');
const w = carregar(legado('config.js') + legado('bank.js') + legado('atendimento.js'));
const novo = carregar(legado('engine.js')).MiseEngine;
const antigo = carregar(execSync(`git show ${ref}:public/legacy/engine.js`).toString()).MiseEngine;
const p = { team: 'Suporte', leader: { disabled: {}, rules: {} } };
const MIN = novo.MIN_LICAO;

let falhas = 0, licoes = 0, curtas = 0, faltamTotal = 0;
for (const t of w.MISE_CFG.TRACKS.map(x => x.id).concat(['ATD'])) {
  const a = antigo.flat(antigo.getUnits(w.MISE_CFG, w.MISE_BANK, w.MISE_ATD, p, t)).map(n => n.key);
  const units = novo.getUnits(w.MISE_CFG, w.MISE_BANK, w.MISE_ATD, p, t);
  const b = novo.flat(units).map(n => n.key);
  if (JSON.stringify(a) !== JSON.stringify(b)) { falhas++; console.log('CHAVES MUDARAM:', t, a.length, '→', b.length); }
  // 4. toda pergunta da trilha está em pelo menos uma lição (nenhuma fica de fora do app).
  const banco = t === 'ATD' ? w.MISE_ATD : w.MISE_BANK.filter(q => (q.trilha_id || q.id.slice(0, 3)) === t);
  const nasLicoes = new Set(novo.flat(units).filter(n => n.type === 'licao').flatMap(n => n.qs.map(q => q.id)));
  const fora = banco.filter(q => !nasLicoes.has(q.id));
  if (fora.length) { falhas++; console.log('PERGUNTAS FORA DE QUALQUER LIÇÃO:', t, fora.map(q => q.id).join(' ')); }
  for (const u of units) {
    const falta = novo.faltam(u.qs.length); faltamTotal += falta;
    for (const nd of u.nodes.filter(n => n.type === 'licao')) {
      licoes++;
      if (nd.qs.length >= MIN) continue;
      curtas++;
      if (!falta) { falhas++; console.log('LIÇÃO CURTA SEM FALTA:', t, u.title, nd.qs.length); }
    }
    if (falta) console.log(`  completar: ${t} · ${u.title} — tem ${u.qs.length}, faltam ${falta}`);
  }
}
// E.faltam: depois de completar, toda lição chega ao mínimo e o nº de lições não muda.
for (let n = 1; n <= 120; n++) {
  const f = novo.faltam(n), N = n + f, k = Math.max(1, Math.round(N / 7));
  if (Math.floor(N / k) < MIN || (n >= MIN && k !== Math.max(1, Math.round(n / 7)))) { falhas++; console.log('faltam() errado para n =', n); }
}
console.log(`${licoes} lições · ${curtas} abaixo de ${MIN} (unidades a completar: ${faltamTotal} perguntas)`);
console.log(falhas ? `FALHOU (${falhas})` : 'OK: chaves idênticas e mínimo garantido onde há perguntas');
process.exit(falhas ? 1 : 0);
