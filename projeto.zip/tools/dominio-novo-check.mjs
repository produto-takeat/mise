// Cenário "domínio novo": o aparelho não tem progresso local (localStorage de outra origem não vem junto)
// e a nuvem tem o progresso da pessoa. Nada pode sobrescrever a nuvem com um progresso zerado,
// nem quando a primeira leitura da nuvem falha.
import { chromium } from 'playwright-core';
const UID = '11111111-1111-1111-1111-111111111111';
const NUVEM = { v: 1, uid: UID, onboarded: true, name: 'João Lucas', team: 'Tecnologia', xpTotal: 940, takitos: 300, done: { 'FUN:0:0': 1, 'FUN:0:1': 1 }, league: { idx: 1, week: null, seed: 1, xp: 120 } };
let falhar = true, salvos = [];
const b = await chromium.launch({ channel: 'chrome' });
const ctx = await b.newContext({ viewport: { width: 1440, height: 900 } });
await ctx.addInitScript(([uid]) => {
  const exp = Math.floor(Date.now() / 1000) + 3600 * 24;
  localStorage.setItem('mise-auth', JSON.stringify({ access_token: 'x.y.z', refresh_token: 'r', expires_at: exp, expires_in: 86400, token_type: 'bearer', user: { id: uid, email: 'joao.lucas@takeat.app', user_metadata: {}, aud: 'authenticated', role: 'authenticated' } }));
  // Só a sessão (o que o login grava): sem progresso local, sem salvoEm, sem nuvemOk.
  if (!localStorage.getItem('mise-v1')) localStorage.setItem('mise-v1', JSON.stringify({ v: 1, session: { email: 'joao.lucas@takeat.app' }, uid, onboarded: true, name: 'João Lucas' }));
}, [UID]);
await ctx.route('**/rest/v1/**', async route => {
  const u = route.request().url(), body = route.request().postDataJSON?.() || {};
  const j = (d, status = 200) => route.fulfill({ status, contentType: 'application/json', body: JSON.stringify(d) });
  if (u.includes('/profiles')) return j({ full_name: 'João Lucas', team: 'Tecnologia', cargo: 'Dev', telefone: null, avatar_url: null, moldura: null });
  if (u.includes('rpc/mise_estado')) return falhar ? j({ message: 'erro' }, 500) : j({ dados: NUVEM, atualizado_em: new Date(Date.now() - 86400000).toISOString(), saldo: 300 });
  if (u.includes('rpc/mise_salvar')) { salvos.push(body.p_xp_total); return j({ ok: true }); }
  if (u.includes('rpc/mise_takitos')) return j({ ok: true, saldo: 300 });
  if (u.includes('rpc/mise_ranking')) return j([]);
  return j([]);
});
const p = await ctx.newPage(); const errs = []; p.on('pageerror', e => errs.push(String(e)));
await p.goto('http://localhost:5181/'); await p.waitForTimeout(6000);
await p.evaluate(() => window.dispatchEvent(new Event('online'))); await p.waitForTimeout(2500);
console.log('1. nuvem fora do ar: nenhum envio de progresso zerado:', salvos.length === 0, salvos);
falhar = false;
await p.evaluate(() => document.dispatchEvent(new Event('visibilitychange'))); await p.waitForTimeout(3000);
const xpLocal = await p.evaluate(() => JSON.parse(localStorage.getItem('mise-v1') || '{}').xpTotal);
console.log('2. nuvem voltou: progresso da nuvem carregado (940):', xpLocal === 940, xpLocal);
console.log('3. envios nunca abaixo do XP da nuvem:', salvos.every(x => x >= 940), salvos);
console.log('4. barra lateral no PC:', await p.locator('.ac-side').isVisible(), '| barra inferior oculta:', !(await p.locator('.ac-tabbar').isVisible()));
console.log('erros', errs); await b.close();
