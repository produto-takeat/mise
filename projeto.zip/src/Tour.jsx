// Tutorial guiado ("tour") do app: a Mise apresenta cada parte da tela principal em balõezinhos,
// com um recorte de luz em volta do item. Abre sozinho para quem está começando (sem nenhuma lição
// feita) e pode ser revisto em Perfil › Configurações. O estado (passo atual) vem do MiseLogic.
import React, { useEffect, useLayoutEffect, useState } from 'react';

const RED = '#df1c0d';
const visivel = (el) => !!el && el.getClientRects().length > 0 && getComputedStyle(el).visibility !== 'hidden';
const porLabel = (l) => () => [...document.querySelectorAll(`[aria-label="${l}"]`)].find(visivel);

// Curto de propósito (5 passos): o que dá pra agrupar vai num balão só.
const varios = (...fs) => () => fs.map(f => f()).filter(Boolean);
const menu = () => { const m = [...document.querySelectorAll('.ac-side, .ac-tabbar')].find(visivel); return m ? [...m.querySelectorAll('button')].filter(visivel) : null; };
export const PASSOS = [
  { alvo: () => document.querySelector('[data-current="1"]'), titulo: 'Oi! Eu sou a Mise', texto: 'Cada círculo da trilha é uma lição de 5 minutos sobre o produto Takeat. A que está pulsando é a sua próxima.', redondo: true },
  { alvo: porLabel('Trocar de trilha'), titulo: 'Outras trilhas', texto: 'Toque aqui pra trocar de trilha: Operação/PDV, Delivery, Fiscal e outras.' },
  { alvo: varios(porLabel('Ofensiva'), porLabel('XP de hoje'), porLabel('Seus Takitos')), titulo: 'Seu dia', texto: 'Ofensiva (dias seguidos estudando), meta de XP do dia e seus Takitos, que são os mesmos do Hub.' },
  { alvo: menu, titulo: 'Menu', texto: 'Praticar revisa seus erros, Ligas tem o ranking da semana, Missões dão Takitos extras e no Perfil dá pra rever este tutorial.' },
  { titulo: 'Bora começar?', texto: 'Sua primeira lição já está te esperando.', botao: 'Começar lição', fim: true },
];

export default function Tour({ passo, onProximo, onVoltar, onPular, onComecar }) {
  const p = PASSOS[passo];
  const [rect, setRect] = useState(null);
  const [vw, setVw] = useState(() => ({ w: window.innerWidth, h: window.innerHeight }));

  // Mede o alvo (e de novo em resize/scroll — o alvo pode estar numa lista com rolagem).
  useLayoutEffect(() => {
    let raf = 0;
    const medir = () => {
      const alvo = p && p.alvo ? p.alvo() : null;
      const els = (Array.isArray(alvo) ? alvo : [alvo]).filter(Boolean);
      if (els.length === 1 && els[0].scrollIntoView && !medir.rolou) { medir.rolou = true; els[0].scrollIntoView({ block: 'center', behavior: 'smooth' }); }
      const rs = els.map(e => e.getBoundingClientRect()).filter(r => r.width);
      if (rs.length) {
        const x = Math.min(...rs.map(r => r.left)), y = Math.min(...rs.map(r => r.top));
        setRect({ x, y, w: Math.max(...rs.map(r => r.right)) - x, h: Math.max(...rs.map(r => r.bottom)) - y });
      } else setRect(null);
      setVw({ w: window.innerWidth, h: window.innerHeight });
    };
    medir();
    const t = setTimeout(medir, 380);  // depois da rolagem suave
    const on = () => { cancelAnimationFrame(raf); raf = requestAnimationFrame(medir); };
    window.addEventListener('resize', on); window.addEventListener('scroll', on, true);
    return () => { clearTimeout(t); cancelAnimationFrame(raf); window.removeEventListener('resize', on); window.removeEventListener('scroll', on, true); };
  }, [passo]);

  useEffect(() => {
    const k = (e) => { if (e.key === 'Escape') onPular(); else if (e.key === 'ArrowRight' || e.key === 'Enter') (p.fim ? onComecar : onProximo)(); else if (e.key === 'ArrowLeft' && passo > 0) onVoltar(); };
    window.addEventListener('keydown', k); return () => window.removeEventListener('keydown', k);
  }, [passo]);

  if (!p) return null;
  const pad = p.redondo ? 12 : 6;
  const furo = rect ? { left: rect.x - pad, top: rect.y - pad, width: rect.w + pad * 2, height: rect.h + pad * 2 } : null;
  const cw = Math.min(340, vw.w - 24);
  // Balão abaixo do alvo quando cabe; senão acima. Sem alvo: no centro.
  let pos;
  if (furo) {
    const left = Math.max(12, Math.min(vw.w - cw - 12, furo.left + furo.width / 2 - cw / 2));
    const abaixo = furo.top + furo.height + 14;
    const cabeAcima = furo.top - 14 > 220;
    if (abaixo + 220 < vw.h) pos = { left, top: abaixo };
    else if (cabeAcima) pos = { left, bottom: vw.h - furo.top + 14 };
    else pos = { left: Math.min(vw.w - cw - 12, furo.left + furo.width + 14), top: Math.max(12, Math.min(vw.h - 240, furo.top + furo.height / 2 - 110)) };  // alvo alto: ao lado
  } else pos = { left: (vw.w - cw) / 2, top: Math.max(24, vw.h / 2 - 150) };
  const total = PASSOS.length;

  return (
    <div role="dialog" aria-modal="true" aria-label={'Tutorial: ' + p.titulo} style={{ position: 'fixed', inset: 0, zIndex: 400, fontFamily: 'Poppins,sans-serif' }}>
      {/* escurece tudo menos o alvo */}
      <div style={furo
        ? { position: 'fixed', ...furo, borderRadius: p.redondo ? '50%' : 16, boxShadow: '0 0 0 9999px rgba(20,12,10,.62)', transition: 'all .35s cubic-bezier(.16,1,.3,1)', pointerEvents: 'none' }
        : { position: 'fixed', inset: 0, background: 'rgba(20,12,10,.62)', transition: 'background .3s' }} />
      {furo && <div style={{ position: 'fixed', ...furo, borderRadius: p.redondo ? '50%' : 16, border: '2.5px solid #fff', boxShadow: '0 0 0 4px hsl(6 91% 47% / .55)', transition: 'all .35s cubic-bezier(.16,1,.3,1)', pointerEvents: 'none', animation: 'tourPulso 1.6s ease-in-out infinite' }} />}
      <div key={passo} style={{ position: 'fixed', ...pos, width: cw, background: '#fff', borderRadius: 18, boxShadow: '0 18px 50px rgba(0,0,0,.28)', padding: '16px 16px 14px', animation: 'tourEntra .32s cubic-bezier(.16,1,.3,1) both', color: 'hsl(0 0% 13%)' }}>
        <div style={{ display: 'flex', gap: 12, alignItems: 'flex-start' }}>
          <img src="assets/mise-avatar.png" alt="" width="46" height="46" style={{ flex: 'none', borderRadius: 14, background: '#f5f2e2', objectFit: 'contain' }} />
          <div style={{ minWidth: 0, paddingRight: !p.fim && passo > 0 ? 36 : 0 }}>
            <div style={{ fontSize: 15.5, fontWeight: 700, lineHeight: 1.25 }}>{p.titulo}</div>
            <div style={{ fontSize: 13.5, lineHeight: 1.45, color: 'hsl(0 0% 32%)', marginTop: 4 }}>{p.texto}</div>
          </div>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginTop: 14 }}>
          <div style={{ display: 'flex', gap: 4, flex: 1, minWidth: 0 }} aria-label={`Passo ${passo + 1} de ${total}`}>
            {PASSOS.map((_, i) => <span key={i} style={{ width: i === passo ? 16 : 6, height: 6, borderRadius: 999, background: i <= passo ? RED : 'hsl(0 0% 88%)', transition: 'all .25s' }} />)}
          </div>
          {p.fim
            ? <button onClick={onPular} style={btn(false)}>Explorar sozinho</button>
            : passo > 0 ? <button onClick={onVoltar} style={btn(false)}>Voltar</button> : <button onClick={onPular} style={btn(false)}>Pular</button>}
          <button onClick={p.fim ? onComecar : onProximo} style={btn(true)}>{p.botao || 'Próximo'}</button>
        </div>
        {!p.fim && passo > 0 && <button onClick={onPular} style={{ position: 'absolute', top: 8, right: 10, border: 'none', background: 'none', color: 'hsl(0 0% 55%)', fontSize: 12, fontWeight: 600, cursor: 'pointer', padding: 6, fontFamily: 'inherit' }}>Pular</button>}
      </div>
    </div>
  );
}

const btn = (primario) => ({
  minHeight: 40, padding: '0 14px', borderRadius: 11, cursor: 'pointer', fontFamily: 'inherit', fontSize: 13.5, fontWeight: 700, whiteSpace: 'nowrap',
  border: primario ? 'none' : '1px solid hsl(0 0% 88%)', background: primario ? RED : '#fff', color: primario ? '#fff' : 'hsl(0 0% 30%)',
  boxShadow: primario ? '0 3px 0 hsl(6 100% 34%)' : 'none',
});
