// Lógica da Mise — portada 1:1 do protótipo (script data-dc-script).
// Estado, regras e renderVals() são os mesmos do HTML de protótipo.
import React from 'react';
import DCLogic from './dc-logic.js';
import * as Hub from './hub.js';
import * as Upd from './update.js';
import * as F from './fsrs.js';

const LS = 'mise-v1';
const LSQ = 'mise-questoes-v1'; // cópia local das perguntas publicadas (funciona offline)
const LSF = 'mise-fsrs-v1';     // último estado da Revisão do dia (FSRS) vindo do servidor (funciona offline)
// Ferramentas de teste (simulador da liga, encerrar semana, avançar dia, simular offline, trocar perfil, ?demo=).
// Ficam fora do build de produção; ligam no `npm run dev` ou com VITE_DEV_TOOLS=on.
const DEV_TOOLS = !!(import.meta.env.DEV || import.meta.env.VITE_DEV_TOOLS === 'on');
const RED = 'hsl(6 91% 47%)', REDT = 'hsl(6 91% 47% / .12)', REDT2 = 'hsl(6 91% 47% / .06)', GREEN = 'hsl(150 55% 40%)', GREENT = 'hsl(150 55% 40% / .12)', BD = 'hsl(0 0% 90%)', MUT = 'hsl(0 0% 46%)', INK = 'hsl(0 0% 13%)', AMBER = 'hsl(40 92% 46%)';
// Coleções das molduras do Hub (prefixo da chave do asset; igual a src/lib/molduras.ts do HubProduto).
const COLECAO = { metal: 'Metais', natureza: 'Natureza', elementos: 'Elementos', rpg: 'RPG', mistico: 'Místico', gotico: 'Gótico', cosmos: 'Cosmos', futurista: 'Futurista', anim: 'Efeitos', oriental: 'Oriental', gastro: 'Gastronomia', pet: 'Companheiros', takeat: 'Takeat' };
// Abas da loja que ainda não existem no TakeatHub.
const LOJA_EM_BREVE = {
  fundo: { icon: 'image', titulo: 'Fundos chegam em breve', texto: 'Os planos de fundo do perfil ainda estão sendo preparados no TakeatHub. Enquanto isso, use seus Takitos nas molduras e nos itens.' },
  icone: { icon: 'badge', titulo: 'Ícones chegam em breve', texto: 'Os ícones do perfil ainda estão sendo preparados no TakeatHub. Enquanto isso, use seus Takitos nas molduras e nos itens.' }
};
// Níveis do nivelamento (as regras e o número de perguntas vêm do servidor).
const NIVEIS = {
  iniciante: { t: 'Iniciante', sub: 'Estou começando agora', d: '6 perguntas do básico, com a Mise explicando cada resposta. Acertou o módulo, ele fica concluído.', icon: 'sprout' },
  intermediario: { t: 'Intermediário', sub: 'Já uso no dia a dia', d: '8 perguntas em até 3 min. Acertou as 2 de um módulo, ele fica concluído — com o XP das fases.', icon: 'gauge' },
  avancado: { t: 'Avançado', sub: 'Domino a plataforma', d: '10 perguntas difíceis em até 3 min. Mandou bem? O básico da trilha também fica concluído.', icon: 'rocket' }
};
const STEP = 64;
const OFF = [0, 46, 70, 46, 0, -46, -70, -46];

export default class MiseLogic extends DCLogic {
  state = {
    ready: false, screen: 'splash', tab: 'learn', sub: null, p: null,
    lg: { email: '', pwd: '', show: false, remember: true, loading: false, err: '' },
    temp: null, first: null, onb: { step: 0 }, lesson: null, ex: null, fb: null, why: false, exitAsk: false,
    end: null, endAnim: { xp: 0, acc: 0 }, post: [], postItem: null, popNode: null, sheet: null, toasts: [], flyers: [], chest: null,
    weekResult: null, lbFilter: 'all', lbLoading: false, profTab: 'desemp', gloss: '', leaderTab: 'units', ruleForm: null, qForm: null,
    flash: null, bannerUnit: 0, bannerFlip: true, justDone: null, now: Date.now(), loja: { busca: '', tier: 'todas', codigo: '' },
    online: true, resetAsk: false, bumpCoin: 0, bumpXp: 0, particles: 0, tempPwd: null, openRule: null, prof: null, homeLoading: false
  };
  frameRef = React.createRef(); repFileRef = React.createRef(); coinImgRef = React.createRef(); pathRef = React.createRef(); xpRef = React.createRef(); coinRef = React.createRef(); endXpRef = React.createRef();

  get E() { return window.MiseEngine; }
  get C() { return window.MISE_CFG; }

  defaults() {
    return {
      v: 1, session: null, remembered: '', onboarded: false, persona: 'cs', objetivo: null, goalMin: 5, reminder: '09:30', workDays: [1, 2, 3, 4, 5], sound: true,
      role: 'lider', team: 'Suporte', name: '', phone: '', cargo: 'Analista de Suporte',
      xpTotal: 0, xpDay: {}, takitos: 120, streak: { count: 0, last: null, freezes: 1, grantWeek: null, days: [], best: 0 }, done: {}, activeTrack: 'FUN',
      league: { idx: 0, week: null, seed: 1, xp: 0 }, day: {}, month: {}, badges: [], certs: [], hl: {}, fsrs: {}, errors: {}, stats: { ans: 0, ok: 0 }, flashRecord: 0, boostUntil: 0,
      owned: ['m-bronze'], equipped: 'metal:bronze', dayOffset: 0, nudged: {}, offlineSim: false, levelTest: null,
      leader: { disabled: {}, mandatory: {}, rules: { Suporte: [{ id: 'r1', titulo: 'Modelo de resposta de impressão', descricao: 'Em chamados de impressão, use o modelo "Impressão · checklist" e adapte com o nome da loja e a impressora citada.', bom: 'Oi, Rafa! Vi que a impressora da cozinha parou. Vamos checar 3 pontos rapidinho: cabo, rede e o App de Impressão aberto.', ruim: 'Segue o procedimento padrão de impressão.', wiki: 'wiki/artigos/app-impressao.md', questions: [], published: false }] } }
    };
  }

  componentDidMount() {
    const go = () => {
      if (!(window.MiseEngine && window.MISE_CFG && window.MISE_BANK && window.MISE_ATD)) return setTimeout(go, 60);
      this.bank = window.MISE_BANK; this.atd = window.MISE_ATD;
      // Perguntas do banco (mantidas em dia com a wiki): usa a última cópia do aparelho até a nuvem responder.
      try { this.aplicarQuestoes(JSON.parse(localStorage.getItem(LSQ) || 'null')); } catch (e) {}
      const demo = new URLSearchParams(location.search).get('demo');
      if (demo && DEV_TOOLS) return this.startDemo(demo);
      let saved = null; try { saved = JSON.parse(localStorage.getItem(LS) || 'null'); } catch (e) {}
      const d = this.defaults();
      const p = Object.assign(d, saved || {});
      if (!DEV_TOOLS) { p.dayOffset = 0; p.offlineSim = false; }
      p.leader = Object.assign(d.leader, p.leader || {});
      // O "Alterar senha" antigo guardava a senha digitada aqui (p.users): apaga do aparelho ao abrir.
      if (p.users) { delete p.users; try { localStorage.setItem(LS, JSON.stringify(p)); } catch (e) {} }
      this._p = p;
      this.setState({ ready: true, p, online: navigator.onLine, lg: Object.assign({}, this.state.lg, { email: p.remembered || '' }) });
      setTimeout(() => {
        // Só entra direto se ainda houver sessão válida do TakeatHub (funciona offline: a sessão fica no aparelho).
        Hub.supabase.auth.getSession().then(({ data }) => {
          const q = this._p, ok = !!(q.session && data && data.session && (!q.uid || data.session.user.id === q.uid));
          if (!ok && q.session) this.upd(x => { x.session = null; });
          // No TakeatHub: quem já está logado no Hub entra direto (a sessão é a mesma).
          if (!ok && Hub.noHub && data && data.session) return this.entrarPeloHub();
          if (!ok) return this.setState({ screen: 'login' });
          // Perfil do Hub + progresso da nuvem antes de decidir a tela (offline: segue com o que há no aparelho).
          const pronto = Hub.perfilAtual().catch(() => null).then(pf => this.carregarNuvem(pf ? this.perfilParaP(pf) : null));
          Promise.race([pronto, new Promise(r => setTimeout(r, 5000))]).then(() => this.irDepoisDoLogin());
        }).catch(() => this.setState({ screen: 'login' }));
      }, 3500); // tempo da intro "espiadinha" (a Mise sobe e o nome aparece)
    };
    go();
    this.onOn = () => { this.setState({ online: true }); this.flushReports(); this.enviarNuvem(); this.atualizarSaldo(); };
    // Voltou para o app: saldo de Takitos (ex.: depósito feito no Hub) e ranking atualizados.
    this.onVis = () => { if (document.visibilityState === 'visible') { this.retentarNuvem(); this.atualizarSaldo(); this.carregarRanking(); } };
    document.addEventListener('visibilitychange', this.onVis);
    this.ivNuvem = setInterval(() => { if (this._p && this._p.uid && document.visibilityState === 'visible') { this.retentarNuvem(); this.atualizarSaldo(); if (this.state.tab === 'league' || this.state.tab === 'learn') this.carregarRanking(); } }, 30000); this.onOff = () => this.setState({ online: false });
    window.addEventListener('online', this.onOn); window.addEventListener('offline', this.onOff);
    this.iv = setInterval(() => this.tick(), 500);
    setTimeout(() => this.flushReports(), 2500);
    setTimeout(() => { if (Upd.ehNativo()) this.checarAtualizacao(true); }, 6000);
  }
  componentWillUnmount() { clearInterval(this.iv); window.removeEventListener('online', this.onOn); window.removeEventListener('offline', this.onOff); }

  tick() {
    const s = this.state;
    if (s.screen === 'flash' && s.flash && !s.flash.done) { if (Date.now() >= s.flash.end) this.finishFlash(); else this.setState({ now: Date.now() }); return; }
    if (s.screen === 'lesson' && s.lesson && s.lesson.timed && !s.fb && !s.lesson.tipOpen) {
      // Nivelamento: um relógio só para o quiz inteiro (o servidor confere o mesmo prazo).
      if (s.lesson.mode === 'nivelamento') { if (Date.now() >= s.lesson.prazoLocal) this.finishServidor(s.lesson); else this.setState({ now: Date.now() }); return; }
      if (Date.now() - s.lesson.qStart >= 30000) { if (s.lesson.server) this.checkServidor(true, true); else this.resolve(false, true); } else this.setState({ now: Date.now() });
      return;
    }
    if (s.screen === 'app' && Date.now() - s.now > 20000) this.setState({ now: Date.now() });
  }

  // ---------- modo demonstração (canvas de fluxo): ?demo=<estado>, sem persistir ----------
  startDemo(demo) {
    this.demo = true;
    if (DEV_TOOLS) window.__mise = this;
    const p = this.defaults(), em = 'ana.prado@takeat.app';
    p.session = demo === 'loading' || demo === 'path' ? { email: em } : null; p.name = 'Ana Prado'; p.onboarded = demo === 'loading' || demo === 'path';
    this._p = p;
    const lg = Object.assign({}, this.state.lg, { email: /^(login|splash)$/.test(demo) ? '' : em, pwd: /^(loginErr|first)$/.test(demo) ? 'academy12' : '' });
    const st = { ready: true, p, online: true, lg };
    const m = demo.match(/^onb(\d)$/);
    if (demo === 'splash') st.screen = 'splash';
    else if (demo === 'login') st.screen = 'login';
    else if (demo === 'loginErr') Object.assign(st, { screen: 'login', lg: Object.assign(lg, { err: 'E-mail ou senha incorretos.' }) });
    else if (demo === 'temp') Object.assign(st, { screen: 'login', temp: { step: 'form', err: '' } });
    else if (demo === 'tempSent') Object.assign(st, { screen: 'login', temp: { step: 'sent', nome: 'Ana Prado', masc: '(27) •••••-4821', pwd: 'TK-7316' } });
    else if (demo === 'first') Object.assign(st, { screen: 'login', first: { email: em, pwd: 'segredo', pwd2: 'segredo', team: 'Suporte', birth: '10/04/1995', err: '' } });
    else if (m) { const n = +m[1]; st.screen = 'onb'; st.onb = { step: n, persona: 'cs', objetivo: n >= 1 ? 'chegando' : null, goalMin: n >= 2 ? 5 : null, nivel: n >= 3 ? 'basico' : null, reminder: '09:30' }; if (n === 0) st.onb.persona = 'cs'; }
    else if (demo === 'nivelamento' && DEV_TOOLS) { p.onboarded = true; p.session = { email: em }; p.uid = 'demo'; this._demoAv = this.demoAvaliacao(); Object.assign(st, { screen: 'app', tab: 'learn' }); }
    else if (demo === 'revisao' && DEV_TOOLS) { p.onboarded = true; p.session = { email: em }; p.uid = 'demo'; this.demoRevisao(p); Object.assign(st, { screen: 'app', tab: 'practice' }); }
    else if (demo === 'loading') Object.assign(st, { screen: 'app', tab: 'learn', homeLoading: true });
    else Object.assign(st, { screen: 'app', tab: 'learn' });
    this.setState(st, () => { if (demo === 'path') setTimeout(() => this.scrollToCurrent(false), 300); if (this._demoAv) this.enterApp(); });
  }
  // Servidor das avaliações nas chamadas reais (Hub) ou, no ?demo=nivelamento (só dev), um servidor de mentira
  // em memória com as perguntas do banco embutido — para ver o fluxo sem login.
  av() { return this._demoAv || Hub; }
  demoAvaliacao() {
    const self = this, tent = {};
    const doModulo = (tid, ui) => { const u = self.units(tid)[ui]; return u ? self.E.shuffle(u.qs.filter(q => q.tipo === 'multipla_escolha' || q.tipo === 'verdadeiro_falso')).slice(0, 2).map(q => Object.assign({}, q, { trilha_id: tid })) : []; };
    const st = { ativo: true, mestre_servidor: false, obrigatorio: true, modulos: [], certificados: [], config: {} };
    return {
      nivelamentoStatus: async () => st,
      avaliacaoIniciar: async (modo, nivel) => {
        const plano = nivel === 'iniciante' ? [['FUN', 1], ['BAS', 0]] : nivel === 'avancado' ? [['OPE', 2], ['OPE', 3], ['DIS', 0], ['FIS', 0], ['GES', 0]] : [['FUN', 0], ['FUN', 1], ['FUN', 2], ['BAS', 0]];
        const qs = [].concat.apply([], plano.map(([t, i]) => doModulo(t, i)));
        const id = 'demo-' + Date.now(); tent[id] = { qs, nivel, resp: {} };
        const seg = nivel === 'iniciante' ? 900 : 180;
        return { ok: true, tentativa_id: id, servidor_em: new Date().toISOString(), prazo: new Date(Date.now() + seg * 1000).toISOString(), perguntas: qs.map(q => ({ id: q.id, tipo: q.tipo, enunciado: q.enunciado, opcoes: q.tipo === 'verdadeiro_falso' ? ['Verdadeiro', 'Falso'] : self.E.shuffle(q.opcoes), trilha_id: q.trilha_id, unidade: q.unidade, respondida: false })) };
      },
      avaliacaoResponder: async (t, qid, r) => {
        const T = tent[t], q = T.qs.find(x => x.id === qid), ok = r != null && r === q.resposta; T.resp[qid] = ok;
        return Object.assign({ ok: true, acertou: ok, esgotou: false }, T.nivel === 'iniciante' ? { correta: q.resposta, explicacao: q.explicacao, fonte: q.fonte } : {});
      },
      avaliacaoConcluir: async (t) => {
        const T = tent[t], mods = {};
        T.qs.forEach(q => { const k = q.trilha_id + '|' + q.unidade; mods[k] = mods[k] || { trilha_id: q.trilha_id, unidade: q.unidade, ok: 0, tot: 0 }; mods[k].tot++; if (T.resp[q.id]) mods[k].ok++; });
        const novos = Object.values(mods).filter(m => m.ok === m.tot).map(m => ({ trilha_id: m.trilha_id, unidade: m.unidade, xp: 30 }));
        st.obrigatorio = false; st.modulos = st.modulos.concat(novos);
        return { ok: true, modo: 'nivelamento', nivel: T.nivel, acertos: Object.values(T.resp).filter(Boolean).length, total: T.qs.length, novos, base: false, xp: novos.length * 30 };
      },
    };
  }

  dd(id, label, opts) {
    const open = this.state.dd === id;
    return { label, open, toggle: e => { if (e && e.stopPropagation) e.stopPropagation(); this.setState({ dd: open ? null : id }); },
      items: opts.map(o => ({ t: o.t, sel: !!o.sel, dot: o.dot || 'transparent', bg: o.sel ? REDT : 'transparent', fg: o.sel ? RED : INK, fw: o.sel ? 600 : 500, onClick: e => { if (e && e.stopPropagation) e.stopPropagation(); this.setState({ dd: null }); o.onPick(); } })) };
  }
  timeVals(cur, set) {
    const [hh, mm] = String(cur || '09:30').split(':').map(Number), z = n => String(n).padStart(2, '0');
    const typed = (part) => e => { const d = e.target.value.replace(/\D/g, '').slice(-2); let n = d === '' ? 0 : +d; n = part === 'h' ? Math.min(23, n) : Math.min(59, n); set(part === 'h' ? z(n) + ':' + z(mm) : z(hh) + ':' + z(n)); };
    const mk = (H, M) => set(z((H + 24) % 24) + ':' + z((M + 60) % 60));
    return { onH: typed('h'), onM: typed('m'), focus: e => e.target.select(), hh: z(hh), mm: z(mm), hUp: () => mk(hh + 1, mm), hDown: () => mk(hh - 1, mm), mUp: () => mk(hh, mm + 5 - (mm % 5)), mDown: () => mk(hh, mm % 5 ? mm - (mm % 5) : mm - 5) };
  }

  // ---------- persistência ----------
  save(p) {
    this._p = p; this.setState({ p }); if (this.demo) return;
    p.salvoEm = Date.now();
    try { localStorage.setItem(LS, JSON.stringify(p)); } catch (e) {}
    this.agendarNuvem();
  }

  // ---------- nuvem: progresso, Takitos do Hub e ranking real ----------
  agendarNuvem() {
    if (!this._p || !this._p.uid || !this._nuvemPronta) return;
    clearTimeout(this._nuvemT); this._nuvemT = setTimeout(() => this.enviarNuvem(), 1200);
  }
  posicoes() {
    const out = {};
    try { this.trackList().forEach(t => { const f = this.E.flat(this.units(t.id)), c = f.find(n => !this._p.done[n.key]); if (c) out[t.id] = c.key; }); } catch (e) {}
    return out;
  }
  async enviarNuvem() {
    const p = this._p; if (!p || !p.uid || this._enviando) return;
    // Só envia depois de ler a nuvem ao menos uma vez nesta abertura (senão um aparelho novo sobrescreveria o progresso).
    if (!this._nuvemPronta) return this.retentarNuvem();
    this._enviando = true;
    try {
      // 1) Takitos pendentes (em ordem); o servidor devolve o saldo oficial do Hub. A fila é lida sempre do
      // estado atual (this._p é trocado a cada mudança) e cada movimento sai dela pela ref, enviado ou recusado.
      while ((this._p.tkFila || []).length) {
        const mv = this._p.tkFila[0], r = await Hub.movimentarTakitos(mv.delta, mv.ref);
        this._p.tkFila = (this._p.tkFila || []).filter(x => x.ref !== mv.ref);
        if (r && typeof r.saldo === 'number') this.aplicarSaldo(r.saldo, r.ok ? null : r.erro);
      }
      // 1b) Respostas da Revisão do dia (FSRS) para a métrica. Falha aqui não segura o progresso.
      try { await this.enviarFsrs(); } catch (e) {}
      // 2) Progresso completo (sem dados de sessão).
      const q = this._p, dados = JSON.parse(JSON.stringify(q)); delete dados.session; delete dados.tkFila; delete dados.fsrsFila; delete dados.users;
      await Hub.salvarNuvem({ dados, xpTotal: q.xpTotal || 0, semana: q.league.week, ligaXp: q.league.xp || 0, ligaIdx: q.league.idx || 0, posicoes: this.posicoes(), resumo: this.resumoPublico() });
      try { localStorage.setItem(LS, JSON.stringify(this._p)); } catch (e) {}
      this._ultimoEnvio = Date.now();
    } catch (e) { /* offline ou erro: tenta de novo na próxima mudança / ao voltar a conexão */ }
    this._enviando = false;
  }
  // Números que os colegas veem (missão de equipe, ofensiva, painel do líder).
  resumoPublico() {
    const p = this._p, E = this.E, mon = E.dkey(E.monday(this.today()));
    let licoes = 0; Object.keys(p.day || {}).forEach(d => { if (d >= mon) licoes += (p.day[d].lessons || 0); });
    let atd = 0; try { const f = E.flat(this.units('ATD')); atd = f.length ? Math.round(100 * f.filter(n => p.done[n.key]).length / f.length) : 0; } catch (e) {}
    let reforcar = [], progresso = 0;
    try { reforcar = this.desempUnidades().filter(x => x.score < .6).sort((a, b) => a.score - b.score).slice(0, 3).map(x => x.unidade); } catch (e) {}
    try { const pcs = this.trackList().map(t => E.trackPct(this.C, this.bank, this.atd, p, t.id)).filter(x => x > 0); progresso = pcs.length ? Math.round(pcs.reduce((a, b) => a + b, 0) / pcs.length) : 0; } catch (e) {}
    return { licoesSemana: licoes, ofensiva: E.streakNow(p, this.today()), atdPct: atd, progresso, trilhas: this.tracksDone(), certificados: (p.certs || []).length,
      precisao: p.stats.ans ? Math.round(p.stats.ok / p.stats.ans * 100) : null, reforcar };
  }
  // ---------- atualização do app (GitHub Releases) ----------
  async checarAtualizacao(silencioso) {
    if (this.state.upd && this.state.upd.checking) return;
    this.setState({ upd: Object.assign({}, this.state.upd, { checking: true, err: '' }) });
    try {
      const r = await Upd.buscarAtualizacao();
      this.setState({ upd: { checking: false, info: r, em: Date.now() } });
      if (r.disponivel && silencioso) this.toast('Nova versão do Mise en Place disponível. Baixe em Perfil → Configurações.', 'download');
      if (!silencioso && !r.disponivel) this.toast(Upd.ehNativo() ? 'Você já está na versão mais recente' : 'Você já está na versão mais recente', 'circle-check');
    } catch (e) {
      this.setState({ upd: { checking: false, err: navigator.onLine ? 'Não foi possível verificar agora.' : 'Sem conexão para verificar.' } });
    }
  }
  vUpdate() {
    const u = this.state.upd || {}, info = u.info || {}, nativo = Upd.ehNativo(), ver = 'Versão ' + Upd.VERSION + (Upd.BUILD ? ' (build ' + Upd.BUILD + ')' : '');
    const avail = nativo && !!info.disponivel;
    const status = u.checking ? 'Procurando atualização…' : u.err ? u.err : avail ? 'Build ' + info.build + ' disponível · você está no ' + (Upd.BUILD || 'inicial') : u.em ? ver + ' · a mais recente' : ver;
    return {
      updStatus: status, updAvail: avail, updChecking: !!u.checking, updBtnOp: u.checking ? .6 : 1,
      updCheckLabel: u.checking ? 'Procurando…' : 'Buscar atualização', updDownloadLabel: 'Baixar e instalar a nova versão',
      updIcon: avail ? 'download' : u.err ? 'triangle-alert' : 'refresh-cw', updIconBg: avail ? 'hsl(150 55% 40% / .12)' : 'hsl(0 0% 95%)', updIconFg: avail ? GREEN : MUT,
      onUpdCheck: () => this.checarAtualizacao(false),
      onUpdDownload: () => { Upd.baixar(info.url); this.toast('Baixando o APK. Abra o arquivo ao terminar para instalar.', 'download'); },
      cfgDevShow: DEV_TOOLS && !!this._p && (this._p.role === 'admin' || this._p.role === 'master' || !!this.demo)
    };
  }
  aplicarSaldo(saldo, erro) {
    this._tkBase = saldo;
    if (this._p.takitos !== saldo) { const p = Object.assign({}, this._p, { takitos: saldo }); this._p = p; this.setState({ p }); try { localStorage.setItem(LS, JSON.stringify(p)); } catch (e) {} }
    if (erro === 'saldo insuficiente') this.toast('Takitos insuficientes no seu saldo do TakeatHub', 'triangle-alert', 'err');
    else if (erro && /limite/.test(erro)) this.toast('Você chegou ao limite de Takitos de hoje na Mise. Amanhã tem mais!', 'triangle-alert', 'err');
  }
  // Ao entrar/abrir: puxa o progresso salvo na nuvem e o saldo de Takitos do Hub.
  // Troca o banco de perguntas (nuvem ou cópia local). Ignora listas vazias/curtas demais, para
  // nunca deixar o app sem perguntas por uma resposta parcial.
  aplicarQuestoes(lista) {
    if (!Array.isArray(lista) || lista.length < 50) return false;
    const atd = lista.filter(q => q.trilha_id === 'ATD'), bank = lista.filter(q => q.trilha_id !== 'ATD');
    if (bank.length) this.bank = bank;
    if (atd.length) this.atd = atd;
    this.E._uc = {};
    return true;
  }
  async carregarQuestoes() {
    try {
      const lista = await Hub.questoesNuvem();
      if (this.aplicarQuestoes(lista)) {
        try { localStorage.setItem(LSQ, JSON.stringify(lista)); } catch (e) {}
        if (this._p.activeTrack === 'DEV' && !this.temDev()) this.upd(p => { p.activeTrack = 'FUN'; });
        this.setState({ bancoEm: Date.now() });
      }
    } catch (e) { /* offline ou sem permissão: segue com a cópia local/banco embutido */ }
  }

  async carregarNuvem(perfilHub) {
    // Usuário real: nada de colegas fictícios (ranking, trilha e colegas só com quem joga de verdade).
    if (!Array.isArray(this.C.REAL_RANK)) { this.C.REAL_RANK = []; this.C.PEOPLE = []; }
    this.carregarQuestoes();
    try {
      const st = await Hub.estadoNuvem(), local = this._p;
      const nuvemMaisNova = st && st.dados && st.dados.uid === local.uid && (!local.salvoEm || new Date(st.atualizado_em).getTime() > local.salvoEm - 2000);
      // Aparelho/endereço que nunca sincronizou (ex.: primeira vez no domínio novo): o progresso da
      // nuvem vence sempre que tiver pelo menos o mesmo XP — nunca troca a nuvem por um progresso zerado.
      const aparelhoNovo = st && st.dados && !local.nuvemOk && (st.dados.xpTotal || 0) >= (local.xpTotal || 0);
      if (st && st.dados && (nuvemMaisNova || aparelhoNovo || !local.salvoEm || local.uid !== st.dados.uid)) {
        const d = this.defaults(), p = Object.assign(d, st.dados, { session: local.session, uid: local.uid, remembered: local.remembered, tkFila: local.tkFila || [], fsrsFila: local.fsrsFila });
        p.leader = Object.assign(d.leader, p.leader || {});
        delete p.users;
        if (!DEV_TOOLS) { p.dayOffset = 0; p.offlineSim = false; }
        this._p = p; this.setState({ p });
      }
      // Perfil do TakeatHub sempre vence (foto, moldura, equipe, cargo, papel).
      if (perfilHub) { const p = Object.assign({}, this._p, perfilHub); this._p = p; this.setState({ p }); }
      this._tkBase = typeof st.saldo === 'number' ? st.saldo : this._p.takitos;
      this._tkReady = true; this._nuvemPronta = true; this._p.nuvemOk = true;
      this.carregarFsrs();
      this.aplicarSaldo(this._tkBase);
      // Fecha a semana só depois de ler o ranking dela; senão a liga parece vazia e todo mundo sobe.
      await this.carregarRanking();
      this.checkWeek();
      this.enviarNuvem();
      this.carregarRanking();
    } catch (e) {
      // Sem resposta da nuvem: só libera o envio se este aparelho já sincronizou antes. Aparelho novo
      // espera conseguir ler a nuvem (tenta de novo ao voltar a conexão/aba), para não apagar o progresso.
      this._tkReady = false;
      if (this._p && this._p.nuvemOk) { this._nuvemPronta = true; this.carregarFsrs(); }
    }
  }
  retentarNuvem() {
    if (this._p && this._p.uid && this._p.session && !this._nuvemPronta && !this._recarregando) {
      this._recarregando = true;
      this.carregarNuvem(null).finally(() => { this._recarregando = false; });
    }
  }
  async atualizarSaldo() {
    if (!this._p || !this._p.uid || !this._tkReady) return;
    try { const st = await Hub.estadoNuvem(); if (st && typeof st.saldo === 'number' && !(this._p.tkFila || []).length) this.aplicarSaldo(st.saldo); } catch (e) {}
  }
  async carregarRanking() {
    if (!this._p || !this._p.uid) return;
    try {
      const semana = this._p.league.week || this.E.dkey(this.E.monday(this.today()));
      const rows = await Hub.rankingSemana(semana);
      const outros = rows.filter(r => !r.eu);
      this.C.REAL_RANK = outros.map(r => ({ nome: r.nome || 'Colaborador', team: r.equipe || '', mold: r.moldura || null, photo: r.avatar_url || null, xp: r.liga_xp || 0, idx: r.liga_idx || 0, pos: r.posicoes || {}, res: r.resumo || {} }));
      this.realBy = {}; this.C.REAL_RANK.forEach(r => { this.realBy[r.nome] = r; });
      this.C.PEOPLE = this.C.REAL_RANK.map(r => [r.nome, r.team, r.mold]);
      this.E.PHOTOS = {}; this.C.REAL_RANK.forEach(r => { if (r.photo) this.E.PHOTOS[r.nome] = r.photo; });
      this._rankOk = true;
      this.setState({ rankTick: Date.now() });
    } catch (e) {}
  }
  upd(fn) { const p = JSON.parse(JSON.stringify(this._p)); const r = fn(p); this.save(p); return r; }
  today() { return new Date(Date.now() + (DEV_TOOLS && this._p && this._p.dayOffset || 0) * this.E.DAY); }
  tk() { return this.E.dkey(this.today()); }
  addXp(p, n) {
    if (n <= 0) return 0;
    if (Date.now() < p.boostUntil) n *= 2;
    const k = this.tk(); p.xpTotal += n; p.xpDay[k] = (p.xpDay[k] || 0) + n; p.league.xp += n; this.E.dayRec(p, k).xp += n;
    return n;
  }
  checkMissions(p) {
    const k = this.tk(), dr = this.E.dayRec(p, k), got = [];
    this.E.missionsFor(this.C, k).forEach(m => { if (!dr.claimed[m.k] && (dr[m.m] || 0) >= m.meta) { dr.claimed[m.k] = true; this.ganhar(p, this.C.MISSION_REWARD, 'missao:' + k + ':' + m.k); got.push(m); } });
    return got;
  }
  // Takitos ganhos na Mise vão pro saldo do TakeatHub com o MOTIVO na ref ("missao:…", "bau:…", "bau-diario:…",
  // "marco:…", "promocao:…"). O servidor (mise_takitos) confere motivo, valor e tetos do dia; a ref identifica o
  // evento, então o mesmo ganho nunca entra duas vezes.
  ganhar(p, n, ref) { p.takitos += n; this.registrarGanho(p, n, ref); }
  registrarGanho(p, n, ref) { if (!this.demo && p.uid && n > 0) p.tkFila = (p.tkFila || []).concat([{ delta: n, ref }]); }
  units(tid) { return this.E.getUnits(this.C, this.bank, this.atd, this._p, tid || this._p.activeTrack); }
  trackList() { const l = [{ id: 'ATD', nome: 'Regras de Atendimento · ' + this._p.team, icon: 'headset' }].concat(this.C.TRACKS); return this.temDev() ? l.concat([{ id: 'DEV', nome: 'Desenvolvimento', icon: 'code', dev: true }]) : l; }
  // Trilha Dev (técnica): Tecnologia e Produto + admin/master veem; líder de Tecnologia e master editam
  // (o banco confere de novo: RLS na leitura e a edge mise-dev na escrita).
  podeDev() { const p = this._p; return ['Tecnologia', 'Produto'].indexOf(p.team) >= 0 || ['admin', 'master'].indexOf(p.role) >= 0; }
  editaDev() { const p = this._p; return p.role === 'master' || (p.leaderTeams || []).indexOf('Tecnologia') >= 0; }
  devQs() { return (this.bank || []).filter(q => q.trilha_id === 'DEV'); }
  temDev() { return this.podeDev() && this.devQs().length > 0; }
  trackInfo(id) { return this.trackList().find(t => t.id === id) || this.C.TRACKS[0]; }
  qById(id) {
    let q = this.bank.find(x => x.id === id) || this.atd.find(x => x.id === id);
    if (q) return q;
    const rules = this._p.leader.rules; Object.keys(rules).forEach(t => rules[t].forEach(r => r.questions.forEach(x => { if (x.id === id) q = x; })));
    return q;
  }
  isLeader() { return ['lider', 'admin', 'master'].indexOf(this._p.role) >= 0; }
  toast(text, icon, tone) {
    const id = Math.random().toString(36).slice(2);
    this.setState(s => ({ toasts: s.toasts.concat([{ id, text, icon: icon || 'circle-check', fg: tone === 'err' ? RED : tone === 'gold' ? 'hsl(32 82% 40%)' : GREEN }]).slice(-3) }));
    setTimeout(() => this.setState(s => ({ toasts: s.toasts.filter(t => t.id !== id) })), 2800);
  }
  beep(kind) {
    if (!this._p || !this._p.sound) return;
    try {
      const ctx = this.ac || (this.ac = new (window.AudioContext || window.webkitAudioContext)());
      const seq = kind === 'ok' ? [[660, 0], [880, .09]] : kind === 'err' ? [[240, 0], [190, .13]] : kind === 'tap' ? [[520, 0]] : [[523, 0], [659, .1], [784, .2], [1046, .32]];
      seq.forEach(([f, t]) => { const o = ctx.createOscillator(), g = ctx.createGain(); o.type = 'sine'; o.frequency.value = f; const t0 = ctx.currentTime + t; g.gain.setValueAtTime(.0001, t0); g.gain.exponentialRampToValueAtTime(.14, t0 + .02); g.gain.exponentialRampToValueAtTime(.0001, t0 + .2); o.connect(g); g.connect(ctx.destination); o.start(t0); o.stop(t0 + .22); });
    } catch (e) {}
  }

  // ---------- voo de moedas / XP ----------
  center(el) { const f = this.frameRef.current; if (!f || !el) return null; const a = f.getBoundingClientRect(), b = el.getBoundingClientRect(); return { x: b.left - a.left + b.width / 2, y: b.top - a.top + b.height / 2 }; }
  fly(kind, from, n) {
    const to = this.center(kind === 'coin' ? (this.coinImgRef.current || this.coinRef.current) : this.xpRef.current); if (!to || !from) return;
    const items = []; for (let i = 0; i < n; i++) items.push({ id: Math.random().toString(36).slice(2), kind, x: from.x + (i - n / 2) * 8, y: from.y, dx: to.x - from.x - (i - n / 2) * 8, dy: to.y - from.y, delay: i * 60 });
    this.setState(s => ({ flyers: s.flyers.concat(items) }));
    setTimeout(() => this.setState(kind === 'coin' ? { bumpCoin: Date.now() } : { bumpXp: Date.now() }), 700 + (n - 1) * 60);
    setTimeout(() => this.setState(s => ({ flyers: s.flyers.filter(f => !items.includes(f)) })), 1100 + n * 60);
  }
  frameCenter() { const f = this.frameRef.current; return f ? { x: f.clientWidth / 2, y: f.clientHeight / 2 } : { x: 195, y: 420 }; }

  // ---------- navegação ----------
  enterApp() { this.checkWeek(); this.setState({ homeLoading: true }); setTimeout(() => { this.setState({ homeLoading: false }); this.scrollToCurrent(true); this.talvezTutorial(0); this.verificarNivelamento(); }, 450); }
  // ---------- tutorial guiado (src/Tour.jsx) ----------
  // Abre sozinho pra quem está começando (nenhum XP ainda, ou acabou de passar pelo onboarding) e nunca viu.
  // "tourVisto" vai junto com o progresso pra nuvem, então não reaparece em outro aparelho.
  talvezTutorial(tentativa) {
    const p = this._p, s = this.state;
    if (!p || this.demo || s.screen !== 'app') return;
    // espera a tela assentar (sem baú, resumo da semana ou folha abertos por cima)
    // só depois de ler o progresso da nuvem (aparelho novo de quem já joga não pode ver o tutorial de iniciante)
    if (!this._nuvemPronta || s.chestOpen || s.wrOpen || s.sheetOpen || s.sub || s.tab !== 'learn') { if (tentativa < 20) setTimeout(() => this.talvezTutorial(tentativa + 1), 1500); return; }
    const q = this._p;   // reavalia com o progresso que veio da nuvem
    if (q.tourVisto || !(q.tourPendente || !(q.xpTotal > 0))) return;
    setTimeout(() => { if (this.state.screen === 'app' && this.state.tour == null) this.setState({ tour: 0, popNode: null }); }, 600);
  }
  abrirTutorial() { this.setState({ tab: 'learn', sub: null, popNode: null }, () => { this.scrollToCurrent(false); setTimeout(() => this.setState({ tour: 0 }), 350); }); }
  tourIr(d) { const PASSOS = 5; this.setState(s => ({ tour: Math.max(0, Math.min(PASSOS - 1, (s.tour || 0) + d)) })); }
  tourFim(comecar) {
    this.setState({ tour: null });
    this.upd(q => { q.tourVisto = true; q.tourPendente = false; });
    if (comecar) { const el = document.querySelector('[data-current="1"]'); if (el) setTimeout(() => el.click(), 150); }
  }
  goApp(extra) {
    this.setState(Object.assign({ screen: 'app', tab: 'learn', sub: null, lesson: null, ex: null, fb: null, why: false, end: null, postItem: null }, extra || {}), () => this.scrollToCurrent(true));
    if (this.pendingToasts) { this.pendingToasts.forEach((m, i) => setTimeout(() => { this.toast('Missão concluída: ' + m.t + ' · +' + this.C.MISSION_REWARD + ' Takitos', 'target', 'gold'); this.fly('coin', this.frameCenter(), 3); }, 500 + i * 900)); this.pendingToasts = null; }
    if (extra && extra.justDone) setTimeout(() => this.setState({ justDone: null }), 1600);
  }
  setTab(t) { this.setState({ tab: t, sub: null, popNode: null }, () => { if (t === 'learn') this.scrollToCurrent(false); }); if (t === 'league') { this.carregarRanking(); this.setState({ lbLoading: true }); setTimeout(() => this.setState({ lbLoading: false }), 550); } }
  scrollToCurrent(smooth) {
    setTimeout(() => {
      const c = this.pathRef.current; if (!c) return;
      const el = c.querySelector('[data-current="1"]');
      if (smooth) c.scrollTop = c.scrollHeight;
      if (!el) { this.updateBanner(); return; }
      const top = el.getBoundingClientRect().top - c.getBoundingClientRect().top + c.scrollTop - c.clientHeight * 0.45;
      c.scrollTo({ top, behavior: smooth ? 'smooth' : 'auto' });
      setTimeout(() => this.updateBanner(), smooth ? 500 : 30);
    }, 60);
  }
  updateBanner() {
    const c = this.pathRef.current; if (!c) return;
    const line = c.getBoundingClientRect().top + c.clientHeight * 0.55; let ui = null;
    c.querySelectorAll('[data-ui]').forEach(sec => { const r = sec.getBoundingClientRect(); if (r.top <= line && r.bottom > line) ui = +sec.getAttribute('data-ui'); });
    const secs = c.querySelectorAll('[data-ui]');
    if (secs.length && c.scrollTop + c.clientHeight >= c.scrollHeight - 140) ui = +secs[secs.length - 1].getAttribute('data-ui');
    if (ui === null && secs.length) ui = +secs[secs.length - 1].getAttribute('data-ui');
    if (ui !== null && ui !== this.state.bannerUnit) this.setState(s => ({ bannerUnit: ui, bannerFlip: !s.bannerFlip }));
  }

  // ---------- login ----------
  doLogin(e) {
    if (e && e.preventDefault) e.preventDefault();
    const { email, pwd, remember } = this.state.lg; const em = email.trim().toLowerCase();
    if (this.state.lg.loading) return;
    if (!em || em.indexOf('@') < 0 || !pwd) { this.setState({ lg: Object.assign({}, this.state.lg, { err: 'Digite seu e-mail e senha.' }) }); return; }
    this.setState({ lg: Object.assign({}, this.state.lg, { loading: true, err: '' }) });
    // Validado no TakeatHub (Supabase do HubProduto) — mesmo fluxo do Login.tsx.
    Hub.entrar(em, pwd).then(r => {
      if (r.erro) { this.setState({ lg: Object.assign({}, this.state.lg, { loading: false, err: r.erro }) }); this.toast(r.erro, 'circle-x', 'err'); return; }
      const pf = r.perfil, uid = r.user.id;
      // O progresso local é por pessoa: outro usuário no mesmo aparelho começa do zero.
      if (this._p.uid && this._p.uid !== uid) this._p = Object.assign(this.defaults(), { remembered: this._p.remembered });
      this.upd(p => {
        p.uid = uid; p.remembered = remember ? em : ''; p.role = r.role; p.leaderTeams = r.liderTimes || [];
        p.name = pf.full_name || this.E.nameFromEmail(em); if (pf.team) p.team = pf.team; if (pf.cargo) p.cargo = pf.cargo; if (pf.telefone) p.phone = pf.telefone;
        p.photo = pf.foto || null; p.equipped = pf.molduraAsset || null;
      });
      this.setState({ lg: Object.assign({}, this.state.lg, { loading: !pf.force_password_change, pwd: '' }) });
      if (pf.force_password_change) this.setState({ first: { uid, email: em, pwd: '', pwd2: '', team: pf.team || this._p.team || 'Suporte', teamDefinida: !!(pf.team && pf.team.trim()), birth: '', err: '' } });
      else this.loginDone(em);
    }).catch(() => this.setState({ lg: Object.assign({}, this.state.lg, { loading: false, err: 'Erro inesperado. Tente novamente.' }) }));
  }
  // Sessão do Hub já ativa (Mise aberta no domínio do TakeatHub): mesmo caminho do login, sem a tela de senha.
  entrarPeloHub() {
    Hub.entrarComSessaoDoHub().then(r => {
      if (!r || r.erro) return this.setState({ screen: 'login' });
      const pf = r.perfil, uid = r.user.id, em = (r.user.email || '').toLowerCase();
      if (this._p.uid && this._p.uid !== uid) this._p = Object.assign(this.defaults(), { remembered: this._p.remembered });
      this.upd(p => {
        p.uid = uid; p.role = r.role; p.leaderTeams = r.liderTimes || [];
        p.name = pf.full_name || this.E.nameFromEmail(em); if (pf.team) p.team = pf.team; if (pf.cargo) p.cargo = pf.cargo; if (pf.telefone) p.phone = pf.telefone;
        p.photo = pf.foto || null; p.equipped = pf.molduraAsset || null;
      });
      this.loginDone(em);
    }).catch(() => this.setState({ screen: 'login' }));
  }
  loginDone(em) {
    this.upd(p => { p.session = { email: em }; p.name = p.name || this.E.nameFromEmail(em); });
    const q = this._p, perfil = { name: q.name, team: q.team, cargo: q.cargo, phone: q.phone, photo: q.photo, role: q.role, equipped: q.equipped };
    this.setState({ first: null, temp: null, lg: Object.assign({}, this.state.lg, { loading: true }) });
    const pronto = this.carregarNuvem(perfil);
    Promise.race([pronto, new Promise(r => setTimeout(r, 6000))]).then(() => { this.setState({ lg: Object.assign({}, this.state.lg, { loading: false }) }); this.irDepoisDoLogin(); });
  }
  perfilParaP(pf) {
    const o = {}; if (pf.nome) o.name = pf.nome; if (pf.team) o.team = pf.team; if (pf.cargo) o.cargo = pf.cargo; if (pf.telefone) o.phone = pf.telefone;
    o.photo = pf.foto || null; o.equipped = pf.molduraAsset || null; return o;
  }
  // Tudo que o TakeatHub já sabe não é perguntado: a equipe define a persona e a trilha inicial,
  // e as preferências (meta, lembrete, dias) começam no padrão e mudam em Perfil → Configurações.
  irDepoisDoLogin() {
    const q = this._p, per = this.personaDaEquipe(q.team);
    if (!q.onboarded && per) this.upd(p => { p.onboarded = true; p.persona = per.id; p.objetivo = p.objetivo || 'chegando'; p.activeTrack = per.order[0]; });
    const scr = this._p.onboarded ? 'app' : 'onb';
    this.setState({ screen: scr, onb: { step: 0 } }, () => { if (scr === 'app') this.enterApp(); else this.carregarNivStatus(); });
  }
  personaDaEquipe(team) {
    const n = t => String(t || '').normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase().trim();
    return n(team) ? this.C.PERSONAS.find(x => x.grupo === 'Time Takeat' && n(x.nome) === n(team)) || null : null;
  }
  saveFirst() {
    const f = this.state.first; if (f.saving) return;
    const ep = Hub.erroSenha(f.pwd);
    if (ep) return this.setState({ first: Object.assign({}, f, { err: ep }) });
    if (f.pwd !== f.pwd2) return this.setState({ first: Object.assign({}, f, { err: 'As senhas não coincidem.' }) });
    const m = f.birth.match(/^(\d{2})\/(\d{2})\/(\d{4})$/), iso = m ? m[3] + '-' + m[2] + '-' + m[1] : '';
    if (!m || isNaN(new Date(iso).getTime())) return this.setState({ first: Object.assign({}, f, { err: 'Informe a data de nascimento no formato dd/mm/aaaa.' }) });
    this.setState({ first: Object.assign({}, f, { saving: true, err: '' }) });
    Hub.salvarPrimeiroAcesso(f.uid, { pwd: f.pwd, team: f.team, birthIso: iso, teamDefinida: f.teamDefinida }).then(r => {
      if (r.erro) return this.setState({ first: Object.assign({}, this.state.first, { saving: false, err: r.erro }) });
      this.upd(p => { if (!f.teamDefinida) p.team = f.team; });
      this.toast('Senha definida. Bem-vindo ao Mise en Place!');
      this.loginDone(f.email);
    });
  }
  genTemp(e) {
    if (e && e.preventDefault) e.preventDefault();
    const em = this.state.lg.email.trim().toLowerCase();
    if (!em || em.indexOf('@') < 0) return this.setState({ temp: { step: 'form', err: 'Digite um e-mail válido.' } });
    this.setState({ temp: { step: 'form', loading: true, err: '' } });
    // Senha temporária entregue no WhatsApp pela Hubia (edge reset-password, autoatendimento).
    Hub.gerarSenhaTemporaria(em).then(r => {
      if (r.erro) return this.setState({ temp: { step: 'form', err: r.erro } });
      this.setState({ temp: { step: 'sent', nome: r.nome, masc: r.masc } });
    });
  }

  // ---------- onboarding ----------
  onbSet(k, v) { this.setState(s => ({ onb: Object.assign({}, s.onb, { [k]: v }) })); this.beep('tap'); }
  onbNext() {
    const o = this.state.onb;
    // Só o nivelamento (obrigatório no 1º acesso / quem tem pouco XP, ou "Refazer" no Perfil): vai direto ao quiz.
    if (o.soNivel) { if (o.nivel) this.iniciarNivelamento(o.nivel); return; }
    if (o.step < 4) return this.setState({ onb: Object.assign({}, o, { step: o.step + 1 }) });
    const per = this.C.PERSONAS.find(x => x.id === o.persona) || this.C.PERSONAS[0];
    this.upd(p => { p.persona = per.id; p.objetivo = o.objetivo; p.goalMin = o.goalMin; p.reminder = o.reminder || p.reminder; p.onboarded = true; p.activeTrack = per.order[0];  p.tourPendente = true; });
    if (NIVEIS[o.nivel]) return this.iniciarNivelamento(o.nivel);
    if (o.nivel === 'teste') {
      const pool = this.E.shuffle(this.units(per.order[0])[0].qs.concat(this.units(per.order[1] || 'OPE')[0].qs)).slice(0, 8);
      this.beginLesson({ mode: 'placement', tid: per.order[0], key: null, ui: 0, qs: pool, title: 'Teste de nivelamento' });
    } else { this.setState({ screen: 'app', tab: 'learn' }, () => this.enterApp()); }
  }

  // ---------- nivelamento (servidor) ----------
  // Quem ainda deve o nivelamento (1º acesso ou menos de 100 XP) faz o quiz ao entrar. As perguntas vêm do
  // servidor SEM a resposta; cada alternativa é conferida lá (mise_avaliacao_*). Módulo com as 2 perguntas
  // certas fica concluído: o app marca as lições e o checkpoint dele e soma o XP dessas fases (vale na liga).
  async carregarNivStatus() {
    if (!this._demoAv && (this.demo || !this._p || !this._p.uid)) return null;
    const st = await this.av().nivelamentoStatus().catch(() => null);
    if (st) { this.nivStatus = st; this.aplicarNivelamento(st.modulos || []); }
    return st;
  }
  async verificarNivelamento() {
    if (this._nivVerificado) return; this._nivVerificado = true;
    const st = await this.carregarNivStatus();
    if (!st || !st.ativo || !st.obrigatorio) return;
    const s = this.state;
    if (s.screen === 'app' && !s.lesson) this.abrirNivelamento(true);
  }
  abrirNivelamento(obrigatorio) {
    if (!this.nivStatus || !this.nivStatus.ativo) return this.toast('O nivelamento não está disponível agora.', 'info');
    this.setState({ screen: 'onb', tour: null, popNode: null, onb: { step: 3, soNivel: true, obrigatorio: !!obrigatorio, nivel: null } });
  }
  trilhasDaPessoa() { const per = this.C.PERSONAS.find(x => x.id === this._p.persona) || this.C.PERSONAS[0]; return per.order.slice(); }
  // Marca as fases dos módulos que o servidor registrou como pulados (uma vez por módulo, em qualquer aparelho).
  aplicarNivelamento(mods) {
    const out = { xp: 0, n: 0, nomes: [] };
    if (!Array.isArray(mods) || !mods.length || !this._p) return out;
    this.upd(p => {
      p.nivAplicado = p.nivAplicado || {};
      mods.forEach(m => {
        const k = m.trilha_id + '|' + m.unidade; if (p.nivAplicado[k]) return;
        const units = this.E.getUnits(this.C, this.bank, this.atd, p, m.trilha_id) || [];
        const ui = units.findIndex(u => u.title === m.unidade); if (ui < 0) return; // perguntas ainda não carregadas: tenta de novo depois
        units[ui].nodes.forEach(nd => { if (nd.type === 'licao' || nd.type === 'checkpoint') p.done[nd.key] = true; });
        const id = 'cp:' + m.trilha_id + ':' + ui;
        if (!p.badges.find(b => b.id === id)) p.badges.push({ id, nome: units[ui].title, sub: 'Checkpoint · ' + this.trackInfo(m.trilha_id).nome + ' · nivelamento', icon: 'award', g: 'linear-gradient(145deg,#FFD66B,#FF8A3D)' });
        const v = Math.max(0, Number(m.xp) || 0), kd = this.tk();
        p.xpTotal += v; p.xpDay[kd] = (p.xpDay[kd] || 0) + v; p.league.xp += v; this.E.dayRec(p, kd).xp += v;
        p.nivAplicado[k] = true; out.xp += v; out.n++; out.nomes.push(m.unidade);
      });
    });
    return out;
  }
  // Pergunta do servidor no formato que a tela de lição usa (sem resposta e sem explicação).
  qDoServidor(x) { return { id: x.id, tipo: x.tipo, enunciado: x.enunciado, opcoes: x.opcoes, unidade: x.unidade, trilha: this.trackInfo(x.trilha_id).nome, trilha_id: x.trilha_id, licao: x.unidade, explicacao: '', fonte: '', resposta: undefined }; }
  metaAparelho() {
    let ap = null; try { ap = localStorage.getItem('mise-aparelho'); if (!ap) { ap = Math.random().toString(36).slice(2) + Date.now().toString(36); localStorage.setItem('mise-aparelho', ap); } } catch (e) {}
    return { plataforma: Hub.noHub ? 'hub' : Upd.ehNativo() ? 'app' : 'web', versao: (import.meta.env && import.meta.env.VITE_APP_VERSION) || null, aparelho: ap, ambiente: { webdriver: !!(navigator && navigator.webdriver) } };
  }
  async iniciarNivelamento(nivel) {
    if (this._nivIniciando) return; this._nivIniciando = true;
    this.setState({ onb: Object.assign({}, this.state.onb, { carregando: true }) });
    const r = await this.av().avaliacaoIniciar('nivelamento', nivel, this.trilhasDaPessoa(), this.metaAparelho());
    this._nivIniciando = false;
    this.setState({ onb: Object.assign({}, this.state.onb, { carregando: false }) });
    if (!r || r.ok === false) {
      this.toast((r && r.erro) || 'Não deu para abrir o nivelamento.', 'circle-x', 'err');
      if (r && r.codigo !== 'rede') this.goApp();
      return;
    }
    const qs = (r.perguntas || []).filter(x => !x.respondida).map(x => this.qDoServidor(x));
    if (!qs.length) return this.finishServidor({ mode: 'nivelamento', server: true, tentativa: r.tentativa_id, nivel, t0: Date.now(), total: 0 });
    const ms = Math.max(30000, new Date(r.prazo).getTime() - new Date(r.servidor_em).getTime() - 10000);
    this.beginLesson({ mode: 'nivelamento', server: true, tentativa: r.tentativa_id, nivel, tid: this.trilhasDaPessoa()[0], key: null, ui: 0, qs, title: 'Nivelamento · ' + NIVEIS[nivel].t, timed: nivel !== 'iniciante', prazoLocal: Date.now() + ms, explica: nivel === 'iniciante' });
  }
  async iniciarMestreServidor(tid, key, ui, title, fallback) {
    const r = await this.av().avaliacaoIniciar('mestre', tid, [], this.metaAparelho());
    if (!r || r.ok === false) {
      if (r && (r.codigo === 'pool_insuficiente' || r.codigo === 'desligado')) return fallback();
      return this.toast((r && r.erro) || 'Não deu para abrir o Desafio Mestre.', 'circle-x', 'err');
    }
    const qs = (r.perguntas || []).filter(x => !x.respondida).map(x => this.qDoServidor(x));
    this.beginLesson({ mode: 'mestre', server: true, tentativa: r.tentativa_id, tid, key, ui, qs, title, timed: true });
  }
  async checkServidor(naoSei, esgotou) {
    const { lesson: L, ex, fb } = this.state; if (fb || !L || L.enviando) return;
    const q = L.queue[L.idx], resp = naoSei ? null : ex.sel;
    if (!naoSei && resp == null) return;
    this.setState({ lesson: Object.assign({}, L, { enviando: true }) });
    const r = await this.av().avaliacaoResponder(L.tentativa, q.id, resp, { tempo_ms: Date.now() - L.qStart });
    const L2 = Object.assign({}, this.state.lesson, { enviando: false });
    if (!r || r.ok === false) {
      if (r && (r.codigo === 'tempo' || r.codigo === 'encerrada')) { this.toast(r.erro, 'timer'); return this.finishServidor(L2); }
      if (r && r.codigo === 'repetida') return this.setState({ lesson: L2 }, () => this.nextQ());
      this.toast((r && r.erro) || 'Sem conexão. Tente de novo.', 'wifi-off', 'err');
      return this.setState({ lesson: L2 });
    }
    const ok = !!r.acertou;
    // A tela pinta de verde a alternativa "certa": só se sabe qual é quando acertou (ou no Iniciante, que é tutorial).
    q.resposta = ok ? resp : (r.correta || undefined);
    if (r.explicacao) { q.explicacao = r.explicacao; q.fonte = r.fonte || ''; }
    L2.wrong = Object.assign({}, L2.wrong);
    if (ok) { L2.combo++; L2.maxCombo = Math.max(L2.maxCombo, L2.combo); L2.solved++; L2.correctFirst++; }
    else { L2.combo = 0; L2.wrong[q.id] = true; }
    this.beep(ok ? 'ok' : 'err');
    const titulo = ok ? null : r.correta ? 'Resposta correta:' : esgotou || r.esgotou ? 'O tempo acabou' : naoSei ? 'Tudo bem, segue o jogo' : 'Não foi dessa vez';
    const correct = ok ? '' : r.correta ? r.correta : L2.mode === 'nivelamento' ? 'Você encontra esse tema nas lições do módulo.' : 'Continue: o resultado sai no fim.';
    this.setState({ lesson: L2, fb: { ok, correct, timeout: !!(esgotou || r.esgotou), titulo } });
  }
  async finishServidor(L) {
    if (this._concluindo) return; this._concluindo = true;
    let r = await this.av().avaliacaoConcluir(L.tentativa);
    if (!r || r.ok === false) r = await this.av().avaliacaoConcluir(L.tentativa);
    this._concluindo = false;
    if (!r || r.ok === false) { this.toast((r && r.erro) || 'Não deu para fechar o resultado. Abra de novo em instantes.', 'circle-x', 'err'); return this.goApp(); }
    if (L.mode === 'mestre') return this.finish(Object.assign({}, L, { servidorOk: true, accServidor: r.acerto, aprovadoServidor: !!r.aprovado }));
    // Nivelamento: o servidor diz quais módulos ficaram concluídos; o app marca as fases e soma o XP delas.
    const ap = this.aplicarNivelamento(r.novos || []);
    if (this.nivStatus) this.nivStatus = Object.assign({}, this.nivStatus, { obrigatorio: false });
    const acc = r.total ? Math.round((r.acertos || 0) / r.total * 100) : 0;
    const nomes = ap.nomes.length ? ap.nomes : (r.novos || []).map(m => m.unidade);
    const sub = nomes.length
      ? 'Você pulou ' + nomes.length + (nomes.length === 1 ? ' módulo: ' : ' módulos: ') + nomes.join(', ') + (r.base ? ' — incluindo o básico da trilha.' : '.') + ' O certificado continua no Desafio Mestre.'
      : r.nivel === 'iniciante' ? 'Agora você conhece o básico. A trilha começa do início, no seu ritmo.' : 'Nenhum módulo ficou concluído desta vez. A trilha vai no seu ritmo — e dá para refazer pelo Perfil.';
    this.setState({ screen: 'end', end: { xp: ap.xp, acc, dur: Math.round((Date.now() - (L.t0 || Date.now())) / 1000), perfect: false, combo: 0, mode: 'nivelamento', pass: nomes.length > 0, title: L.title, key: null, sub }, endAnim: { xp: 0, acc: 0 }, post: [], particles: Date.now(), lesson: null, ex: null, fb: null });
    this.beep('done');
    const t0 = performance.now(), run = now => { const k = Math.min(1, (now - t0) / 600), e = 1 - Math.pow(1 - k, 3); this.setState({ endAnim: { xp: Math.round(ap.xp * e), acc: Math.round(acc * e) } }); if (k < 1) requestAnimationFrame(run); };
    requestAnimationFrame(run);
  }

  // ---------- lição ----------
  startNode(key) {
    const tid = key.split(':')[0], units = this.units(tid), nd = this.E.flat(units).find(n => n.key === key), u = units[nd.ui];
    this.setState({ popNode: null });
    if (nd.type === 'bau') return this.openChest('path', key);
    let qs, mode = nd.type, timed = false; const sh = this.E.shuffle;
    // Lição abaixo do mínimo (enquanto o mise-auto não completa a unidade): completa primeiro com a
    // PRÓPRIA unidade e só depois com unidades anteriores — para não repetir pergunta de outro tema.
    if (mode === 'licao') {
      qs = sh(nd.qs);
      const falta = this.E.MIN_LICAO - qs.length, fora = q => nd.qs.indexOf(q) < 0;
      if (falta > 0) qs = qs.concat(sh(u.qs.concat(u.extras || []).filter(fora)), sh([].concat.apply([], units.slice(0, nd.ui).map(x => x.qs)).filter(fora))).slice(0, this.E.MIN_LICAO);
      qs = qs.slice(0, Math.max(10, nd.qs.length));
    }
    else if (mode === 'checkpoint') { qs = sh(u.qs).slice(0, 8); if (qs.length < 6) qs = qs.concat(sh([].concat.apply([], units.map(x => x.qs)).filter(q => qs.indexOf(q) < 0)).slice(0, 6 - qs.length)); }
    else if (mode === 'caso') qs = nd.qs.slice();
    else if (mode === 'mestre') {
      qs = sh(nd.qs).slice(0, 10); timed = true;
      // Mestre conferido no servidor (perguntas próprias, gabarito fora do aparelho). Sem perguntas suficientes
      // na trilha ou desligado, segue o Mestre de antes.
      if (this.nivStatus && this.nivStatus.mestre_servidor && tid !== 'ATD' && tid !== 'DEV') {
        const antigo = () => this.beginLesson({ mode, tid, key, ui: nd.ui, qs, title: nd.title, timed });
        return this.iniciarMestreServidor(tid, key, nd.ui, nd.title, antigo);
      }
    }
    this.beginLesson({ mode, tid, key, ui: nd.ui, qs, title: nd.title, timed });
  }
  skipTest(tid, ui) { const u = this.units(tid)[ui]; this.setState({ popNode: null }); this.beginLesson({ mode: 'skip', tid, key: null, ui, qs: this.E.shuffle(u.qs).slice(0, 8), title: 'Teste para pular · ' + u.title }); }
  beginLesson(c) {
    const tip = c.mode === 'licao' ? c.qs.find(q => !this._p.hl[q.id]) : null;
    const L = Object.assign({ queue: c.qs.slice(), idx: 0, total: c.qs.length, solved: 0, wrong: {}, combo: 0, maxCombo: 0, comboBonus: 0, correctFirst: 0, t0: Date.now(), qStart: Date.now(), tip: tip || null, tipOpen: !!tip }, c);
    this.setState({ screen: 'lesson', lesson: L, ex: this.makeEx(L.queue[0]), fb: null, why: false, exitAsk: false, sheet: null });
  }
  makeEx(q) {
    const E = this.E, ex = { sel: null, num: '' }, t = q.tipo;
    if (E.numericAnswer(q)) ex.numeric = true;
    if (E.OPT_TYPES.indexOf(t) >= 0) ex.opts = t === 'verdadeiro_falso' ? ['Verdadeiro', 'Falso'] : E.shuffle(q.opcoes);
    if (t === 'ordenar_passos') { let o = E.shuffle(q.opcoes); if (JSON.stringify(o) === JSON.stringify(q.resposta)) o = o.slice().reverse(); ex.order = o; ex.drag = null; }
    if (t === 'combinar_pares') { ex.left = E.shuffle(q.opcoes.esquerda); ex.right = E.shuffle(Array.from(new Set(q.opcoes.direita))); ex.mL = {}; ex.mR = {}; ex.selL = null; ex.selR = null; ex.mistakes = 0; ex.bad = null; }
    if (t === 'onde_fica') { ex.tree = E.buildTree(q.opcoes); ex.path = []; }
    return ex;
  }
  setEx(patch) { this.setState(s => ({ ex: Object.assign({}, s.ex, patch) })); }
  correctText(q) {
    if (q.tipo === 'ordenar_passos') return q.resposta.map((x, i) => (i + 1) + '. ' + x).join('\n');
    if (q.tipo === 'combinar_pares') return Object.keys(q.resposta).map(a => a + ' → ' + q.resposta[a]).join('\n');
    return q.resposta;
  }
  check() {
    const { lesson: L, ex, fb } = this.state; if (fb || !L) return;
    if (L.server) return this.checkServidor(false);
    const q = L.queue[L.idx], t = q.tipo; let ok;
    if (t === 'ordenar_passos') ok = JSON.stringify(ex.order) === JSON.stringify(q.resposta);
    else if (t === 'combinar_pares') ok = ex.mistakes === 0;
    else if (ex.numeric) ok = this.E.digits(ex.num).length > 0 && this.E.digits(ex.num) === this.E.digits(q.resposta);
    else ok = ex.sel === q.resposta;
    this.resolve(ok, false);
  }
  resolve(ok, timeout) {
    const L = Object.assign({}, this.state.lesson), q = L.queue[L.idx], E = this.E;
    this.upd(p => {
      p.stats.ans++; if (ok) p.stats.ok++;
      p.qa = p.qa || {}; const qa = p.qa[q.id] || (p.qa[q.id] = [0, 0]); qa[0]++; if (ok) qa[1]++;
      const h0 = (p.hl[q.id] && p.hl[q.id].h) || 1; p.hl[q.id] = { h: ok ? Math.min(64, h0 * 2) : Math.max(.25, h0 / 2), t: this.today().getTime() };
      if (ok) { if ((L.mode === 'errors' || L.mode === 'review') && p.errors[q.id]) { delete p.errors[q.id]; E.dayRec(p, this.tk()).reviews++; } }
      else p.errors[q.id] = true;
      this.fsrsResposta(p, L, q, ok);
    });
    L.wrong = Object.assign({}, L.wrong);
    if (ok) { L.combo++; L.maxCombo = Math.max(L.maxCombo, L.combo); if (L.combo >= 5) L.comboBonus++; L.solved++; if (!L.wrong[q.id]) L.correctFirst++; }
    else { L.combo = 0; L.wrong[q.id] = true; if (E.NOREQ.indexOf(L.mode) < 0) L.queue = L.queue.concat([q]); }
    this.beep(ok ? 'ok' : 'err');
    this.setState({ lesson: L, fb: { ok, correct: this.correctText(q), timeout } });
  }
  nextQ() {
    const L = Object.assign({}, this.state.lesson); L.idx++;
    if (L.idx >= L.queue.length) return this.finish(L);
    L.qStart = Date.now();
    this.setState({ lesson: L, ex: this.makeEx(L.queue[L.idx]), fb: null, why: false });
  }
  ordDown(i, e) { if (this.state.fb) return; try { e.currentTarget.setPointerCapture(e.pointerId); } catch (x) {} this.drag = { i, y0: e.clientY, dy: 0 }; this.setEx({ drag: { i, dy: 0 } }); }
  ordMove(e) { if (!this.drag) return; this.drag.dy = e.clientY - this.drag.y0; this.setEx({ drag: { i: this.drag.i, dy: this.drag.dy } }); }
  ordUp() {
    if (!this.drag) return; const { i, dy } = this.drag; this.drag = null;
    const o = this.state.ex.order.slice(), to = Math.max(0, Math.min(o.length - 1, i + Math.round(dy / STEP)));
    const m = o.splice(i, 1)[0]; o.splice(to, 0, m); this.setEx({ order: o, drag: null });
  }
  tapPair(side, v) {
    const ex = this.state.ex, q = this.state.lesson.queue[this.state.lesson.idx]; if (this.state.fb) return;
    if (side === 'l' && ex.mL[v]) return; if (side === 'r' && ex.mR[v]) return;
    const selL = side === 'l' ? v : ex.selL, selR = side === 'r' ? v : ex.selR;
    if (!selL || !selR) { this.beep('tap'); return this.setEx({ selL, selR }); }
    if (q.resposta[selL] === selR) {
      const mL = Object.assign({}, ex.mL, { [selL]: true }), mR = Object.assign({}, ex.mR);
      if (Object.keys(q.resposta).filter(k => q.resposta[k] === selR).every(k => mL[k])) mR[selR] = true;
      this.beep('ok'); this.setEx({ mL, mR, selL: null, selR: null });
      if (ex.left.every(l => mL[l])) setTimeout(() => this.check(), 420);
    } else {
      this.beep('err'); this.setEx({ mistakes: ex.mistakes + 1, bad: { l: selL, r: selR }, selL: null, selR: null });
      setTimeout(() => this.setEx({ bad: null }), 420);
    }
  }
  openWhy() { this.setState({ why: true }); this.upd(p => { this.E.dayRec(p, this.tk()).whys++; }); }

  finish(L) {
    // Avaliação conferida no servidor: o resultado oficial vem de lá antes de fechar.
    if (L.server && !L.servidorOk) return this.finishServidor(L);
    const E = this.E, C = this.C, wrongN = Object.keys(L.wrong).length, perfect = wrongN === 0;
    const acc = L.servidorOk && L.accServidor != null ? L.accServidor : Math.round(L.correctFirst / L.total * 100);
    const dur = Math.round((Date.now() - L.t0) / 1000);
    let xp = 0, pass = true;
    if (L.mode === 'licao' || L.mode === 'caso') xp = 10 + (perfect ? 5 : 0);
    else if (L.mode === 'checkpoint') xp = 20;
    else if (L.mode === 'mestre') { pass = L.servidorOk ? !!L.aprovadoServidor : acc >= 80; xp = pass ? 40 : 10; }
    else if (L.mode === 'skip') { pass = acc >= 75; xp = pass ? 20 : 0; }
    else if (L.mode === 'placement') { pass = acc >= 75; xp = 0; }
    else xp = 5 + (perfect ? 3 : 0);
    xp += L.comboBonus;
    const before = E.conquests(this._p, { tracksDone: this.tracksDone() }).fams.map(f => f.level);
    const post = []; let gained = 0, missions = [];
    const units = L.tid ? this.units(L.tid) : [];
    this.upd(p => {
      const k = this.tk(), dr = E.dayRec(p, k), goal = E.goalXp(C, p), b4 = dr.xp;
      gained = this.addXp(p, xp);
      if (L.mode !== 'placement') { dr.lessons++; if (perfect) dr.perfect++; dr.maxCombo = Math.max(dr.maxCombo, L.maxCombo); const mk = k.slice(0, 7); p.month[mk] = (p.month[mk] || 0) + 1; }
      if (L.key && ['licao', 'caso', 'checkpoint'].indexOf(L.mode) >= 0) p.done[L.key] = true;
      if (L.sessao) p.fsrsFila = F.enfileirar(p.fsrsFila, { sessao: Object.assign({}, L.sessao, { concluida_em: new Date().toISOString(), perguntas: L.total, acertos: L.correctFirst, checagens: Object.keys(L.checagem || {}).length, duracao_s: dur }) });
      if (L.mode === 'mestre' && pass) p.done[L.key] = true;
      if (L.mode === 'skip' && pass) units[L.ui].nodes.forEach(n => { p.done[n.key] = true; });
      if (L.mode === 'placement') { p.levelTest = acc; if (pass) { const per = C.PERSONAS.find(x => x.id === p.persona) || C.PERSONAS[0]; per.order.slice(0, 2).forEach(t => this.E.getUnits(C, this.bank, this.atd, p, t)[0].nodes.forEach(n => { p.done[n.key] = true; })); } }
      if (L.mode === 'checkpoint') { const id = 'cp:' + L.tid + ':' + L.ui; if (!p.badges.find(b => b.id === id)) { const b = { id, nome: units[L.ui].title, sub: 'Checkpoint · ' + this.trackInfo(L.tid).nome, icon: 'award', g: 'linear-gradient(145deg,#FFD66B,#FF8A3D)' }; p.badges.push(b); post.push({ k: 'badge', b }); } }
      if (L.mode === 'mestre' && pass) { const c = { id: 'cert:' + L.tid, trilha: this.trackInfo(L.tid).nome, nome: p.name, data: this.today().toLocaleDateString('pt-BR', { day: '2-digit', month: 'long', year: 'numeric' }), acc }; p.certs = p.certs.filter(x => x.id !== c.id).concat([c]); post.push({ k: 'cert', c }); }
      if (L.mode !== 'placement') { const st = E.extendStreak(p, this.today()); if (st) { post.unshift(Object.assign({ k: 'streak' }, st)); this.marcoOfensiva(p, st); } }
      if (b4 < goal && dr.xp >= goal) post.push({ k: 'goal', goal });
      const mk = k.slice(0, 7);
      if ((p.month[mk] || 0) >= C.MONTH_GOAL && !p.badges.find(b => b.id === 'mes:' + mk)) { const b = { id: 'mes:' + mk, nome: 'Desafio do mês', sub: C.MONTH_GOAL + ' lições em ' + this.today().toLocaleDateString('pt-BR', { month: 'long' }), icon: 'target', g: 'linear-gradient(135deg,#FF2F6E,#A82743 55%,#5B1A8A)' }; p.badges.push(b); post.push({ k: 'badge', b }); }
      missions = this.checkMissions(p);
    });
    const after = E.conquests(this._p, { tracksDone: this.tracksDone() }).fams;
    after.forEach((f, i) => { if (f.level > before[i]) post.push({ k: 'badge', b: { nome: f.fam + ' · Nível ' + E.ROMAN[f.level], sub: f.levels[f.level - 1] + ' ' + f.un, icon: f.icon, g: 'linear-gradient(145deg,#7CC9FF,#5B6CFF)' } }); });
    this.pendingToasts = missions;
    this.setState({ screen: 'end', end: { xp: gained, acc, dur, perfect, combo: L.comboBonus, mode: L.mode, pass, title: L.title, key: L.key }, endAnim: { xp: 0, acc: 0 }, post, particles: Date.now(), lesson: null, ex: null, fb: null });
    this.beep('done');
    const t0 = performance.now(), run = now => { const k = Math.min(1, (now - t0) / 600), e = 1 - Math.pow(1 - k, 3); this.setState({ endAnim: { xp: Math.round(gained * e), acc: Math.round(acc * e) } }); if (k < 1) requestAnimationFrame(run); };
    requestAnimationFrame(run);
    if (gained > 0) setTimeout(() => this.fly('xp', this.center(this.endXpRef.current), 1), 720);
  }
  nextPost() {
    const post = this.state.post.slice();
    if (post.length) { const it = post.shift(); this.setState({ screen: 'post', postItem: it, post }); if (it.k === 'streak' && it.milestone) setTimeout(() => this.fly('coin', this.frameCenter(), 5), 900); return; }
    const key = this.state.end && this.state.end.key;
    this.goApp({ justDone: key || null });
  }
  tracksDone() { return this.trackList().filter(t => { const f = this.E.flat(this.units(t.id)); return f.length && f.every(n => this._p.done[n.key]); }).length; }
  // Marco de ofensiva (7/30/100/365 dias): o engine já somou os Takitos em p; aqui só vai pra fila do Hub.
  marcoOfensiva(p, st) { if (st && st.milestone) this.registrarGanho(p, st.milestone.t, 'marco:' + st.milestone.d + ':' + this.tk()); }

  // ---------- baú ----------
  openChest(source, key) {
    const r = Math.random(); let reward;
    if (r < .6) reward = { k: 'takitos', n: 10 + Math.floor(Math.random() * 3) * 10 };
    else if (r < .8) reward = this._p.streak.freezes < 2 ? { k: 'freeze' } : { k: 'takitos', n: 25 };
    else reward = { k: 'boost' };
    this.setState({ chest: { source, key, reward, at: Date.now() }, popNode: null });
  }
  collectChest() {
    const c = this.state.chest, rw = c.reward;
    this.upd(p => {
      if (rw.k === 'takitos') this.ganhar(p, rw.n, c.source === 'path' ? 'bau:' + c.key : 'bau-diario:' + this.tk()); else if (rw.k === 'freeze') p.streak.freezes = Math.min(2, p.streak.freezes + 1); else p.boostUntil = Date.now() + 15 * 60000;
      if (c.source === 'path') p.done[c.key] = true; else this.E.dayRec(p, this.tk()).chest = true;
    });
    this.setState({ chest: null, justDone: c.source === 'path' ? c.key : null });
    if (rw.k === 'takitos') setTimeout(() => this.fly('coin', this.frameCenter(), 5), 80);
    else this.toast(rw.k === 'freeze' ? 'Congelamento de ofensiva guardado' : 'XP em dobro ativo por 15 minutos', rw.k === 'freeze' ? 'snowflake' : 'zap', 'gold');
    if (c.source === 'path') setTimeout(() => this.setState({ justDone: null }), 1600);
  }

  // ---------- ligas ----------
  checkWeek() {
    const wk = this.E.dkey(this.E.monday(this.today()));
    if (!this._p.league.week) return this.upd(p => { p.league.week = wk; });
    if (this._p.league.week > wk) return this.upd(p => { p.league.week = wk; });
    if (this._p.league.week !== wk && !(this._p.uid && !this._rankOk)) this.endWeek();
  }
  endWeek() {
    const C = this.C, d = this.E.leagueData(C, this._p, this.today()), me = d.rows.find(r => r.me), idx = this._p.league.idx;
    let to = idx, res = 'stay';
    const z = this.E.leagueZones(C, d.rows, idx);
    if (me.rank <= z.up) { to = idx + 1; res = 'up'; }
    else if (me.rank > z.down) { to = idx - 1; res = 'down'; }
    const wk = this.E.dkey(this.E.monday(this.today()));
    this.upd(p => { p.league.idx = to; p.league.xp = 0; p.league.seed++; p.league.week = wk; if (res === 'up') this.ganhar(p, C.LEAGUE_RULES.premioPromocao, 'promocao:' + wk); });
    this.setState({ weekResult: { from: idx, to, res, rank: me.rank } });
  }

  // ---------- Revisão do dia (FSRS) — ver src/fsrs.js ----------
  fsrsAtivo() { return !!(this.fsrsCfg && this.fsrsCfg.ativo) && (!this.demo || !!this._fsrsDemo) && !!(this._p && this._p.uid); }
  // ?demo=revisao (só dev): 24 perguntas do banco embutido vistas há 3 a 40 dias, metade em cada metade do experimento.
  demoRevisao(p) {
    const agora = Date.now(), qs = this.bank.filter(q => q.tipo === 'multipla_escolha' || q.tipo === 'verdadeiro_falso').slice(0, 24), controle = [];
    qs.forEach((q, i) => { const t = agora - (3 + i * 1.6) * this.E.DAY; p.hl[q.id] = { h: 1, t }; p.fsrs[q.id] = F.responder(null, i % 5 !== 0, t).cartao; if (i % 2) controle.push(q.id); });
    this._fsrsDemo = true; this.aplicarFsrsCfg({ ativo: true, retencao: 0.9, por_dia: 8, checagem: 2, checagem_dias: 14, controle });
  }
  aplicarFsrsCfg(cfg) {
    this.fsrsCfg = cfg && cfg.ativo ? Object.assign({}, cfg, { controle: new Set(cfg.controle || []) }) : { ativo: false };
  }
  async carregarFsrs() {
    if (!this.fsrsCfg) { try { this.aplicarFsrsCfg(JSON.parse(localStorage.getItem(LSF) || 'null')); } catch (e) {} }
    const st = await Hub.fsrsStatus().catch(() => null);
    if (st) { this.aplicarFsrsCfg(st); try { localStorage.setItem(LSF, JSON.stringify(st)); } catch (e) {} }
    if (!this.fsrsAtivo()) return this.setState({ fsrsEm: Date.now() });
    // Quem já respondia (meia-vida em p.hl) começa com as perguntas que já viu.
    const p = this._p, faltam = Object.keys(p.hl || {}).filter(id => !(p.fsrs || {})[id]);
    if (!faltam.length) return this.setState({ fsrsEm: Date.now() });
    this.upd(q => {
      const novos = F.iniciarDeHl(q.fsrs, q.hl, q.errors, this.fsrsCfg.retencao);
      faltam.forEach(id => { if (novos[id]) q.fsrsFila = F.enfileirar(q.fsrsFila, { questaoId: id, cartao: novos[id] }); });
      q.fsrs = novos;
    });
  }
  revisaoHoje() {
    return F.revisaoDoDia(this._p.fsrs || {}, this.fsrsCfg.controle, this.today().getTime(), this.fsrsCfg, id => !!this.qById(id));
  }
  startRevisaoDia() {
    const rd = this.revisaoHoje(), ids = rd.revisao.concat(rd.checagem), qs = ids.map(id => this.qById(id)).filter(Boolean);
    if (!qs.length) return this.toast('Nada para revisar agora. Volte amanhã.', 'circle-check');
    const checagem = {}; rd.checagem.forEach(id => { checagem[id] = true; });
    const sessao = { id: F.uuid(), iniciada_em: new Date().toISOString() };
    this.upd(p => { p.fsrsFila = F.enfileirar(p.fsrsFila, { sessao: Object.assign({ perguntas: qs.length }, sessao) }); });
    this.beginLesson({ mode: 'review', tid: null, key: null, ui: 0, qs: this.E.shuffle(qs), title: 'Revisão do dia', checagem, sessao });
  }
  // Cada 1ª resposta do dia de uma pergunta do banco atualiza o FSRS e entra na fila da métrica.
  fsrsResposta(p, L, q, ok) {
    if (!this.fsrsAtivo() || L.server || q.hubia || F.FORA_DO_FSRS.indexOf(L.mode) >= 0) return;
    const agora = this.today().getTime(), chec = !!(L.checagem && L.checagem[q.id]);
    p.fsrs = p.fsrs || {};
    const r = F.responder(p.fsrs[q.id], ok, agora, this.fsrsCfg.retencao);
    if (!r) return;
    p.fsrs[q.id] = r.cartao;
    p.fsrsFila = F.enfileirar(p.fsrsFila, { questaoId: q.id, cartao: r.cartao, resposta: {
      id: F.uuid(), questao_id: q.id, respondido_em: new Date(agora).toISOString(), origem: F.origemDe(L.mode, chec), acerto: !!ok, nota: ok ? 3 : 1,
      tempo_ms: L.qStart ? Date.now() - L.qStart : null, chance_prevista: r.chancePrevista, dias_desde: r.diasDesde, sessao_id: L.sessao ? L.sessao.id : null,
    } });
  }
  async enviarFsrs() {
    for (let i = 0; i < 5 && !F.filaVazia(this._p.fsrsFila); i++) {
      const lt = F.lote(this._p.fsrsFila), r = await Hub.fsrsRegistrar(lt);
      if (!r.ok && r.codigo !== 'dados') return; // sem conexão: fica na fila
      this._p.fsrsFila = F.semEnviados(this._p.fsrsFila, lt.tira, lt);
    }
  }

  // ---------- praticar ----------
  dueQs() {
    if (this.fsrsAtivo()) { const rd = this.revisaoHoje(); return rd.revisao.concat(rd.checagem).map(id => this.qById(id)).filter(Boolean); }
    const now = this.today().getTime(), hl = this._p.hl;
    return Object.keys(hl).map(id => ({ id, pr: Math.pow(2, -((now - hl[id].t) / this.E.DAY) / hl[id].h) })).filter(x => x.pr < .5).sort((a, b) => a.pr - b.pr).map(x => this.qById(x.id)).filter(Boolean);
  }
  startPractice(mode, qs, title) {
    if (mode === 'review' && this.fsrsAtivo()) return this.startRevisaoDia();
    if (!qs.length) return this.toast(mode === 'errors' ? 'Nenhum erro para revisar. Mandou bem!' : 'Nada para revisar agora.', 'circle-check');
    this.beginLesson({ mode, tid: null, key: null, ui: 0, qs: this.E.shuffle(qs).slice(0, 8), title });
  }
  practiceTerm(term) {
    const t = term.toLowerCase();
    const qs = this.bank.filter(q => (q.enunciado + ' ' + JSON.stringify(q.opcoes)).toLowerCase().indexOf(t) >= 0);
    if (qs.length < 3) return this.toast('Ainda não há questões suficientes para "' + term + '".', 'search', 'err');
    this.startPractice('term', qs, 'Praticar · ' + term);
  }
  newBatch(f) { const g = this.C.GLOSSARY, items = []; for (let i = 0; i < 4; i++) items.push(g[(f.ptr + i) % g.length]); return Object.assign(f, { items, left: this.E.shuffle(items.map(x => x.t)), right: this.E.shuffle(items.map(x => x.s)), mL: {}, selL: null, selR: null, bad: null, ptr: f.ptr + 4 }); }
  startFlash() { const f = this.newBatch({ end: Date.now() + 60000, score: 0, ptr: Math.floor(Math.random() * 19), done: false }); this.setState({ screen: 'flash', flash: f }); }
  tapFlash(side, v) {
    const f = Object.assign({}, this.state.flash); if (f.done) return;
    if (side === 'l') { if (f.mL[v]) return; f.selL = v; } else { if (Object.values(f.mL).indexOf(v) >= 0) return; f.selR = v; }
    if (f.selL && f.selR) {
      const it = f.items.find(x => x.t === f.selL);
      if (it.s === f.selR) { f.mL = Object.assign({}, f.mL, { [f.selL]: f.selR }); f.score++; this.beep('ok'); if (Object.keys(f.mL).length === 4) setTimeout(() => this.setState(s => ({ flash: this.newBatch(Object.assign({}, s.flash)) })), 380); }
      else { f.bad = { l: f.selL, r: f.selR }; this.beep('err'); setTimeout(() => this.setState(s => ({ flash: Object.assign({}, s.flash, { bad: null }) })), 400); }
      f.selL = null; f.selR = null;
    } else this.beep('tap');
    this.setState({ flash: f });
  }
  finishFlash() {
    const f = this.state.flash, rec = f.score > this._p.flashRecord; let xp = 0, st = null;
    this.upd(p => { xp = this.addXp(p, Math.min(20, f.score)); if (rec) p.flashRecord = f.score; if (f.score > 0) { st = this.E.extendStreak(p, this.today()); this.marcoOfensiva(p, st); } this.pendingToasts = this.checkMissions(p); });
    this.setState({ flash: Object.assign({}, f, { done: true, rec, xp }) });
    this.beep('done');
  }

  // ---------- líder ----------
  leaderUpd(fn) { this.upd(p => { const t = p.team; p.leader.rules[t] = p.leader.rules[t] || []; fn(p, t); }); }
  hubiaDraft(rule, tipo) {
    if (tipo === 'verdadeiro_falso') return { tipo, enunciado: 'Pela regra "' + rule.titulo + '": ' + rule.ruim.replace(/\.$/, '') + ' é uma resposta adequada.', opts: ['Verdadeiro', 'Falso', '', ''], correct: 1, explicacao: rule.descricao, hubia: true };
    return { tipo, enunciado: (tipo === 'diagnostico' ? 'Mensagem do atendente: "' + rule.ruim + '" O que essa mensagem viola?' : 'Um cliente traz um caso ligado a "' + rule.titulo + '". Qual resposta segue a regra do time?'),
      opts: tipo === 'diagnostico' ? ['A regra "' + rule.titulo + '"', 'Encerramento', 'CSAT', 'Nenhuma regra'] : [rule.bom, rule.ruim, 'Responder depois, sem avisar o cliente.', 'Encaminhar para outro time sem contexto.'], correct: 0, explicacao: rule.descricao, hubia: true };
  }
  addQuestion() {
    const f = this.state.qForm, vf = f.tipo === 'verdadeiro_falso';
    const opts = vf ? ['Verdadeiro', 'Falso'] : f.opts.map(x => x.trim()).filter(Boolean);
    if (!f.enunciado.trim() || opts.length < 2 || !opts[f.correct]) return this.toast('Preencha o enunciado, as alternativas e a correta.', 'triangle-alert', 'err');
    this.leaderUpd((p, t) => { const r = p.leader.rules[t].find(x => x.id === f.ruleId); r.questions.push({ id: r.id + '-q' + (r.questions.length + 1), trilha: 'Regras de Atendimento', unidade: r.titulo, licao: r.titulo, tipo: f.tipo, dificuldade: 4, enunciado: f.enunciado.trim(), opcoes: opts, resposta: opts[f.correct], explicacao: f.explicacao.trim() || r.descricao, fonte: r.wiki || 'Regra do time ' + t }); });
    this.setState({ qForm: null }); this.toast('Questão adicionada ao rascunho');
  }

  renderVals() {
    const s = this.state;
    const F = { frameRef: this.frameRef, isSplash: true, isLogin: false, isOnb: false, isApp: false, isLesson: false, isEnd: false, isPost: false, isFlash: false, showHeader: false, offlineBanner: false, tempOpen: false, firstOpen: false, sheetOpen: false, chestOpen: false, wrOpen: false, exitAsk: false, resetAsk: false, toasts: [], flyersEl: null, particlesEl: null, stopProp: e => e.stopPropagation(), closePop: () => { if (this.state.popNode) this.setState({ popNode: null }); } };
    if (!s.ready || !s.p) return F;
    this.E.me = { name: s.p.name, photo: s.p.photo || null };
    const v = Object.assign(F, { isSplash: s.screen === 'splash', isLogin: s.screen === 'login', isOnb: s.screen === 'onb', isApp: s.screen === 'app', isLesson: s.screen === 'lesson', isEnd: s.screen === 'end', isPost: s.screen === 'post', isFlash: s.screen === 'flash' });
    v.showHeader = (s.screen === 'app' && !s.sub) || s.screen === 'end' || s.screen === 'post';
    v.offlineBanner = (!s.online || s.p.offlineSim) && s.screen === 'app';
    v.toasts = s.toasts; v.printCert = !!s.certView; if (s.certView) Object.assign(v, this.vCert());
    v.flyersEl = this.flyersEl(); v.particlesEl = this.particlesEl();
    Object.assign(v, this.vHeader(), this.vOverlays());
    if (v.isLogin) Object.assign(v, this.vLogin());
    if (v.isOnb) Object.assign(v, this.vOnb());
    if (v.isApp) Object.assign(v, this.vApp());
    if (v.isLesson) Object.assign(v, this.vLesson());
    if (v.isEnd) Object.assign(v, this.vEnd());
    if (v.isPost) Object.assign(v, this.vPost());
    if (v.isFlash) Object.assign(v, this.vFlash());
    Object.assign(v, this.vUpdate());
    return v;
  }

  flyersEl() {
    const h = React.createElement;
    return h('div', { style: { position: 'absolute', inset: 0, pointerEvents: 'none', zIndex: 120 } }, this.state.flyers.map(f => h('div', { key: f.id, style: { position: 'absolute', left: f.x - 14, top: f.y - 14, '--dx': f.dx + 'px', animation: 'flyX .7s cubic-bezier(.45,0,.55,1) ' + f.delay + 'ms both' } },
      h('div', { style: { '--dy': f.dy + 'px', animation: 'flyY .7s cubic-bezier(.5,-0.9,.7,1) ' + f.delay + 'ms both' } },
        f.kind === 'coin' ? h('img', { src: './src/assets/takitos.png', width: 28, height: 28, style: { display: 'block', filter: 'drop-shadow(0 4px 8px rgba(0,0,0,.25))' } })
          : h('span', { style: { width: 30, height: 30, borderRadius: 10, background: AMBER, color: '#fff', display: 'grid', placeItems: 'center', boxShadow: '0 6px 14px hsl(40 92% 46% / .45)' } }, h('lu-icon', { name: 'zap', size: '18', fill: 'currentColor' }))))));
  }
  particlesEl() {
    if (!this.state.particles || (this.state.screen !== 'end')) return null;
    const h = React.createElement, cols = ['#ff2419', '#df1c0d', '#8f1109', 'hsl(40 92% 46%)', 'hsl(150 55% 40%)', 'hsl(212 72% 48%)', 'hsl(262 52% 55%)'], r = this.E.seeded(this.state.particles);
    const items = []; for (let i = 0; i < 34; i++) { const a = r() * Math.PI * 2, d = 90 + r() * 170; items.push(h('span', { key: i, style: { position: 'absolute', left: '50%', top: '30%', width: 6 + r() * 6, height: 10 + r() * 8, borderRadius: r() > .5 ? 999 : 2, background: cols[i % cols.length], '--px': Math.cos(a) * d + 'px', '--py': Math.sin(a) * d + 120 * r() + 'px', '--pr': (r() * 720 - 360) + 'deg', animation: 'particle 1.3s cubic-bezier(.16,1,.3,1) ' + (r() * 150) + 'ms both' } })); }
    return h('div', { key: this.state.particles, style: { position: 'absolute', inset: 0, pointerEvents: 'none', overflow: 'hidden', zIndex: 5 } }, items);
  }
  num(v, ts) { return React.createElement('span', { key: 'n' + ts, style: { display: 'inline-block', animation: ts ? 'bump .45s cubic-bezier(.34,1.56,.64,1)' : 'none' } }, v); }

  vHeader() {
    const p = this._p, s = this.state, E = this.E, k = this.tk(), xpT = p.xpDay[k] || 0, goal = E.goalXp(this.C, p), sn = E.streakNow(p, this.today()), done = p.streak.last === k;
    const ti = this.trackInfo(p.activeTrack);
    return {
      trackIcon: ti.icon, trackShort: ({ ATD: 'Atendimento', FUN: 'Fundamentos', OPE: 'Operação', KDS: 'Cozinha', DEL: 'Delivery', GES: 'Gestor', CAN: 'Canais', DIS: 'Dispositivos', INT: 'Integrações', FIS: 'Fiscal', MUL: 'Multilojas', CLU: 'Clube', BAS: 'Bastidores' })[ti.id] || ti.nome,
      openTracks: () => this.setState({ sheet: 'tracks' }), openStreak: () => this.setState({ sheet: 'streak' }), openCoins: () => this.setState({ sheet: 'coins' }),
      streakN: sn, flameColor: done ? 'hsl(28 90% 52%)' : 'hsl(0 0% 62%)', flameFill: done ? 'hsl(40 92% 56%)' : 'none',
      xpRef: this.xpRef, coinRef: this.coinRef, coinImgRef: this.coinImgRef, xpNumEl: this.num(xpT, s.bumpXp), coinNumEl: this.num(p.takitos, s.bumpCoin),
      goalXp: goal, ringDash: Math.min(100, Math.round(xpT / goal * 100)) + ' 100', ringColor: xpT >= goal ? GREEN : AMBER, boostOn: Date.now() < p.boostUntil
    };
  }

  vLogin() {
    const lg = this.state.lg, set = (k) => (e) => this.setState({ lg: Object.assign({}, this.state.lg, { [k]: e.target.value, err: '' }) });
    return {
      lgEmail: lg.email, lgPwd: lg.pwd, onLgEmail: set('email'), onLgPwd: set('pwd'), lgPwdType: lg.show ? 'text' : 'password', lgEyeIcon: lg.show ? 'eye-off' : 'eye',
      toggleShow: () => this.setState({ lg: Object.assign({}, lg, { show: !lg.show }) }), lgRemember: lg.remember, toggleRemember: () => this.setState({ lg: Object.assign({}, lg, { remember: !lg.remember }) }),
      onLogin: e => this.doLogin(e), lgLoading: lg.loading, lgIdle: !lg.loading, hasLgErr: !!lg.err, lgErr: lg.err, onForgot: () => this.setState({ temp: { step: 'form', err: '' } }),
      onLgKey: e => { if (e.key === 'Enter') this.doLogin(e); }
    };
  }

  vOnb() {
    const o = this.state.onb, C = this.C;
    const card = (sel) => ({ bd: sel ? RED : BD, bg: sel ? REDT2 : '#fff', fg: sel ? RED : INK, tr: sel ? 'translateY(-2px) scale(1.02)' : 'none' });
    const can = [!!o.persona, !!o.objetivo, !!o.goalMin, !!o.nivel, true][o.step] && !o.carregando;
    // Nivelamento ligado: os 3 níveis (o quiz roda no servidor). Desligado: as opções de antes.
    const comNiv = !!(this.nivStatus && this.nivStatus.ativo);
    const niveis = comNiv
      ? Object.keys(NIVEIS).map(id => ({ id, t: NIVEIS[id].t + ' · ' + NIVEIS[id].sub, d: NIVEIS[id].d, icon: NIVEIS[id].icon }))
      : [{ id: 'basico', t: 'Começar do básico', d: 'Sigo a trilha desde a primeira lição.', icon: 'sprout' }, { id: 'teste', t: 'Fazer o teste rápido', d: '8 questões. Com 75% ou mais, as unidades básicas ficam concluídas.', icon: 'gauge' }];
    const sairNiv = () => { this.setState({ onb: { step: 0 } }); this.goApp(); };
    return {
      onb3Titulo: comNiv ? 'Qual é o seu nível com a Takeat?' : 'Por onde começar?',
      onb3Sub: comNiv ? (o.obrigatorio ? 'Antes de começar, um quiz rápido mostra o que você já sabe. O que você dominar fica concluído, com o XP das fases. O certificado continua no Desafio Mestre.' : 'Um quiz rápido mostra o que você já sabe. Refazer só soma: o que você já concluiu continua valendo.') : 'Se você já usa a Takeat, o teste pula o que você já sabe.',
      onbPct: o.soNivel ? '100%' : ((o.step + 1) / 5 * 100) + '%', onbCanBack: o.step > 0 && !(o.soNivel && o.obrigatorio), onbDisabledBack: o.step === 0 || (o.soNivel && o.obrigatorio),
      onbBack: () => o.soNivel ? sairNiv() : this.setState({ onb: Object.assign({}, o, { step: o.step - 1 }) }),
      onb0: o.step === 0, onb1: o.step === 1, onb2: o.step === 2, onb3: o.step === 3, onb4: o.step === 4,
      personasInt: C.PERSONAS.filter(x => x.grupo === 'Time Takeat').map(x => Object.assign({ nome: x.nome, icon: x.icon, onClick: () => this.onbSet('persona', x.id) }, card(o.persona === x.id))),
      personasCli: C.PERSONAS.filter(x => x.grupo === 'Restaurante').map(x => Object.assign({ nome: x.nome, icon: x.icon, onClick: () => this.onbSet('persona', x.id) }, card(o.persona === x.id))),
      objetivos: C.OBJETIVOS.map(x => Object.assign({ t: x.t, d: x.d, onClick: () => this.onbSet('objetivo', x.id) }, card(o.objetivo === x.id))),
      goals: C.GOALS.map(x => Object.assign({ t: x.min + ' min por dia', d: x.t, xp: x.xp + ' XP', onClick: () => this.onbSet('goalMin', x.min) }, card(o.goalMin === x.min))),
      niveis: niveis.map(x => Object.assign({ t: x.t, d: x.d, icon: x.icon, onClick: () => this.onbSet('nivel', x.id) }, card(o.nivel === x.id))),
      reminders: C.REMINDERS.slice(0, 4).map(r => { const sel = !o.custom && (o.reminder || '09:30') === r; return { t: r, onClick: () => this.setState(s => ({ onb: Object.assign({}, s.onb, { reminder: r, custom: false }) })), bg: sel ? RED : '#fff', fg: sel ? '#fff' : MUT, bd: sel ? RED : BD }; }),
      onbCustom: !!o.custom, onbCustomBg: o.custom ? RED : '#fff', onbCustomFg: o.custom ? '#fff' : MUT, onbCustomBd: o.custom ? RED : BD, onOnbCustom: () => this.setState(s => ({ onb: Object.assign({}, s.onb, { custom: true, reminder: s.onb.reminder || '09:30' }) })),
      onbTime: this.timeVals(o.reminder || '09:30', v => this.setState(s => ({ onb: Object.assign({}, s.onb, { reminder: v }) }))),
      onbNext: () => this.onbNext(), onbDisabled: !can, onbBtnBg: can ? RED : 'hsl(0 0% 88%)', onbBtnFg: can ? '#fff' : 'hsl(0 0% 62%)', onbBtnSh: can ? '0 4px 0 hsl(6 100% 34%)' : '0 4px 0 hsl(0 0% 80%)',
      onbNextLabel: o.carregando ? 'Preparando o quiz…' : o.soNivel ? 'Começar o quiz' : o.step === 4 ? (o.nivel === 'teste' || NIVEIS[o.nivel] ? 'Começar o quiz' : 'Começar a trilha') : 'Continuar',
      onAllowNotif: () => { try { window.Notification && Notification.requestPermission(); } catch (e) {} this.toast('Lembrete combinado para ' + (o.reminder || '09:30'), 'bell'); }
    };
  }

  vApp() {
    const s = this.state, p = this._p, t = s.tab;
    const tabs = [['learn', 'Aprender', 'book-open'], ['practice', 'Praticar', 'dumbbell'], ['league', 'Ligas', 'trophy'], ['missions', 'Missões', 'target'], ['profile', 'Perfil', 'user']].map(([id, label, icon]) => ({ label, icon, onClick: () => this.setTab(id), fg: t === id ? RED : MUT, bg: t === id ? REDT : 'transparent', fw: t === id ? 700 : 500 }));
    const v = { ...this.vHubSaida(), tabs, isTabs: !s.sub, isSub: !!s.sub, tabLearn: t === 'learn' && !s.sub, tabPractice: t === 'practice' && !s.sub, tabLeague: t === 'league' && !s.sub, tabMissions: t === 'missions' && !s.sub, tabProfile: t === 'profile' && !s.sub,
      subLoja: s.sub === 'loja', subGloss: s.sub === 'gloss', subLeader: s.sub === 'leader', subDevEdit: s.sub === 'devEdit', subResgate: s.sub === 'resgate', subCert: s.sub === 'cert', subReports: s.sub === 'reports', subReportView: s.sub === 'reportView', subTitle: { reportView: 'Feedback', reports: 'Meus feedbacks', loja: 'Loja', gloss: 'Glossário', leader: 'Modo líder', devEdit: 'Trilha Dev', desempenho: 'Meu desempenho', resgate: 'Resgatar código', cert: 'Certificado' }[s.sub] || '', subCrumb: { reportView: 'Perfil / Meus feedbacks', reports: 'Perfil / Feedback', loja: 'Hub / Loja', gloss: 'Praticar / Glossário', leader: 'Atendimento / ' + p.team, devEdit: 'Trilhas / Desenvolvimento', desempenho: 'Perfil / Relatório', resgate: 'Hub / Loja', cert: 'Perfil / Certificados' }[s.sub] || '', subIcon: { reportView: 'message-square-text', reports: 'message-square-text', loja: 'store', gloss: 'book-text', leader: 'shield', devEdit: 'code', desempenho: 'trending-up', resgate: 'gift', cert: 'file-badge' }[s.sub] || 'store', onSubBack: () => { if (s.sub === 'reportView') return this.setState({ sub: 'reports', repLight: null }); if (s.sub === 'cert' && s.certFrom === 'post') return this.setState({ screen: 'post', sub: null, certFull: false }); this.setState({ sub: s.sub === 'resgate' ? 'loja' : null, certFull: false }); } };
    if (v.tabLearn) Object.assign(v, this.vLearn());
    if (v.tabPractice) Object.assign(v, this.vPractice());
    if (v.tabLeague) Object.assign(v, this.vLeague());
    if (v.tabMissions) Object.assign(v, this.vMissions());
    if (v.tabProfile) { Object.assign(v, this.vProfile()); if (v.isPtR) Object.assign(v, this.vDesempenho()); }
    if (v.subLoja) Object.assign(v, this.vLoja());
    if (v.subGloss) Object.assign(v, this.vGloss());
    if (v.subLeader) Object.assign(v, this.vLeader());
    if (v.subDevEdit) Object.assign(v, this.vDevEdit());
    if (v.subResgate) Object.assign(v, this.vResgate());
    if (v.subCert) Object.assign(v, this.vCert());
    if (v.subReports) Object.assign(v, this.vReports());
    if (v.subReportView) Object.assign(v, this.vReportView());
    return v;
  }

  vLearn() {
    const s = this.state, p = this._p, E = this.E, tid = p.activeTrack, units = this.units(tid), flat = E.flat(units), curI = flat.findIndex(n => !p.done[n.key]);
    const COLOR = { licao: [RED, 'hsl(6 100% 34%)'], caso: [RED, 'hsl(6 100% 34%)'], bau: [AMBER, 'hsl(36 90% 34%)'], checkpoint: [AMBER, 'hsl(36 90% 34%)'], mestre: ['#8f1109', '#560803'] };
    const ICON = { licao: 'book-open', bau: 'gift', caso: 'message-square', checkpoint: 'award', mestre: 'trophy' };
    // Quem está em cada fase: o usuário logado (TakeatHub) na fase atual + colegas mock (C.PEOPLE),
    // distribuídos de forma estável pela trilha (mais gente no começo).
    const occ = {};
    if (flat.length) {
      if (Array.isArray(this.C.REAL_RANK)) {
        // Colegas reais: a fase atual de cada um nesta trilha vem da nuvem (mise_progresso.posicoes).
        this.C.REAL_RANK.forEach(x => { const k = x.pos && x.pos[tid]; if (k) (occ[k] = occ[k] || []).push({ nome: x.nome, team: x.team, mold: x.mold }); });
      } else {
        this.C.PEOPLE.forEach(x => { const r = E.seeded('pos:' + x[0] + ':' + tid), gi = Math.min(flat.length - 1, Math.floor(Math.pow(r(), 1.7) * flat.length * 0.85)); (occ[flat[gi].key] = occ[flat[gi].key] || []).push({ nome: x[0], team: x[1], mold: x[2] }); });
      }
      if (curI >= 0) (occ[flat[curI].key] = occ[flat[curI].key] || []).unshift({ nome: p.name || 'Você', team: p.team, mold: p.equipped, me: true });
    }
    const uv = units.map(u => {
      const unitDone = u.nodes.every(n => p.done[n.key]), first = flat.indexOf(u.nodes[0]), locked = curI >= 0 && first > curI;
      const rows = u.nodes.map((n, ni) => {
        const gi = flat.indexOf(n), done = !!p.done[n.key], cur = gi === curI, lockedN = !done && !cur, x = OFF[ni % 8], cx = Math.max(-58, Math.min(58, x));
        const [col, dark] = COLOR[n.type], open = s.popNode === n.key;
        const nEx = n.type === 'licao' ? Math.min(10, Math.max(6, n.qs.length)) : n.type === 'checkpoint' ? Math.min(8, Math.max(6, n.qs.length)) : n.type === 'mestre' ? 10 : n.type === 'caso' ? n.qs.length : 0;
        const crowd = occ[n.key] || [], extra = crowd.length - 2;
        const popSub = n.type === 'bau' ? 'Abra para ganhar uma recompensa' : n.type === 'mestre' ? nEx + ' exercícios · 30 s cada · sem dicas · +40 XP' : nEx + ' exercícios · +' + E.NODE_XP[n.type] + ' XP';
        return {
          key: n.key, dc: cur ? '1' : '0', left: 'calc(50% + ' + x + 'px - 34px)', isCur: cur, notCur: !cur,
          bg: lockedN ? 'hsl(0 0% 90%)' : done && n.type === 'bau' ? 'hsl(40 70% 90%)' : col, sh: '0 6px 0 ' + (lockedN ? 'hsl(0 0% 80%)' : done && n.type === 'bau' ? 'hsl(40 50% 76%)' : dark), fg: lockedN ? 'hsl(0 0% 62%)' : done && n.type === 'bau' ? 'hsl(36 75% 42%)' : '#fff',
          icon: done ? (n.type === 'bau' ? 'package-open' : 'check') : ICON[n.type], anim: n.key === s.justDone ? 'nodePop .55s cubic-bezier(.34,1.56,.64,1)' : (cur && s.justDone ? 'flipIn .6s .4s cubic-bezier(.16,1,.3,1) both' : 'none'),
          onClick: e => { e.stopPropagation(); if (open) return this.setState({ popNode: null }); this.openPop(n.key, e.currentTarget, ni === 0 && !unitDone && !done); }, z: open ? 40 : 'auto', hasLine: ni > 0,
          popPos: open && s.popUp ? 'bottom:94px' : 'top:92px', caretPos: open && s.popUp ? 'bottom:-7px' : 'top:-7px', popOrigin: open && s.popUp ? 'bottom center' : 'top center',
          skipBg: lockedN ? 'hsl(0 0% 95%)' : 'rgba(255,255,255,.16)', skipBd: lockedN ? BD : 'rgba(255,255,255,.45)',
          lx1: 150 + (ni > 0 ? OFF[(ni - 1) % 8] : 0), lx2: 150 + x, lc: done || cur ? 'hsl(6 91% 47% / .55)' : 'hsl(0 0% 88%)', lanim: cur && s.justDone ? 'drawLine .4s .05s cubic-bezier(.16,1,.3,1) both' : 'none',
          popOpen: open, popLeft: 'calc(50% + ' + cx + 'px - 130px)', caretLeft: (130 + x - cx - 8) + 'px', popTitle: n.title, popSub, popBg: lockedN ? '#fff' : col, popFg: lockedN ? INK : '#fff', popSubFg: lockedN ? MUT : 'rgba(255,255,255,.85)',
          popCan: !lockedN, popLocked: lockedN, popBtn: done ? (n.type === 'bau' ? 'Já aberto' : 'Praticar de novo') : n.type === 'bau' ? 'Abrir baú' : 'Começar', popBtnFg: col,
          onStart: () => { if (done && n.type === 'bau') return; this.startNode(n.key); },
          onReport: e => { e.stopPropagation(); this.openReport({ tipo: 'fase', ref: n.key, label: 'Fase · ' + u.title, titulo: n.title, trilha: this.trackInfo(tid).nome, unidade: u.title }); }, reportFg: lockedN ? MUT : 'rgba(255,255,255,.85)', showSkip: ni === 0 && !unitDone && !done, onSkip: () => this.skipTest(tid, u.ui),
          showStartTag: cur && !open,
          crowdHas: crowd.length > 0, crowdTwo: crowd.length > 1, crowdMore: extra > 0, crowdN: '+' + extra, crowdLeft: 'calc(50% + ' + (x + 18) + 'px)',
          cA1: crowd[0] ? E.av(crowd[0].nome, crowd[0].mold) : null, cA2: crowd[1] ? E.av(crowd[1].nome, crowd[1].mold) : null,
          crowdLabel: crowd.length + (crowd.length === 1 ? ' pessoa nesta fase' : ' pessoas nesta fase'),
          onCrowd: e => { e.stopPropagation(); this.setState({ popNode: null, sheet: 'crowd', crowd: { title: n.title, list: crowd } }); }
        };
      });
      return { ui: u.ui, uiS: String(u.ui), label: 'Unidade ' + (u.ui + 1), title: u.title, color: u.color, op: locked ? .5 : 1, rows: rows.reverse(), done: unitDone };
    });
    const bu = units[s.bannerUnit] || units[0], curN = flat[curI], ti = this.trackInfo(tid), k = this.tk();
    const sn = E.streakNow(p, this.today()), risk = sn > 0 && p.streak.last !== k;
    const m = p.leader.mandatory[p.team];
    return {
      pathRef: this.pathRef, onPathScroll: () => { if (!this._raf) this._raf = requestAnimationFrame(() => { this._raf = 0; this.updateBanner(); }); },
      units: uv.reverse(), hasUnits: units.length > 0, bannerA: s.bannerFlip, bannerB: !s.bannerFlip, bLabel: bu ? 'Unidade ' + (bu.ui + 1) + ' · ' + ti.nome : '', bTitle: bu ? bu.title : '', bColor: bu ? bu.color : RED,
      onUnitInfo: () => this.setState({ sheet: 'unit' }), showRisk: risk, riskText: 'Faça uma lição hoje para manter ' + sn + (sn === 1 ? ' dia' : ' dias') + ' de ofensiva.',
      hasContinue: !!curN && !s.popNode, continueLabel: curN ? curN.title : '', onContinue: () => curN && this.startNode(curN.key), trackDone: curI < 0 && units.length > 0,
      isAtd: tid === 'ATD', atdEmpty: tid === 'ATD' && !units.length, canLead: this.isLeader(), onOpenLeader: () => this.setState({ sub: 'leader', leaderTab: 'units' }),
      atdMand: !!(m && m.on), atdMandText: m && m.on ? 'Obrigatória para ' + (m.publico === 'novatos' ? 'novatos' : 'o time inteiro') + (m.prazo ? ' até ' + this.E.pk(m.prazo).toLocaleDateString('pt-BR') : '') : '',
      homeLoading: s.homeLoading, homeReady: !s.homeLoading
    };
  }

  vPractice() {
    const p = this._p, due = this.dueQs(), errs = Object.keys(p.errors).map(id => this.qById(id)).filter(Boolean);
    const recs = this.desempUnidades().filter(x => x.score < .6).sort((a, b) => a.score - b.score).slice(0, 2)
      .map(x => ({ crit: x.unidade, score: Math.round(x.score * 100) + '%', sub: x.trilha, onClick: () => this.startPractice('reforco', x.qs.slice(), 'Reforce · ' + x.unidade) }));
    const fsrsOn = this.fsrsAtivo(), min = Math.max(1, Math.round(due.length * 15 / 60));
    return { dueTitle: fsrsOn ? 'Revisão do dia' : 'Revisão inteligente', dueCount: due.length, onReview: () => this.startPractice('review', due, 'Revisão inteligente'), errCount: errs.length, onErrors: () => this.startPractice('errors', errs, 'Meus erros'),
      onGlossOpen: () => this.setState({ sub: 'gloss', gloss: '' }), onFlash: () => this.startFlash(), flashRecord: p.flashRecord, recs, hasRecs: recs.length > 0, glossCount: this.C.GLOSSARY.length,
      dueLabel: fsrsOn ? (due.length ? (due.length === 1 ? '1 pergunta' : due.length + ' perguntas') + ' para lembrar hoje · cerca de ' + min + ' min' : 'Tudo em dia. Volte amanhã.')
        : due.length ? due.length + ' conceitos com chance de lembrar abaixo de 50%' : 'Tudo em dia. Volte amanhã.', errLabel: errs.length ? (errs.length === 1 ? '1 pergunta' : errs.length + ' perguntas') + ' para acertar de novo' : 'Nenhum erro pendente' };
  }

  vLeague() {
    const s = this.state, p = this._p, C = this.C, E = this.E, lgs = C.LEAGUES, L = lgs[p.league.idx], d = E.leagueData(C, p, this.today());
    const offline = !s.online || p.offlineSim;
    let rows = d.rows; if (s.lbFilter === 'team') rows = rows.filter(r => r.team === p.team || r.me).map((r, i) => Object.assign({}, r, { rank: i + 1 }));
    const n = d.rows.length, z = E.leagueZones(C, d.rows, p.league.idx), up = z.up, down = z.down;
    const items = []; rows.forEach((r, i) => {
      items.push({ isRow: true, isDiv: false, rank: r.rank, nome: r.me ? r.nome + ' (você)' : r.nome, team: r.team, xp: r.xp + ' XP', av: E.av(r.nome, r.mold), bg: r.me ? 'hsl(6 80% 96%)' : '#fff', bd: r.me ? 'hsl(6 91% 47% / .45)' : BD, pos: r.me ? 'sticky' : 'relative', zi: r.me ? 6 : 1, rankFg: s.lbFilter !== 'all' ? MUT : r.rank <= up ? GREEN : r.rank > down ? RED : MUT, delay: (i * 40) + 'ms' });
      const nx = rows[i + 1];
      if (s.lbFilter === 'all' && nx && r.rank === up) items.push({ isRow: false, isDiv: true, divText: 'Zona de promoção', divIcon: 'chevrons-up', divFg: GREEN });
      if (s.lbFilter === 'all' && nx && r.rank === down) items.push({ isRow: false, isDiv: true, divText: 'Zona de rebaixamento', divIcon: 'chevrons-down', divFg: RED });
    });
    const top = rows.slice(0, 3), ord = [1, 0, 2], H = [96, 72, 56], COLS = ['linear-gradient(180deg,#FFD66B,#FF8A3D)', 'linear-gradient(180deg,#f1f5f9,#a7b1be)', 'linear-gradient(180deg,#e7a46a,#a2582a)'];
    const podium = ord.filter(i => top[i]).map(i => ({ place: i + 1, nome: top[i].me ? 'Você' : top[i].nome.split(' ')[0], xp: top[i].xp + ' XP', av: E.av(top[i].nome, top[i].mold), h: H[i] + 'px', g: COLS[i], stepDelay: [.24, .12, 0][i] + 's', avDelay: ([.24, .12, 0][i] + .35) + 's' }));
    return {
      lbLoading: s.lbLoading && !offline, lbError: offline, lbReady: !s.lbLoading && !offline, onRetry: () => { if (this.state.retrying) return; this.setState({ retrying: true }); setTimeout(() => { const still = !navigator.onLine || this._p.offlineSim; this.setState({ retrying: false, online: navigator.onLine, errShake: still ? Date.now() : 0, lbLoading: !still }); if (still) this.toast('Ainda sem conexão. Tente de novo em instantes.', 'wifi-off', 'err'); else setTimeout(() => this.setState({ lbLoading: false }), 600); }, 900); }, retrying: !!s.retrying, retryIdle: !s.retrying, retryIcon: s.retrying ? 'loader-circle' : 'refresh-cw', retryAnim: s.retrying ? 'spin .8s linear infinite' : 'none', errAnim: s.errShake ? ((Math.floor(s.errShake / 7) % 2) ? 'shake .35s ease' : 'shakeB .35s ease') : 'none', errKey: s.errShake,
      lgName: 'Liga ' + L.nome, lgGrad: L.g, lgIcon: L.icon || 'trophy', lgCountdown: 'Termina em ' + d.countdown, lgRules: (p.league.idx >= lgs.length - 1 ? 'Topo das ligas' : z.vagas ? 'Top ' + z.vagas + ' sobem' : 'Sobe a partir de ' + z.minSobe + ' pessoas') + ' · ' + (p.league.idx === 0 ? 'Bronze não rebaixa' : z.descem ? z.descem + (z.descem === 1 ? ' último desce' : ' últimos descem') : 'Desce a partir de ' + z.minDesce + ' pessoas'),
      lgSteps: lgs.map((x, i) => ({ g: x.g, icon: x.icon || 'trophy', nome: x.nome, op: i === p.league.idx ? 1 : i < p.league.idx ? .8 : .4, sz: i === p.league.idx ? '44px' : '34px', isz: i === p.league.idx ? '20' : '15', cur: i === p.league.idx, fw: i === p.league.idx ? 700 : 500, fg: i === p.league.idx ? INK : MUT })),
      fAllBg: s.lbFilter === 'all' ? '#fff' : 'transparent', fAllFg: s.lbFilter === 'all' ? INK : MUT, fAllSh: s.lbFilter === 'all' ? '0 1px 2px rgba(0,0,0,.08)' : 'none',
      fTeamBg: s.lbFilter === 'team' ? '#fff' : 'transparent', fTeamFg: s.lbFilter === 'team' ? INK : MUT, fTeamSh: s.lbFilter === 'team' ? '0 1px 2px rgba(0,0,0,.08)' : 'none',
      onFAll: () => this.setState({ lbFilter: 'all' }), onFTeam: () => this.setState({ lbFilter: 'team' }), lbIsAll: s.lbFilter === 'all', lbIsTeam: s.lbFilter === 'team', podium, lbItems: items, onEndWeek: () => { if (DEV_TOOLS) this.endWeek(); }, myTeam: p.team,
      // Simulador e "encerrar semana": ferramentas de teste, só para admin/master (o ranking é real).
      simShow: DEV_TOOLS && (p.role === 'admin' || p.role === 'master' || !!this.demo),
      simXp: String(p.league.xp), simPos: (() => { const me = d.rows.find(r => r.me); return me ? me.rank + 'º de ' + n : ''; })(),
      onSimXp: e => { const v = Math.max(0, parseInt(e.target.value, 10) || 0); this.upd(q => { q.league.xp = v; }); },
      simBtns: [-100, -20, 20, 100].map(k => ({ t: (k > 0 ? '+' : '−') + Math.abs(k), bg: k > 0 ? 'hsl(150 55% 40% / .1)' : 'hsl(6 91% 47% / .08)', fg: k > 0 ? GREEN : RED, onClick: () => this.upd(q => { q.league.xp = Math.max(0, q.league.xp + k); }) }))
    };
  }

  vMissions() {
    const p = this._p, C = this.C, E = this.E, k = this.tk(), dr = p.day[k] || { claimed: {} }, ms = E.missionsFor(C, k);
    const daily = ms.map(m => { const pr = Math.min(m.meta, (dr[m.m] || 0)), done = !!(dr.claimed && dr.claimed[m.k]); return { t: m.t, prog: pr + '/' + m.meta, pct: Math.round(pr / m.meta * 100) + '%', done, notDone: !done, reward: '+' + C.MISSION_REWARD, op: done ? .55 : 1, deco: done ? 'line-through' : 'none' }; });
    const nd = daily.filter(x => x.done).length, all = nd === 3;
    const mk = k.slice(0, 7), mp = Math.min(C.MONTH_GOAL, p.month[mk] || 0);
    const mon = E.monday(this.today()), f = Math.min(1, (this.today() - mon) / (7 * E.DAY) + .1), r = E.seeded('team' + E.dkey(mon) + p.team);
    let mine = 0; Object.keys(p.day).forEach(d => { if (d >= E.dkey(mon) && d <= k) mine += p.day[d].lessons; });
    const real = n => (this.realBy && this.realBy[n] && this.realBy[n].res) || null;
    const mates = C.PEOPLE.filter(x => x[1] === p.team).slice(0, 5).map(x => ({ nome: x[0], n: real(x[0]) ? (real(x[0]).licoesSemana || 0) : Math.round(r() * 9 * f), av: E.av(x[0], x[2]) }));
    mates.unshift({ nome: (p.name || 'Você') + ' (você)', n: mine, av: E.av(p.name, p.equipped) });
    const tot = mates.reduce((a, b) => a + b.n, 0);
    const mid = new Date(this.today()); mid.setHours(24, 0, 0, 0); const left = mid - this.today();
    return {
      daily, dailyDone: nd, chestReady: all && !dr.chest, chestOpened: !!dr.chest, chestLocked: !all, onDailyChest: () => this.openChest('daily'),
      resetIn: 'renova em ' + Math.floor(left / 36e5) + 'h', monthT: 'Desafio de ' + this.today().toLocaleDateString('pt-BR', { month: 'long' }), monthSub: 'Conclua ' + C.MONTH_GOAL + ' lições e ganhe um emblema exclusivo',
      monthPct: Math.round(mp / C.MONTH_GOAL * 100) + '%', monthProg: mp + '/' + C.MONTH_GOAL, monthDone: mp >= C.MONTH_GOAL,
      teamT: 'Equipe ' + p.team + ': ' + C.TEAM_GOAL + ' lições na semana', teamPct: Math.min(100, Math.round(tot / C.TEAM_GOAL * 100)) + '%', teamProg: Math.min(tot, C.TEAM_GOAL) + '/' + C.TEAM_GOAL, teamMembers: mates.map(m => Object.assign(m, { nl: m.n + (m.n === 1 ? ' lição' : ' lições') })),
      onLoja: () => this.setState({ sub: 'loja' }), hubLevel: ['Explorador do Hub', 'Conhecedor do Hub', 'Especialista do Hub'][nd >= 3 ? 2 : nd >= 1 ? 1 : 0]
    };
  }

  vProfile() {
    const s = this.state, p = this._p, C = this.C, E = this.E, pt = s.profTab;
    const cq = E.conquests(p, { tracksDone: this.tracksDone() }), acc = p.stats.ans ? Math.round(p.stats.ok / p.stats.ans * 100) : 0, L = C.LEAGUES[p.league.idx];
    const roleLabel = { master: 'Master', admin: 'Admin', lider: 'Líder', analista: 'Viewer' }[p.role] || 'Viewer';
    const stats = [['flame', 'Ofensiva', E.streakNow(p, this.today()) + ' dias', 'hsl(28 90% 52%)', 'hsl(28 90% 52% / .14)'], ['zap', 'XP total', p.xpTotal, AMBER, 'hsl(40 92% 46% / .15)'], ['trophy', 'Liga', L.nome, 'hsl(212 72% 48%)', 'hsl(212 72% 48% / .12)'], ['book-open', 'Lições', cq.lessons, RED, REDT], ['target', 'Precisão', acc + '%', GREEN, 'hsl(150 55% 40% / .14)'], ['snowflake', 'Congelamentos', p.streak.freezes + '/2', 'hsl(190 65% 42%)', 'hsl(190 65% 42% / .12)']].map(x => ({ icon: x[0], label: x[1], val: x[2], fg: x[3], bg: x[4] }));
    const emb = cq.fams.map(f => ({ nome: f.fam, sub: f.level ? 'Nível ' + E.ROMAN[f.level] : 'Bloqueado', prog: f.next ? f.val + '/' + f.next + ' ' + f.un : 'Nível máximo', icon: f.icon, g: f.level ? 'linear-gradient(145deg,#7CC9FF,#5B6CFF)' : 'linear-gradient(145deg,hsl(0 0% 88%),hsl(0 0% 76%))', op: 1 }))
      .concat(p.badges.map(b => ({ nome: b.nome, sub: b.sub, prog: 'Conquistado', icon: b.icon, g: b.g, op: 1 })));
    const order = (C.PERSONAS.find(x => x.id === p.persona) || C.PERSONAS[0]).order;
    const trk = this.trackList().filter(t => t.id === 'ATD' || order.indexOf(t.id) >= 0 || E.trackPct(C, this.bank, this.atd, p, t.id) > 0).map(t => { const pc = E.trackPct(C, this.bank, this.atd, p, t.id); return { nome: t.nome, icon: t.icon, pct: pc + '%', onClick: () => { this.upd(q => { q.activeTrack = t.id; }); this.setTab('learn'); } }; });
    const mates = C.PEOPLE.filter(x => x[1] === p.team).slice(0, 6).map(x => { const nudged = p.nudged[x[0]] === this.tk(); const r = E.seeded('st' + x[0] + this.tk()); return { nome: x[0], sub: ((this.realBy && this.realBy[x[0]] && this.realBy[x[0]].res) ? (this.realBy[x[0]].res.ofensiva || 0) : Math.floor(r() * 40)) + ' dias de ofensiva', av: E.av(x[0], x[2]), nudged, canNudge: !nudged, onNudge: () => { this.upd(q => { q.nudged[x[0]] = this.tk(); }); this.toast('Você cutucou ' + x[0].split(' ')[0] + '. Ela recebe um lembrete.', 'hand'); } }; });
    const pf = s.prof || { name: p.name, phone: p.phone, pwd: '', pwd2: '', show: false };
    const setPf = k => e => this.setState({ prof: Object.assign({}, pf, { [k]: e.target.value }) });
    const pill = id => ({ bg: pt === id ? RED : '#fff', fg: pt === id ? '#fff' : MUT, bd: pt === id ? RED : BD });
    const lead = this.isLeader();
    const doTime = (C.REAL_RANK || []).filter(x => x.team === p.team && x.res && x.res.progresso != null).map(x => x.res).concat([this.resumoPublico()]);
    const freq = {}; doTime.forEach(x => (x.reforcar || []).forEach(u => { freq[u] = (freq[u] || 0) + 1; }));
    const leadWorst = Object.keys(freq).sort((a, b) => freq[b] - freq[a]).slice(0, 3);
    const somaT = f => doTime.reduce((a, x) => a + (x[f] || 0), 0);
    return {
      onProfReport: () => this.openReport({ tipo: 'geral', label: 'Feedback geral', titulo: '' }), onProfReports: () => this.setState({ sub: 'reports' }), profRepCount: (window.MiseFeedback ? window.MiseFeedback.list().length : 0), profPadTop: p.equippedBg ? '50px' : '16px', profBg: (C.SHOP.find(x => x.id === p.equippedBg) || {}).g || '', hasProfBg: !!p.equippedBg, profIconOn: !!p.equippedIcon, profIcon: (C.SHOP.find(x => x.id === p.equippedIcon) || {}).icon || 'star', profName: p.name || 'Usuário', profEmail: p.session ? p.session.email : '', roleLabel, profAv: E.av(p.name, p.equipped), profCargo: p.cargo + ' · ' + p.team,
      // Abas do perfil: o relatório abre primeiro; Configurações reúne dados pessoais, preferências e ajuda.
      profTabs: [['desemp', 'Desempenho', 'trending-up'], ['conq', 'Conquistas', 'award'], ['equipe', 'Equipe', 'users'], ['config', 'Configurações', 'settings']].map(([id, t, icon]) => ({ t, icon, bg: pt === id ? '#fff' : 'transparent', fg: pt === id ? RED : MUT, sh: pt === id ? '0 1px 3px rgba(0,0,0,.1)' : 'none', onClick: () => this.setState({ profTab: id }) })),
      isPtR: pt === 'desemp' || ['conq', 'equipe', 'config'].indexOf(pt) < 0, isPtA: pt === 'conq', isPtE: pt === 'equipe', isPtC: pt === 'config', equipeVazia: !lead && !mates.length,
      stats, emblems: emb, certs: p.certs.map(c => ({ trilha: c.trilha, data: c.data, onOpen: () => this.viewCert(c), onPrint: e => { e.stopPropagation(); this.openCert(c); } })),
      onCertSample: () => this.viewCert({ nome: p.name, trilha: this.trackInfo(p.activeTrack).nome, data: this.today().toLocaleDateString('pt-BR', { day: '2-digit', month: 'long', year: 'numeric' }) }), hasCerts: p.certs.length > 0, noCerts: !p.certs.length,
      trkRows: trk, mates, hasMates: mates.length > 0,
      isLeaderUser: lead, leadPct: Math.round(somaT('progresso') / doTime.length) + '%', leadDone: somaT('trilhas') + (somaT('trilhas') === 1 ? ' trilha concluída' : ' trilhas concluídas'), leadCerts: somaT('certificados') + (somaT('certificados') === 1 ? ' certificado' : ' certificados'),
      leadWorst, leadTemWorst: leadWorst.length > 0, leadSemWorst: !leadWorst.length, leadMembers: doTime.length + (doTime.length === 1 ? ' pessoa do time com dados (você)' : ' pessoas do time com dados nesta semana'),
      onOpenLeader: () => this.setState({ sub: 'leader', leaderTab: 'panel' }),
      pfName: pf.name, pfPhone: pf.phone, onPfName: setPf('name'), onPfPhone: setPf('phone'), pfTeam: p.team, pfCargo: p.cargo, canManage: p.role === 'admin' || p.role === 'master', cantManage: !(p.role === 'admin' || p.role === 'master'),
      pTeamDD: this.dd('pteam', p.team, C.TEAMS.map(t => ({ t, sel: p.team === t, onPick: () => { this.upd(q => { q.team = t; }); this.toast('Equipe alterada para ' + t); } }))),
      onPfSave: () => { this.upd(q => { q.name = pf.name; q.phone = pf.phone; }); this.toast('Perfil atualizado com sucesso!'); },
      pfPwd: pf.pwd, pfPwd2: pf.pwd2, onPfPwd: setPf('pwd'), onPfPwd2: setPf('pwd2'), pfPwdType: pf.show ? 'text' : 'password', pfEye: pf.show ? 'eye-off' : 'eye', onPfEye: () => this.setState({ prof: Object.assign({}, pf, { show: !pf.show }) }),
      onPfPwdSave: () => this.trocarSenha(pf),
      cfgGoals: C.GOALS.map(g => ({ t: g.min + ' min', bg: E.goalMinOf(p) === g.min ? '#fff' : 'transparent', fg: E.goalMinOf(p) === g.min ? INK : MUT, sh: E.goalMinOf(p) === g.min ? '0 1px 2px rgba(0,0,0,.08)' : 'none', onClick: () => this.upd(q => { q.goalMin = g.min; }) })),
      cfgRem: C.REMINDERS.slice(0, 4).map(t => { const on = !s.remCustom && p.reminder === t; return { t, bg: on ? RED : '#fff', fg: on ? '#fff' : MUT, bd: on ? RED : BD, onClick: () => { this.setState({ remCustom: false }); this.upd(q => { q.reminder = t; }); } }; }),
      remCustom: !!s.remCustom || C.REMINDERS.indexOf(p.reminder) < 0, remCustomBg: (s.remCustom || C.REMINDERS.indexOf(p.reminder) < 0) ? RED : '#fff', remCustomFg: (s.remCustom || C.REMINDERS.indexOf(p.reminder) < 0) ? '#fff' : MUT, remCustomBd: (s.remCustom || C.REMINDERS.indexOf(p.reminder) < 0) ? RED : BD, onRemCustom: () => this.setState({ remCustom: true }),
      cfgTime: this.timeVals(p.reminder, v => this.upd(q => { q.reminder = v; })),
      soundOn: p.sound, soundBg: p.sound ? RED : BD, soundKnob: p.sound ? '18px' : '2px', onSound: () => this.upd(q => { q.sound = !q.sound; }), onTutorial: () => this.abrirTutorial(),
      nivDisponivel: !!(this.nivStatus && this.nivStatus.ativo), onRefazerNiv: () => this.abrirNivelamento(false),
      offBg: p.offlineSim ? RED : BD, offKnob: p.offlineSim ? '18px' : '2px', onOffSim: () => this.upd(q => { q.offlineSim = !q.offlineSim; }),
      personaDD: this.dd('persona', (C.PERSONAS.find(x => x.id === p.persona) || C.PERSONAS[0]).nome, C.PERSONAS.map(x => ({ t: x.nome + ' · ' + x.grupo, sel: p.persona === x.id, onPick: () => this.upd(q => { q.persona = x.id; }) }))),
      cfgRoles: [['analista', 'Analista'], ['lider', 'Líder'], ['admin', 'Admin'], ['master', 'Master']].map(([id, t]) => ({ t, bg: p.role === id ? '#fff' : 'transparent', fg: p.role === id ? INK : MUT, sh: p.role === id ? '0 1px 2px rgba(0,0,0,.08)' : 'none', onClick: () => this.upd(q => { q.role = id; }) })),
      onAdvanceDay: () => { if (!DEV_TOOLS) return; this.upd(q => { q.dayOffset++; }); this.checkWeek(); this.toast('Avançamos para ' + this.today().toLocaleDateString('pt-BR', { weekday: 'long', day: '2-digit', month: '2-digit' }), 'calendar'); },
      onResetAsk: () => this.setState({ resetAsk: true }), podeSair: !Hub.noHub, onLogout: () => { Hub.sair(); this.upd(q => { q.session = null; }); this.setState({ screen: 'login', lg: Object.assign({}, s.lg, { pwd: '', email: p.remembered || '' }) }); }
    };
  }
  // Troca a senha de verdade na conta do TakeatHub (mesmas regras do Hub). Nada da senha fica no app.
  async trocarSenha(pf) {
    if (pf.saving) return;
    const ep = Hub.erroSenha(pf.pwd);
    if (ep) return this.toast(ep, 'circle-x', 'err');
    if (pf.pwd !== pf.pwd2) return this.toast('As senhas não coincidem.', 'circle-x', 'err');
    if (this.demo) { this.setState({ prof: Object.assign({}, pf, { pwd: '', pwd2: '' }) }); return this.toast('Senha alterada com sucesso!'); }
    this.setState({ prof: Object.assign({}, pf, { saving: true }) });
    const r = await Hub.trocarSenha(pf.pwd);
    this.setState({ prof: Object.assign({}, this.state.prof || pf, { saving: false }, r.ok ? { pwd: '', pwd2: '' } : {}) });
    if (!r.ok) return this.toast(r.erro, 'circle-x', 'err');
    this.toast('Senha alterada! Use a nova senha no TakeatHub e na Mise.');
  }

  // ---------- Loja: catálogo, posse e moldura equipada vêm do TakeatHub ----------
  // Molduras = loja_itens do Hub, com as MESMAS RPCs da Loja do Hub (comprar_item, equipar_moldura,
  // resgatar_codigo): a compra e a moldura aplicada valem nos dois lugares. Itens (congelamento, XP em
  // dobro) são do próprio app e só são entregues depois do débito no saldo do Hub. Fundos e ícones ainda
  // não existem no Hub: abas "Em breve".
  lojaReal() { return !this.demo && !!(this._p && this._p.uid && this._p.session); }
  async carregarLoja(forcar) {
    if (!this.lojaReal() || this._lojaCarregando) return;
    const h = this.state.lojaHub;
    if (!forcar && h && Date.now() - h.em < 30000) return;
    this._lojaCarregando = true;
    try {
      const r = await Hub.lojaNuvem(), possui = r.possui, C = this.C;
      const ord = { comum: 0, raro: 1, epico: 2, lendario: 3, sazonal: 4 };
      const itens = r.itens.filter(i => i.tipo === 'moldura' && (!i.oculto_na_loja || possui.indexOf(i.id) >= 0))
        .map(i => ({ id: i.id, hub: true, tipo: 'moldura', asset: i.asset, nome: i.nome, raridade: C.RARIDADE[i.raridade] ? i.raridade : 'comum', preco: i.preco || 0,
          colecao: COLECAO[String(i.asset || '').split(':')[0]] || 'Especial', somente_codigo: !!i.somente_codigo }))
        .sort((a, b) => ord[a.raridade] - ord[b.raridade] || a.preco - b.preco);
      // O banco manda: a moldura do perfil do Hub é a que aparece no app.
      const eq = itens.find(i => i.id === r.equipada), asset = r.equipada ? (eq ? eq.asset : this._p.equipped) : null;
      if (this._p.equipped !== asset) this.upd(q => { q.equipped = asset; });
      this.setState({ lojaHub: { itens, possui, equipada: r.equipada, em: Date.now(), erro: '' } });
    } catch (e) {
      this.setState({ lojaHub: Object.assign({ itens: null, possui: [], equipada: null }, this.state.lojaHub || {}, { em: Date.now(), erro: navigator.onLine ? 'Não foi possível carregar a loja agora. Tente de novo em instantes.' : 'Sem conexão. Conecte-se para ver a loja.' }) });
    }
    this._lojaCarregando = false;
  }
  // Manda antes os Takitos pendentes do app, para o saldo do servidor estar em dia na hora da compra.
  async acertarTakitos() { if ((this._p.tkFila || []).length) { try { await this.enviarNuvem(); } catch (e) {} } }
  erroCompra(erro) {
    return erro === 'saldo insuficiente' ? 'Takitos insuficientes no seu saldo do TakeatHub' : erro === 'item invalido' ? 'Esse item saiu da loja.' : (erro || 'Não foi possível comprar agora.');
  }
  async equiparHub(i, tirar) {
    if (this.state.lojaBusy) return false;
    this.setState({ lojaBusy: i.id });
    const r = await Hub.equiparMoldura(tirar ? null : i.id);
    this.setState({ lojaBusy: null });
    if (!r.ok) { this.toast(r.erro, 'triangle-alert', 'err'); return false; }
    this.upd(q => { q.equipped = tirar ? null : i.asset; });
    this.setState({ lojaHub: Object.assign({}, this.state.lojaHub, { equipada: tirar ? null : i.id }) });
    this.toast(tirar ? 'Moldura removida do seu perfil' : i.nome + ' aplicada no seu perfil!', tirar ? 'circle-check' : 'sparkles');
    return true;
  }
  async comprarHub(i) {
    if (this.state.buyBusy) return;
    this.setState({ buyBusy: true });
    await this.acertarTakitos();
    const r = await Hub.comprarItem(i.id);
    if (r && typeof r.saldo === 'number') this.aplicarSaldo(r.saldo);
    if (!r || !r.ok) {
      this.setState({ buyBusy: false });
      if (r && r.erro === 'ja possui') { this.setState({ buy: null }); await this.carregarLoja(true); return this.toast('Essa moldura já é sua. Toque em Equipar para aplicar.', 'circle-check'); }
      return this.toast(this.erroCompra(r && r.erro), 'triangle-alert', 'err');
    }
    const eq = await Hub.equiparMoldura(i.id);
    if (eq.ok) this.upd(q => { q.equipped = i.asset; });
    const h = this.state.lojaHub || {};
    this.setState({ buy: null, buyBusy: false, lojaHub: Object.assign({}, h, { possui: (h.possui || []).concat([i.id]), equipada: eq.ok ? i.id : h.equipada }) });
    this.toast(eq.ok ? i.nome + ' comprada e aplicada no seu perfil!' : i.nome + ' comprada! Toque em Equipar para aplicar.', 'store', 'gold');
  }
  async comprarItemApp(i) {
    if (this.state.buyBusy) return;
    const entregar = q => { if (i.id === 'i-freeze') q.streak.freezes = Math.min(2, q.streak.freezes + 1); else q.boostUntil = Math.max(Date.now(), q.boostUntil || 0) + 15 * 60000; };
    const ok = () => { this.setState({ buy: null, buyBusy: false }); this.toast(i.nome + ' ativado!', 'store', 'gold'); };
    if (!this.lojaReal()) { this.upd(q => { q.takitos -= i.preco; entregar(q); }); return ok(); }
    this.setState({ buyBusy: true });
    await this.acertarTakitos();
    let r;
    try { r = await Hub.movimentarTakitos(-i.preco, 'loja-' + i.id + '-' + Date.now().toString(36) + Math.random().toString(36).slice(2, 6)); }
    catch (e) { r = { ok: false, erro: navigator.onLine ? 'Não foi possível comprar agora.' : 'Sem conexão. Conecte-se para comprar.' }; }
    if (r && typeof r.saldo === 'number') this.aplicarSaldo(r.saldo);
    if (!r || !r.ok) { this.setState({ buyBusy: false }); return this.toast(this.erroCompra(r && r.erro), 'triangle-alert', 'err'); }
    this.upd(entregar); ok();
  }
  // No TakeatHub a Mise abre numa moldura (página /mise-en-place) que substitui o menu do Hub: o menu da Mise
  // ganha "Abrir em nova aba" e "Voltar ao TakeatHub" (o Hub ouve a mensagem 'mise:sair' e volta para onde
  // a pessoa estava). Aberta em nova aba no domínio do Hub, fica só o "Voltar".
  vHubSaida() {
    let emMoldura = false; try { emMoldura = window.self !== window.top; } catch (e) { emMoldura = true; }
    return { hubVoltarShow: Hub.noHub, hubNovaAbaShow: Hub.noHub && emMoldura,
      onHubNovaAba: () => window.open(location.origin + '/mise/', '_blank', 'noopener'),
      onHubVoltar: () => {
        if (emMoldura) { try { window.parent.postMessage({ tipo: 'mise:sair' }, location.origin); return; } catch (e) {} }
        location.href = location.origin + '/';
      } };
  }
  vLoja() {
    const s = this.state, p = this._p, C = this.C, lj = s.loja, tab = lj.tab || 'moldura', real = this.lojaReal(), norm = x => x.normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase();
    const soon = LOJA_EM_BREVE[tab];
    if (real && tab === 'moldura') this.carregarLoja();
    const hub = s.lojaHub || {}, possui = hub.possui || [], carregando = real && tab === 'moldura' && !hub.itens && !hub.erro;
    let items = soon ? [] : real && tab === 'moldura' ? (hub.itens || []) : C.SHOP.filter(i => i.tipo === tab);
    if (lj.busca.trim()) items = items.filter(i => norm(i.nome).indexOf(norm(lj.busca.trim())) >= 0);
    const tiers = ['todas', 'comum', 'raro', 'epico', 'lendario', 'sazonal'];
    const tl = t => (t === 'todas' ? 'Todas as raridades' : C.RARIDADE[t].label) + ' (' + items.filter(i => t === 'todas' || i.raridade === t).length + ')';
    const tierDD = this.dd('tier', tl(lj.tier), tiers.map(t => ({ t: tl(t), sel: lj.tier === t, dot: t === 'todas' ? 'transparent' : C.RARIDADE[t].cor, onPick: () => this.setState({ loja: Object.assign({}, this.state.loja, { tier: t }) }) })));
    if (lj.tier !== 'todas') items = items.filter(i => i.raridade === lj.tier);
    const eqOf = i => i.hub ? hub.equipada === i.id : i.tipo === 'moldura' ? p.equipped === i.asset : false;
    const list = items.map(i => {
      const rar = C.RARIDADE[i.raridade], own = i.hub ? possui.indexOf(i.id) >= 0 : (p.owned.indexOf(i.id) >= 0 && i.tipo !== 'item'), eq = eqOf(i), gratis = i.preco === 0, sem = !gratis && p.takitos < i.preco;
      const cheio = i.id === 'i-freeze' && p.streak.freezes >= 2, busy = s.lojaBusy === i.id;
      let btn = 'Comprar', btnBg = RED, btnFg = '#fff', btnBd = RED, dis = sem || !!s.lojaBusy;
      if (own) { btn = busy ? 'Aplicando…' : eq ? 'Em uso · tirar' : 'Equipar'; btnBg = eq ? 'hsl(0 0% 95%)' : '#fff'; btnFg = INK; btnBd = BD; dis = !!s.lojaBusy; }
      else if (i.somente_codigo) { btn = 'Só por código'; btnBg = '#fff'; btnFg = MUT; btnBd = BD; dis = true; }
      else if (cheio) { btn = 'Você já tem 2'; btnBg = 'hsl(0 0% 95%)'; btnFg = MUT; btnBd = BD; dis = true; }
      else if (gratis) { btn = 'Pegar grátis'; btnBg = 'hsl(0 0% 95%)'; btnFg = INK; btnBd = BD; }
      else if (sem) { btn = 'Takitos insuficientes'; btnBg = 'hsl(0 0% 90%)'; btnFg = MUT; btnBd = 'hsl(0 0% 90%)'; }
      return { nome: i.nome, col: 'Coleção ' + i.colecao, rar: rar.label, rbg: rar.bg, rfg: rar.fg, top: '3px solid ' + rar.cor, isMold: i.tipo === 'moldura', isFundo: false, isIcone: false, isItem: i.tipo === 'item', g: i.g || '', av: this.E.av(p.name, i.asset), icon: i.icon || 'gift', img: i.img || '', hasImg: !!i.img, noImg: !i.img, eq, preco: i.preco, isGratis: gratis && !i.somente_codigo, isPago: !gratis, isCod: !!i.somente_codigo, btn, btnBg, btnFg, btnBd, dis,
        onClick: () => {
          if (dis) return;
          if (own) {
            if (i.hub) return this.equiparHub(i, eq);
            this.upd(q => { q.equipped = eq ? null : i.asset; }); return this.toast(eq ? i.nome + ' removido do perfil' : i.nome + ' equipado!');
          }
          this.setState({ buy: i.id, dd: null });
        } };
    });
    const tabs = C.SHOP_TABS.map(([id, t]) => ({ t, soon: !!LOJA_EM_BREVE[id], bg: tab === id ? '#fff' : 'transparent', fg: tab === id ? INK : MUT, sh: tab === id ? '0 1px 2px rgba(0,0,0,.08)' : 'none', onClick: () => this.setState({ loja: Object.assign({}, this.state.loja, { tab: id, tier: 'todas' }) }) }));
    const emptyMsg = carregando ? 'Carregando a loja do TakeatHub…' : (real && tab === 'moldura' && hub.erro && !hub.itens) ? hub.erro : 'Nada encontrado com esses filtros.';
    return { lojaSaldo: p.takitos, lojaBusca: lj.busca, onLojaBusca: e => this.setState({ loja: Object.assign({}, lj, { busca: e.target.value }) }), lojaPh: 'Buscar ' + ({ moldura: 'moldura', fundo: 'plano de fundo', icone: 'ícone', item: 'item' })[tab] + ' pelo nome...',
      lojaTabs: tabs, tierDD, lojaItems: list, lojaEmpty: !soon && !list.length, lojaEmptyMsg: emptyMsg, lojaSoon: !!soon, lojaNotSoon: !soon, lojaSoonIcon: soon ? soon.icon : 'clock', lojaSoonTitle: soon ? soon.titulo : '', lojaSoonText: soon ? soon.texto : '',
      onOpenResgate: () => this.setState({ sub: 'resgate', resg: { code: '', item: null, err: '', busy: false } }) };
  }
  lojaItem(id) { const h = this.state.lojaHub; return (h && h.itens && h.itens.find(x => x.id === id)) || this.C.SHOP.find(x => x.id === id); }
  vBuy() {
    const s = this.state, p = this._p, C = this.C, i = this.lojaItem(s.buy); if (!i) return { buyOpen: false };
    const rar = C.RARIDADE[i.raridade], after = p.takitos - i.preco, bg = C.SHOP.find(x => x.id === p.equippedBg), ic = C.SHOP.find(x => x.id === p.equippedIcon), busy = !!s.buyBusy;
    return { buyOpen: true, bNomeI: i.nome, bCol: 'Coleção ' + i.colecao, bRar: rar.label, bRbg: rar.bg, bRfg: rar.fg, bTop: '3px solid ' + rar.cor, bPreco: i.preco, bGratis: i.preco === 0, bPago: i.preco > 0, bAfter: after + ' Takitos depois da compra',
      bAv: this.E.av(p.name, i.tipo === 'moldura' ? i.asset : p.equipped), bBanner: bg ? bg.g : 'linear-gradient(135deg,hsl(0 0% 96%),hsl(0 0% 90%))', bIconOn: !!ic, bIcon: ic ? ic.icon : 'star', bIsItem: i.tipo === 'item', bIsVisual: i.tipo !== 'item', bItemIcon: i.icon || 'gift', bItemImg: i.img || '', bItemHasImg: !!i.img, bItemNoImg: !i.img, bNome: p.name || 'Você', bTeam: p.team,
      bHint: i.tipo === 'item' ? (i.id === 'i-freeze' ? 'Protege sua ofensiva num dia sem lição.' : p.boostUntil > Date.now() ? 'Soma mais 15 minutos ao XP em dobro que já está valendo.' : 'Todo XP dos próximos 15 minutos vale o dobro.') : 'Fica no seu perfil do TakeatHub e aqui no Mise en Place.',
      bConfirmLabel: busy ? 'Comprando…' : i.preco === 0 ? 'Pegar grátis' : 'Confirmar compra', bConfirmOp: busy ? .7 : 1,
      onBuyCancel: () => { if (!this.state.buyBusy) this.setState({ buy: null }); },
      onBuyConfirm: () => {
        if (this.state.buyBusy) return;
        if (i.hub) return this.comprarHub(i);
        if (i.tipo === 'item') return this.comprarItemApp(i);
        this.upd(q => { q.takitos -= i.preco; q.owned.push(i.id); q.equipped = i.asset; });
        this.setState({ buy: null }); this.toast(i.nome + ' comprado e equipado!', 'store', 'gold');
      } };
  }
  vResgate() {
    const p = this._p, C = this.C, r = this.state.resg || { code: '', item: null, err: '' }, it = r.item, set = patch => this.setState({ resg: Object.assign({}, this.state.resg || {}, patch) }), real = this.lojaReal();
    const rar = it ? C.RARIDADE[it.raridade] || C.RARIDADE.comum : null;
    return { rsCode: r.code, onRsCode: e => set({ code: e.target.value.toUpperCase(), err: '' }), rsHasErr: !!r.err, rsErr: r.err, rsForm: !it, rsPreview: !!it, rsDisabled: !r.code.trim() || !!r.busy,
      rsCheckLabel: r.busy ? 'Resgatando…' : 'Resgatar código', rsConfirmLabel: real ? (it && it.asset ? 'Aplicar no perfil' : 'Voltar para a loja') : 'Confirmar resgate',
      onRsCheck: async () => {
        if (r.busy || !r.code.trim()) return;
        if (!real) { const id = C.CODES[r.code.trim()]; if (!id) return set({ err: 'Código inválido ou já usado.' }); if (p.owned.indexOf(id) >= 0) return set({ err: 'Você já tem esse item na coleção.' }); return set({ item: C.SHOP.find(x => x.id === id) }); }
        set({ busy: true, err: '' });
        const res = await Hub.resgatarCodigo(r.code.trim());
        if (!res.ok) return set({ busy: false, err: res.erro || 'Código inválido.' });
        await this.carregarLoja(true);
        const h = this.state.lojaHub || {}, achou = (h.itens || []).find(x => x.nome === res.item);
        set({ busy: false, item: achou || { nome: res.item || 'Prêmio', raridade: 'lendario', colecao: 'Takeat', asset: null } });
        this.toast('Código resgatado! ' + (res.item || 'O prêmio') + ' já está na sua coleção.', 'gift', 'gold');
      },
      rsNome: it ? it.nome : '', rsCol: it ? 'Coleção ' + it.colecao : '', rsRar: rar ? rar.label : '', rsRbg: rar ? rar.bg : '', rsRfg: rar ? rar.fg : '', rsTop: rar ? '3px solid ' + rar.cor : '', rsAv: this.E.av(p.name, it ? it.asset : null),
      onRsConfirm: async () => {
        const volta = () => this.setState({ sub: 'loja', resg: null, loja: Object.assign({}, this.state.loja, { codigo: '', tab: 'moldura' }) });
        if (!real) { this.upd(q => { q.owned.push(it.id); }); volta(); return this.toast(it.nome + ' resgatada! Já está na sua coleção.', 'gift', 'gold'); }
        if (it && it.id && it.asset && !(await this.equiparHub(it, false))) return;
        volta();
      },
      onRsOther: () => set({ item: null, code: '', err: '', busy: false }) };
  }

  vGloss() {
    const q = this.state.gloss.trim().toLowerCase();
    return { gloss: this.state.gloss, onGloss: e => this.setState({ gloss: e.target.value }), glossItems: this.C.GLOSSARY.filter(g => !q || (g.t + ' ' + g.d).toLowerCase().indexOf(q) >= 0).map(g => ({ t: g.t, d: g.d, onPractice: () => this.practiceTerm(g.t) })) };
  }

  vLeader() {
    const s = this.state, p = this._p, C = this.C, E = this.E, team = p.team, lt = s.leaderTab, dis = E.disabledFor(C, p, team), rules = p.leader.rules[team] || [];
    const tabs = [['units', 'Unidades'], ['rules', 'Regras'], ['mand', 'Obrigatória'], ['panel', 'Painel']].map(([id, t]) => ({ t, onClick: () => this.setState({ leaderTab: id }), bg: lt === id ? RED : '#fff', fg: lt === id ? '#fff' : MUT, bd: lt === id ? RED : BD, sh: lt === id ? '0 2px 8px hsl(6 91% 47% / .28)' : 'none' }));
    const base = C.ATD_UNITS.map((u, i) => { const on = dis.indexOf(i) < 0; return { t: (i + 1) + '. ' + u.titulo, regra: u.regra, crit: !!u.critico, trk: on ? RED : BD, knob: on ? '18px' : '2px', n: this.atd.filter(q => q.unidade === u.titulo).length + ' questões', onToggle: () => this.upd(q => { const d = E.disabledFor(C, q, team).slice(); q.leader.disabled[team] = on ? d.concat([i]) : d.filter(x => x !== i); }) }; });
    const rf = s.ruleForm, qf = s.qForm;
    const rv = rules.map(r => ({ id: r.id, t: r.titulo, d: r.descricao, bom: r.bom, ruim: r.ruim, wiki: r.wiki || 'Sem artigo vinculado', nq: r.questions.length + (r.questions.length === 1 ? ' questão' : ' questões'), pub: r.published, draft: !r.published,
      open: s.openRule === r.id, onToggle: () => this.setState({ openRule: s.openRule === r.id ? null : r.id, qForm: null }),
      qs: r.questions.map(q => ({ t: q.enunciado, tipo: E.TYPE_LABEL[q.tipo][0], ans: q.resposta })),
      onNewQ: () => this.setState({ qForm: { ruleId: r.id, tipo: 'cenario', enunciado: '', opts: ['', '', '', ''], correct: 0, explicacao: '' } }),
      onPublish: () => { if (!r.questions.length) return this.toast('Crie pelo menos 1 questão antes de publicar.', 'triangle-alert', 'err'); this.leaderUpd((q, t) => { q.leader.rules[t].find(x => x.id === r.id).published = true; }); this.toast('Regra publicada na trilha do time'); },
      onUnpub: () => this.leaderUpd((q, t) => { q.leader.rules[t].find(x => x.id === r.id).published = false; }),
      showQForm: !!(qf && qf.ruleId === r.id) }));
    const setR = k => e => this.setState({ ruleForm: Object.assign({}, rf, { [k]: e.target.value }) });
    const setQ = k => e => this.setState({ qForm: Object.assign({}, qf, { [k]: e.target.value }) });
    const qRule = qf ? rules.find(x => x.id === qf.ruleId) : null, vf = qf && qf.tipo === 'verdadeiro_falso';
    const m = p.leader.mandatory[team] || { on: false, prazo: '', publico: 'time' };
    const setM = patch => this.upd(q => { q.leader.mandatory[team] = Object.assign({}, m, patch); });
    const r = E.seeded('panel' + team + E.dkey(E.monday(this.today())));
    const atdPct = E.trackPct(C, this.bank, this.atd, p, 'ATD');
    const members = C.PEOPLE.filter(x => x[1] === team).map(x => ({ nome: x[0], av: E.av(x[0], x[2]), pct: (this.realBy && this.realBy[x[0]] && this.realBy[x[0]].res) ? (this.realBy[x[0]].res.atdPct || 0) : Math.round(10 + r() * 85) })).concat([{ nome: (p.name || 'Você') + ' (você)', av: E.av(p.name, p.equipped), pct: atdPct }]).sort((a, b) => b.pct - a.pct).map(x => Object.assign(x, { pctS: x.pct + '%', fg: x.pct >= 80 ? GREEN : x.pct >= 60 ? AMBER : RED }));
    const prec = C.ATD_UNITS.filter((u, i) => dis.indexOf(i) < 0).map(u => ({ t: u.titulo, v: Math.round(48 + r() * 48) })).concat(rules.filter(x => x.published).map(x => ({ t: x.titulo, v: Math.round(45 + r() * 50) })));
    prec.forEach(x => { x.vS = x.v + '%'; x.fg = x.v >= 80 ? GREEN : x.v >= 60 ? AMBER : RED; x.band = x.v >= 80 ? 'Alto' : x.v >= 60 ? 'Médio' : 'Baixo'; });
    const worst = prec.slice().sort((a, b) => a.v - b.v).slice(0, 3);
    return {
      leaderTabs: tabs, ltUnits: lt === 'units', ltRules: lt === 'rules', ltMand: lt === 'mand', ltPanel: lt === 'panel', leadTeam: team, baseUnits: base, noBase: C.BASE_TEAMS.indexOf(team) < 0,
      rules: rv, hasRules: rules.length > 0, noRules: !rules.length,
      ruleFormOpen: !!rf, onNewRule: () => this.setState({ ruleForm: { titulo: '', descricao: '', bom: '', ruim: '', wiki: '' } }), onCancelRule: () => this.setState({ ruleForm: null }),
      rfT: rf ? rf.titulo : '', rfD: rf ? rf.descricao : '', rfB: rf ? rf.bom : '', rfR: rf ? rf.ruim : '', rfW: rf ? rf.wiki : '', onRfT: setR('titulo'), onRfD: setR('descricao'), onRfB: setR('bom'), onRfR: setR('ruim'), onRfW: setR('wiki'),
      onSaveRule: () => { if (!rf.titulo.trim() || !rf.descricao.trim()) return this.toast('Dê um título e uma descrição para a regra.', 'triangle-alert', 'err'); const id = 'r' + Date.now().toString(36); this.leaderUpd((q, t) => { q.leader.rules[t].push(Object.assign({ id, questions: [], published: false }, rf)); }); this.setState({ ruleForm: null, openRule: id }); this.toast('Regra criada como rascunho'); },
      qfTipos: [['cenario', 'Cenário'], ['multipla_escolha', 'Múltipla escolha'], ['verdadeiro_falso', 'V ou F'], ['diagnostico', 'Diagnóstico']].map(([id, t]) => ({ t, bg: qf && qf.tipo === id ? '#fff' : 'transparent', fg: qf && qf.tipo === id ? INK : MUT, sh: qf && qf.tipo === id ? '0 1px 2px rgba(0,0,0,.08)' : 'none', onClick: () => this.setState({ qForm: Object.assign({}, qf, { tipo: id, correct: id === 'verdadeiro_falso' ? 1 : 0 }) }) })),
      qfEnun: qf ? qf.enunciado : '', onQfEnun: setQ('enunciado'), qfExp: qf ? qf.explicacao : '', onQfExp: setQ('explicacao'), qfVF: !!vf, qfNotVF: !vf,
      qfOpts: qf ? (vf ? ['Verdadeiro', 'Falso'] : qf.opts).map((o, i) => ({ v: o, ph: 'Alternativa ' + (i + 1), letter: String.fromCharCode(65 + i), onChange: e => { const op = qf.opts.slice(); op[i] = e.target.value; this.setState({ qForm: Object.assign({}, this.state.qForm, { opts: op }) }); }, ok: qf.correct === i, rbg: qf.correct === i ? GREEN : '#fff', rbd: qf.correct === i ? GREEN : BD, onCorrect: () => this.setState({ qForm: Object.assign({}, this.state.qForm, { correct: i }) }) })) : [],
      onHubia: () => { if (!qRule) return; this.setState({ qForm: Object.assign({}, qf, this.hubiaDraft(qRule, qf.tipo)) }); this.toast('A Mise preencheu um rascunho. Revise antes de salvar.', 'sparkles'); },
      qfHubia: !!(qf && qf.hubia), onCancelQ: () => this.setState({ qForm: null }), onAddQ: () => this.addQuestion(),
      prevEnun: qf && qf.enunciado ? qf.enunciado : 'O enunciado aparece aqui.', prevOpts: qf ? (vf ? ['Verdadeiro', 'Falso'] : qf.opts.filter(Boolean)).map((o, i) => ({ t: o, bd: (vf ? i : qf.opts.indexOf(o)) === qf.correct ? GREEN : BD })) : [], prevTipo: qf ? E.TYPE_LABEL[qf.tipo][0] : '',
      mOn: m.on, mTrk: m.on ? RED : BD, mKnob: m.on ? '18px' : '2px', onMToggle: () => setM({ on: !m.on }), mPrazo: m.prazo, onMPrazo: e => setM({ prazo: e.target.value }),
      mPubTime: { bg: m.publico !== 'novatos' ? '#fff' : 'transparent', fg: m.publico !== 'novatos' ? INK : MUT, sh: m.publico !== 'novatos' ? '0 1px 2px rgba(0,0,0,.08)' : 'none' }, mPubNov: { bg: m.publico === 'novatos' ? '#fff' : 'transparent', fg: m.publico === 'novatos' ? INK : MUT, sh: m.publico === 'novatos' ? '0 1px 2px rgba(0,0,0,.08)' : 'none' },
      onPubTime: () => setM({ publico: 'time' }), onPubNov: () => setM({ publico: 'novatos' }),
      members, prec, worst, teamAvg: Math.round(members.reduce((a, b) => a + b.pct, 0) / members.length) + '%'
    };
  }

  // ---------- desempenho (só dados reais do próprio progresso) ----------
  // Força de um módulo = média da chance de lembrar (memória espaçada, p.hl) das perguntas já vistas,
  // misturada com a taxa de acerto quando há histórico (p.qa). Nada estimado nem sorteado.
  desempUnidades() {
    const p = this._p, E = this.E, now = this.today().getTime(), hl = p.hl || {}, qa = p.qa || {}, out = [];
    this.trackList().forEach(t => {
      let units = []; try { units = this.units(t.id); } catch (e) { units = []; }
      units.forEach(u => {
        const qs = u.qs.concat(u.extras || []), vistos = qs.filter(q => hl[q.id]);
        if (vistos.length < 3) return;
        const mem = vistos.reduce((a, q) => a + Math.pow(2, -((now - hl[q.id].t) / E.DAY) / hl[q.id].h), 0) / vistos.length;
        let ans = 0, ok = 0; vistos.forEach(q => { if (qa[q.id]) { ans += qa[q.id][0]; ok += qa[q.id][1]; } });
        const acc = ans ? ok / ans : null;
        out.push({ tid: t.id, trilha: t.nome, unidade: u.title, qs, vistos: vistos.length, total: qs.length, mem, acc, score: acc == null ? mem : (mem + acc) / 2, erros: qs.filter(q => p.errors[q.id]).length });
      });
    });
    return out;
  }
  vDesempenho() {
    const s = this.state, p = this._p, E = this.E, C = this.C, dias = s.desPer || 7, hoje = this.today();
    const dia = i => { const d = new Date(hoje); d.setDate(d.getDate() - i); const r = (p.day || {})[E.dkey(d)] || {}; return { d, xp: r.xp || 0, licoes: r.lessons || 0, perf: r.perfect || 0, rev: r.reviews || 0 }; };
    const serie = [], antes = [];
    for (let i = dias - 1; i >= 0; i--) serie.push(dia(i));
    for (let i = 2 * dias - 1; i >= dias; i--) antes.push(dia(i));
    const soma = (l, f) => l.reduce((a, x) => a + x[f], 0), ativos = l => l.filter(x => x.licoes || x.xp).length;
    const lic = soma(serie, 'licoes'), xp = soma(serie, 'xp'), licA = soma(antes, 'licoes'), xpA = soma(antes, 'xp');
    const delta = (a, b, un, uns) => !b && !a ? 'sem atividade' : !b ? 'novo no período' : a === b ? 'igual ao período anterior' : (a > b ? '▲ ' : '▼ ') + Math.abs(a - b) + ' ' + (Math.abs(a - b) === 1 ? un : uns) + ' vs. período anterior';
    const acc = p.stats.ans ? Math.round(p.stats.ok / p.stats.ans * 100) : null;
    const maxXp = Math.max(10, ...serie.map(x => x.xp)), sem = ['D', 'S', 'T', 'Q', 'Q', 'S', 'S'];
    const uni = this.desempUnidades();
    const nivel = sc => sc >= .8 ? ['Forte', GREEN] : sc >= .6 ? ['Bom', AMBER] : ['Reforçar', RED];
    const linha = x => { const n = nivel(x.score); return { t: x.unidade, sub: x.trilha + ' · ' + x.vistos + ' de ' + x.total + ' perguntas vistas' + (x.erros ? ' · ' + x.erros + ' com erro' : ''), pct: Math.round(x.score * 100) + '%', w: Math.round(x.score * 100) + '%', fg: n[1], nivel: n[0], onTreinar: () => this.startPractice('reforco', x.qs.slice(), 'Reforce · ' + x.unidade) }; };
    const fortes = uni.filter(x => x.score >= .7).sort((a, b) => b.score - a.score).slice(0, 3).map(linha);
    const fracas = uni.filter(x => x.score < .7 || x.erros).sort((a, b) => a.score - b.score).slice(0, 3).map(linha);
    const trilhas = this.trackList().map(t => ({ t, pc: E.trackPct(C, this.bank, this.atd, p, t.id) })).filter(x => x.pc > 0).sort((a, b) => b.pc - a.pc)
      .map(x => ({ nome: x.t.nome, icon: x.t.icon, pct: x.pc + '%', onClick: () => { this.upd(q => { q.activeTrack = x.t.id; }); this.setState({ sub: null }); this.setTab('learn'); } }));
    const due = this.dueQs(), errs = Object.keys(p.errors).map(id => this.qById(id)).filter(Boolean);
    const aba = (n, t) => ({ t, bg: dias === n ? '#fff' : 'transparent', fg: dias === n ? INK : MUT, sh: dias === n ? '0 1px 2px rgba(0,0,0,.08)' : 'none', onClick: () => this.setState({ desPer: n }) });
    return {
      dsPers: [aba(7, '7 dias'), aba(30, '30 dias')],
      dsVazio: !Object.keys(p.hl || {}).length,
      dsKpis: [
        { icon: 'book-open', fg: RED, bg: REDT, val: String(lic), label: lic === 1 ? 'lição concluída' : 'lições concluídas', sub: delta(lic, licA, 'lição', 'lições') },
        { icon: 'zap', fg: AMBER, bg: 'hsl(40 92% 46% / .15)', val: String(xp), label: 'XP ganho', sub: delta(xp, xpA, 'XP', 'XP') },
        { icon: 'calendar-check', fg: 'hsl(212 72% 48%)', bg: 'hsl(212 72% 48% / .12)', val: ativos(serie) + '/' + dias, label: 'dias com estudo', sub: 'ofensiva atual: ' + E.streakNow(p, hoje) + ' · recorde ' + (p.streak.best || 0) },
        { icon: 'target', fg: GREEN, bg: 'hsl(150 55% 40% / .14)', val: acc == null ? '—' : acc + '%', label: 'precisão geral', sub: p.stats.ans ? p.stats.ok + ' acertos em ' + p.stats.ans + ' respostas' : 'responda uma lição para medir' },
      ],
      dsBars: serie.map((x, i) => ({ h: Math.max(x.xp ? 6 : 2, Math.round(x.xp / maxXp * 100)) + '%', bg: x.xp ? RED : 'hsl(0 0% 90%)', l: dias === 7 ? sem[x.d.getDay()] : (i % 5 === 0 || i === dias - 1 ? String(x.d.getDate()) : ''), tip: x.d.toLocaleDateString('pt-BR', { day: '2-digit', month: '2-digit' }) + ' · ' + x.xp + ' XP · ' + x.licoes + ' lições' })),
      dsBarsGap: dias === 7 ? '8px' : '2px',
      dsFortes: fortes, dsTemFortes: fortes.length > 0, dsSemFortes: !fortes.length,
      dsFracas: fracas, dsTemFracas: fracas.length > 0, dsSemFracas: !fracas.length,
      dsTrilhas: trilhas, dsTemTrilhas: trilhas.length > 0,
      dsDue: due.length, dsErr: errs.length,
      onDsRevisao: () => { if (!due.length) return this.toast('Nada para revisar agora. Volte amanhã.', 'circle-check'); this.startPractice('review', due, 'Revisão inteligente'); },
      onDsErros: () => { if (!errs.length) return this.toast('Nenhum erro pendente.', 'circle-check'); this.startPractice('errors', errs, 'Meus erros'); },
    };
  }

  // ---------- trilha Dev (editor do líder de Tecnologia) ----------
  devForm(q, extra) {
    const opts = Array.isArray(q && q.opcoes) ? q.opcoes.map(String) : ['', '', '', ''];
    while (opts.length < 4) opts.push('');
    const tipo = (q && q.tipo) || 'multipla_escolha';
    return Object.assign({ id: (q && q.id) || null, unidade: (q && q.unidade) || '', licao: (q && q.licao) || '', tipo, enunciado: (q && q.enunciado) || '', opts: tipo === 'verdadeiro_falso' ? ['Verdadeiro', 'Falso', '', ''] : opts.slice(0, 4),
      correct: Math.max(0, opts.indexOf(String(q && q.resposta))), explicacao: (q && q.explicacao) || '', fonte: (q && q.fonte) || '', dificuldade: (q && q.dificuldade) || 3 }, extra || {});
  }
  devPayload(f) {
    const vf = f.tipo === 'verdadeiro_falso', opts = vf ? ['Verdadeiro', 'Falso'] : f.opts.map(x => x.trim()).filter(Boolean);
    return { id: f.id || undefined, unidade: f.unidade.trim(), licao: f.licao.trim(), tipo: f.tipo, dificuldade: f.dificuldade, enunciado: f.enunciado.trim(), opcoes: opts, resposta: (vf ? ['Verdadeiro', 'Falso'] : f.opts)[f.correct], explicacao: f.explicacao.trim(), fonte: f.fonte.trim() };
  }
  devSet(patch) { this.setState({ devEd: Object.assign({}, this.state.devEd, patch) }); }
  devFormSet(patch) { const d = this.state.devEd; this.devSet({ form: Object.assign({}, d.form, patch) }); }
  async devPedirMise(questao) {
    const d = this.state.devEd, pedido = (d.pedido || '').trim() || (questao ? 'Melhore esta pergunta: deixe mais clara, confira no código e corrija o que estiver errado.' : '');
    if (pedido.length < 6) return this.toast('Diga à Mise o que você quer perguntar.', 'triangle-alert', 'err');
    if (d.carregando) return;
    this.devSet({ carregando: 'ajuda' });
    const r = await Hub.devAcao({ acao: 'ajuda', instrucao: pedido, questao: questao ? this.devPayload(this.devForm(questao)) : undefined, unidade: (d.form && d.form.unidade) || (questao && questao.unidade) || d.aberto || undefined, tipos: this.DEV_TIPOS.map(x => x[0]) });
    if (r.erro) { this.devSet({ carregando: '' }); return this.toast(r.erro, 'circle-x', 'err'); }
    this.devSet({ carregando: '', pedido: '', form: this.devForm(r.questao, { id: questao ? questao.id : null }), ia: { comentario: r.comentario || '', evid: r.evidencias || [], aviso: r.aviso || '' } });
    this.toast('A Mise montou um rascunho. Revise antes de salvar.', 'sparkles');
  }
  async devSalvar() {
    const d = this.state.devEd, f = d.form, q = this.devPayload(f);
    if (!q.unidade) return this.toast('Escolha um módulo ou crie um novo.', 'triangle-alert', 'err');
    if (!q.licao) return this.toast('Dê um nome à lição.', 'triangle-alert', 'err');
    if (q.enunciado.length < 8 || q.opcoes.length < 2 || !q.resposta) return this.toast('Preencha o enunciado, as alternativas e marque a correta.', 'triangle-alert', 'err');
    if (d.carregando) return;
    this.devSet({ carregando: 'salvar' });
    const r = await Hub.devAcao({ acao: 'salvar', questao: q });
    if (r.erro) { this.devSet({ carregando: '' }); return this.toast(r.erro, 'circle-x', 'err'); }
    await this.carregarQuestoes();
    this.devSet({ carregando: '', form: null, ia: null, aberto: q.unidade });
    this.toast(f.id ? 'Pergunta atualizada na trilha Dev' : 'Pergunta publicada na trilha Dev', 'circle-check');
  }
  async devDesativar(q) {
    if (!window.confirm('Tirar esta pergunta da trilha Dev?\n\n"' + q.enunciado.slice(0, 120) + '"\n\nDá para desfazer pelo Painel Master.')) return;
    const r = await Hub.devAcao({ acao: 'desativar', id: q.id });
    if (r.erro) return this.toast(r.erro, 'circle-x', 'err');
    await this.carregarQuestoes(); this.toast('Pergunta retirada da trilha Dev');
  }
  async devRenomear(de) {
    const para = (window.prompt('Novo nome do módulo', de) || '').trim();
    if (!para || para === de) return;
    const r = await Hub.devAcao({ acao: 'modulo', de, para });
    if (r.erro) return this.toast(r.erro, 'circle-x', 'err');
    await this.carregarQuestoes(); this.devSet({ aberto: para }); this.toast('Módulo renomeado');
  }
  get DEV_TIPOS() { return [['multipla_escolha', 'Múltipla'], ['verdadeiro_falso', 'V ou F'], ['completar_lacuna', 'Lacuna'], ['cenario', 'Cenário']]; }
  vDevEdit() {
    const s = this.state, E = this.E, d = s.devEd || { aberto: null, form: null, pedido: '', ia: null }, f = d.form, qs = this.devQs();
    const mods = []; qs.forEach(q => { if (mods.indexOf(q.unidade) < 0) mods.push(q.unidade); });
    const editaveis = this.DEV_TIPOS.map(x => x[0]).concat(['diagnostico']), vf = !!(f && f.tipo === 'verdadeiro_falso'), ld = d.carregando;
    const nova = unidade => this.devSet({ form: this.devForm(null, { unidade: unidade || '' }), ia: null });
    return {
      dvResumo: qs.length + (qs.length === 1 ? ' pergunta' : ' perguntas') + ' em ' + mods.length + (mods.length === 1 ? ' módulo' : ' módulos'),
      dvVazia: !qs.length, onDvNova: () => nova(d.aberto),
      dvPedido: d.pedido || '', onDvPedido: e => this.devSet({ pedido: e.target.value }), onDvPedir: () => this.devPedirMise(null),
      dvPedirLabel: ld === 'ajuda' ? 'A Mise está lendo o código…' : 'Pedir à Mise', dvPedirOp: ld ? '.6' : '1', dvLendo: ld === 'ajuda',
      dvModulos: mods.map(m => {
        const lista = qs.filter(q => q.unidade === m), open = d.aberto === m;
        return { t: m, n: lista.length + (lista.length === 1 ? ' pergunta' : ' perguntas'), open, onToggle: () => this.devSet({ aberto: open ? null : m }),
          onNovaAqui: () => nova(m), onRenomear: () => this.devRenomear(m),
          qs: lista.map(q => ({ id: q.id, t: q.enunciado, tipo: (E.TYPE_LABEL[q.tipo] || [q.tipo])[0], ans: typeof q.resposta === 'string' ? q.resposta : 'resposta em várias partes', licao: q.licao,
            onEdit: () => editaveis.indexOf(q.tipo) >= 0 ? this.devSet({ form: this.devForm(q), ia: null }) : this.toast('Este tipo de pergunta ainda não é editável aqui. Peça à Mise para reescrever como múltipla escolha.', 'info'),
            onMelhorar: () => this.devPedirMise(q), onDesativar: () => this.devDesativar(q) })) };
      }),
      dvFormOpen: !!f, dvFormTitulo: f && f.id ? 'Editar ' + f.id : 'Nova pergunta',
      dvIa: !!(f && d.ia), dvIaComent: d.ia ? d.ia.comentario : '', dvIaAviso: d.ia && d.ia.aviso ? 'Atenção: ' + d.ia.aviso + '.' : '', dvIaTemAviso: !!(d.ia && d.ia.aviso),
      dvEvid: d.ia ? (d.ia.evid || []).map(x => ({ t: (x.repo || '') + (x.path ? ' / ' + x.path : '') })) : [],
      dvModChips: mods.map(m => ({ t: m, bg: f && f.unidade === m ? RED : '#fff', fg: f && f.unidade === m ? '#fff' : INK, bd: f && f.unidade === m ? RED : BD, onClick: () => this.devFormSet({ unidade: m }) })),
      dvNovoMod: f && mods.indexOf(f.unidade) < 0 ? f.unidade : '', onDvNovoMod: e => this.devFormSet({ unidade: e.target.value }),
      dvLicao: f ? f.licao : '', onDvLicao: e => this.devFormSet({ licao: e.target.value }),
      dvTipos: this.DEV_TIPOS.map(([id, t]) => ({ t, bg: f && f.tipo === id ? '#fff' : 'transparent', fg: f && f.tipo === id ? INK : MUT, sh: f && f.tipo === id ? '0 1px 2px rgba(0,0,0,.08)' : 'none',
        onClick: () => this.devFormSet({ tipo: id, correct: id === 'verdadeiro_falso' ? 1 : 0, opts: id === 'verdadeiro_falso' ? ['Verdadeiro', 'Falso', '', ''] : (f.tipo === 'verdadeiro_falso' ? ['', '', '', ''] : f.opts) }) })),
      dvEnun: f ? f.enunciado : '', onDvEnun: e => this.devFormSet({ enunciado: e.target.value }),
      dvVF: vf, dvNotVF: !vf,
      dvOpts: f ? (vf ? ['Verdadeiro', 'Falso'] : f.opts).map((o, i) => ({ v: o, ph: 'Alternativa ' + (i + 1), onChange: e => { const op = this.state.devEd.form.opts.slice(); op[i] = e.target.value; this.devFormSet({ opts: op }); }, rbg: f.correct === i ? GREEN : '#fff', rbd: f.correct === i ? GREEN : BD, onCorrect: () => this.devFormSet({ correct: i }) })) : [],
      dvExp: f ? f.explicacao : '', onDvExp: e => this.devFormSet({ explicacao: e.target.value }),
      dvFonte: f ? f.fonte : '', onDvFonte: e => this.devFormSet({ fonte: e.target.value }),
      onDvCancelar: () => this.devSet({ form: null, ia: null }), onDvSalvar: () => this.devSalvar(),
      dvSalvarLabel: ld === 'salvar' ? 'Salvando…' : (f && f.id ? 'Salvar alterações' : 'Publicar na trilha'), dvSalvarOp: ld ? '.6' : '1',
    };
  }

  vLesson() {
    const s = this.state, L = s.lesson, ex = s.ex, E = this.E, h = React.createElement; if (!L || !ex) return {};
    const noReq = E.NOREQ.indexOf(L.mode) >= 0 || !!L.server, answered = L.solved + (noReq ? Object.keys(L.wrong).length : 0), pct = Math.round(Math.min(1, answered / L.total) * 100);
    const v = {
      lessonPct: pct + '%', onExit: () => this.setState({ exitAsk: true }),
      shineEl: h('span', { key: 'sh' + answered, style: { position: 'absolute', top: 0, bottom: 0, width: '35%', left: 0, background: 'linear-gradient(90deg,transparent,rgba(255,255,255,.75),transparent)', animation: answered ? 'shine .8s .15s ease-out both' : 'none' } }),
      showCombo: L.combo >= 3, comboEl: h('span', { key: 'c' + L.combo, style: { display: 'inline-flex', alignItems: 'center', gap: 4, padding: '5px 10px', borderRadius: 999, background: 'hsl(40 92% 46% / .15)', color: 'hsl(32 82% 40%)', fontWeight: 700, fontSize: 12 + Math.min(4, L.combo - 3), animation: 'comboPop .4s cubic-bezier(.34,1.56,.64,1)' } }, h('lu-icon', { name: 'flame', size: '14' }), 'x' + L.combo),
      onLessonReport: () => { const q = L.tipOpen ? L.tip : L.queue[L.idx]; this.openReport({ tipo: 'questao', ref: q.id, label: 'Questão ' + q.id + ' · ' + E.TYPE_LABEL[q.tipo][0], titulo: q.enunciado, trilha: q.trilha, unidade: q.unidade, licao: L.title }); },
      isTimed: L.timed && !L.tipOpen, isTip: L.tipOpen, notTip: !L.tipOpen, lessonTitle: L.title
    };
    if (L.timed && L.mode === 'nivelamento') { const left = Math.max(0, Math.floor((L.prazoLocal - s.now) / 1000)); v.secsLeft = E.mmss(left); v.timerFg = left <= 30 ? AMBER : MUT; }
    else if (L.timed) { const left = Math.max(0, 30 - Math.floor((s.now - L.qStart) / 1000)); v.secsLeft = left + 's'; v.timerFg = left <= 10 ? RED : MUT; }
    // "Não sei" no nivelamento: melhor que chutar (chute certo pularia um módulo que a pessoa não domina).
    v.showNaoSei = L.mode === 'nivelamento' && !s.fb && !L.tipOpen; v.onNaoSei = () => this.checkServidor(true);
    if (L.tipOpen) { Object.assign(v, { tipTitle: L.tip.licao, tipText: L.tip.explicacao, tipFonte: E.fmtFonte(L.tip.fonte), onTipGo: () => this.setState({ lesson: Object.assign({}, L, { tipOpen: false, qStart: Date.now() }) }) }); return v; }
    const q = L.queue[L.idx], t = q.tipo, checked = !!s.fb, TL = E.TYPE_LABEL[t];
    const optStyle = o => {
      const sel = ex.sel === o, isAns = o === q.resposta; let bd = BD, bg = '#fff', sh = '0 3px 0 hsl(0 0% 88%)', tr = 'none', anim = 'none', fg = INK;
      if (!checked && sel) { bd = RED; bg = REDT2; sh = '0 3px 0 hsl(6 91% 47% / .45)'; tr = 'translateY(-2px) scale(1.02)'; fg = RED; }
      if (checked && isAns) { bd = GREEN; bg = GREENT; sh = '0 3px 0 hsl(150 55% 40% / .45)'; fg = 'hsl(150 55% 28%)'; }
      if (checked && sel && !isAns) { bd = RED; bg = REDT; anim = 'shake .3s ease'; fg = RED; }
      return { text: o, bd, bg, sh, tr, anim, fg, sel, onClick: () => { if (this.state.fb) return; this.beep('tap'); this.setEx({ sel: o }); } };
    };
    Object.assign(v, { typeLabel: TL[0], typeIcon: TL[1], enun: q.enunciado, isVF: t === 'verdadeiro_falso', isCenario: t === 'cenario', isDiag: t === 'diagnostico', isLacuna: t === 'completar_lacuna', isTouch: t === 'toque_na_tela', isNumeric: !!ex.numeric, isOrder: t === 'ordenar_passos', isPairs: t === 'combinar_pares', isOnde: t === 'onde_fica' });
    v.isPlainQ = !v.isCenario && !v.isDiag && !v.isLacuna && !v.isTouch;
    v.isOptList = !!ex.opts && !v.isLacuna && !v.isTouch && !v.isNumeric;
    v.optCols = v.isVF ? '1fr 1fr' : '1fr';
    v.opts = ex.opts ? ex.opts.map(optStyle) : [];
    if (v.isLacuna) { const parts = q.enunciado.split(/_{2,}/); v.lacA = parts[0]; v.lacB = parts.slice(1).join(' '); v.lacBlank = ex.sel || '\u00a0'; v.lacBd = ex.sel ? RED : 'hsl(0 0% 80%)'; v.lacFg = checked ? (ex.sel === q.resposta ? GREEN : RED) : RED; }
    if (v.isTouch) { const m = q.enunciado.match(/^Tela:\s*([\s\S]+?)\.\s+([\s\S]*)$/); v.touchCap = m ? m[1] : 'Tela da plataforma'; v.touchQ = m ? m[2] : q.enunciado; }
    if (v.isNumeric) { v.numVal = ex.num; v.onNum = e => { if (this.state.fb) return; this.setEx({ num: e.target.value }); }; v.numBd = checked ? (s.fb.ok ? GREEN : RED) : (ex.num ? RED : BD); v.onNumKey = e => { if (e.key === 'Enter' && this.E.digits(this.state.ex.num)) this.check(); }; }
    if (v.isOrder) {
      const d = ex.drag, n = ex.order.length;
      v.ordItems = ex.order.map((text, j) => {
        let ty = 0, z = 1, sc = 1, shadow = '0 3px 0 hsl(0 0% 88%)', trans = 'transform .22s cubic-bezier(.16,1,.3,1)';
        if (d) { const target = Math.max(0, Math.min(n - 1, d.i + Math.round(d.dy / STEP))); if (j === d.i) { ty = d.dy; z = 5; sc = 1.04; shadow = '0 14px 30px rgba(0,0,0,.18)'; trans = 'none'; } else if (j > d.i && j <= target) ty = -STEP; else if (j < d.i && j >= target) ty = STEP; }
        const ok = checked && q.resposta[j] === text, bad = checked && !ok;
        return { text, num: j + 1, tf: 'translateY(' + ty + 'px) scale(' + sc + ')', z, shadow, trans, bd: ok ? GREEN : bad ? RED : BD, bg: ok ? GREENT : bad ? REDT2 : '#fff', nbg: ok ? GREEN : bad ? RED : 'hsl(0 0% 95%)', nfg: ok || bad ? '#fff' : MUT, onDown: e => this.ordDown(j, e), onMove: e => this.ordMove(e), onUp: () => this.ordUp() };
      });
    }
    if (v.isPairs) {
      const mk = (side, val) => { const m = side === 'l' ? ex.mL[val] : ex.mR[val], sel = side === 'l' ? ex.selL === val : ex.selR === val, bad = ex.bad && (side === 'l' ? ex.bad.l : ex.bad.r) === val; return { text: val, onClick: () => this.tapPair(side, val), bd: sel || bad ? RED : BD, bg: sel ? REDT2 : bad ? REDT : '#fff', fg: sel || bad ? RED : INK, anim: m ? 'pairOut .45s cubic-bezier(.16,1,.3,1) forwards' : bad ? 'shake .3s ease' : 'none', pe: m ? 'none' : 'auto', tr: sel ? 'translateY(-2px) scale(1.02)' : 'none' }; };
      v.pairL = ex.left.map(x => mk('l', x)); v.pairR = ex.right.map(x => mk('r', x)); v.pairMist = ex.mistakes ? ex.mistakes + (ex.mistakes === 1 ? ' erro' : ' erros') : 'Sem erros';
    }
    if (v.isOnde) {
      let node = ex.tree; ex.path.forEach(lb => { node = node.kids.find(k => k.label === lb) || node; });
      const rows = node.kids.map(k => { const sel = ex.sel && k.value === ex.sel && !k.kids.length; return { label: k.label, kids: k.kids.length > 0, leaf: !k.kids.length, sel, bg: sel ? REDT2 : '#fff', bd: sel ? RED : 'hsl(0 0% 93%)', fg: sel ? RED : INK, onClick: () => { if (this.state.fb) return; this.beep('tap'); if (k.kids.length) this.setEx({ path: ex.path.concat([k.label]) }); else this.setEx({ sel: k.value }); } }; });
      if (node.value && node.kids.length) rows.unshift({ label: 'Abrir ' + node.label, kids: false, leaf: true, sel: ex.sel === node.value, bg: ex.sel === node.value ? REDT2 : '#fff', bd: ex.sel === node.value ? RED : 'hsl(0 0% 93%)', fg: ex.sel === node.value ? RED : INK, onClick: () => this.setEx({ sel: node.value }) });
      v.ondeRows = rows; v.ondeCrumb = ['Início'].concat(ex.path).join('  ›  '); v.ondeCanBack = ex.path.length > 0; v.onOndeBack = () => this.setEx({ path: ex.path.slice(0, -1) }); v.ondeSel = ex.sel || ''; v.hasOndeSel = !!ex.sel;
    }
    const can = (v.isOrder ? true : v.isNumeric ? E.digits(ex.num).length > 0 : ex.sel != null) && !L.enviando;
    Object.assign(v, { showCheck: !v.isPairs && !checked, checkDisabled: !can, checkBg: can ? RED : 'hsl(0 0% 90%)', checkFg: can ? '#fff' : 'hsl(0 0% 62%)', checkSh: can ? '0 4px 0 hsl(6 100% 34%)' : '0 4px 0 hsl(0 0% 82%)', onCheck: () => this.check(), pairsHint: v.isPairs && !checked });
    if (checked) { const ok = s.fb.ok; Object.assign(v, { fbOpen: !s.why, fbOk: ok, fbBad: !ok, fbTitle: ok ? ['Mandou bem!', 'Isso mesmo!', 'Perfeito!'][answered % 3] : s.fb.titulo || (s.fb.timeout ? 'O tempo acabou' : 'Resposta correta:'), fbCorrect: s.fb.correct, fbBg: ok ? 'hsl(150 55% 96%)' : 'hsl(6 91% 97%)', fbFg: ok ? 'hsl(150 55% 30%)' : RED, fbBtn: ok ? GREEN : RED, fbBtnSh: ok ? '0 4px 0 hsl(150 55% 28%)' : '0 4px 0 hsl(6 100% 34%)', onNext: () => this.nextQ(), onWhy: () => this.openWhy(), whyOpen: s.why, whyText: q.explicacao || (L.server ? 'A explicação aparece quando você chegar nas lições deste módulo.' : ''), whyFonte: E.fmtFonte(q.fonte), onWhyClose: () => this.setState({ why: false }), fbRequeue: !ok && !noReq }); }
    else Object.assign(v, { fbOpen: false, whyOpen: false });
    return v;
  }

  vEnd() {
    const e = this.state.end, a = this.state.endAnim; if (!e) return {};
    const T = { licao: 'Lição concluída!', caso: 'Caso resolvido!', checkpoint: 'Checkpoint concluído!', mestre: e.pass ? 'Desafio Mestre vencido!' : 'Quase lá no Desafio Mestre', skip: e.pass ? 'Unidade liberada!' : 'Ainda não foi desta vez', placement: 'Teste de nivelamento', nivelamento: e.pass ? 'Nivelamento concluído!' : 'Vamos do começo', review: 'Revisão concluída!', errors: 'Erros revisados!', term: 'Treino concluído!', reforco: 'Reforço concluído!' };
    const sub = e.sub ? e.sub : e.mode === 'placement' ? (e.pass ? 'Você acertou ' + e.acc + '%. As unidades básicas já estão concluídas.' : 'Você acertou ' + e.acc + '%. Vamos começar do básico, no seu ritmo.') : e.mode === 'skip' && !e.pass ? 'Você precisava de 75%. Siga pela trilha e tente de novo depois.' : e.mode === 'mestre' && !e.pass ? 'O certificado sai com 80% de acerto. Você fez ' + e.acc + '%.' : e.perfect ? 'Lição perfeita, sem nenhum erro.' : e.title;
    const stats = [{ label: 'XP ganho', val: '+' + a.xp, icon: 'zap', fg: 'hsl(32 82% 40%)', bg: 'hsl(40 92% 46% / .15)', d: '.15s', ref: this.endXpRef }, { label: 'Precisão', val: a.acc + '%', icon: 'target', fg: GREEN, bg: 'hsl(150 55% 40% / .14)', d: '.23s', ref: null }, { label: 'Tempo', val: this.E.mmss(e.dur), icon: 'clock', fg: 'hsl(212 72% 48%)', bg: 'hsl(212 72% 48% / .12)', d: '.31s', ref: null }];
    return { onEndReport: () => this.openReport({ tipo: 'fase', ref: e.key || e.mode, label: 'Fase concluída', titulo: e.title }), endTitle: T[e.mode] || 'Concluído!', endSub: sub, endStats: stats, endXpRef: this.endXpRef, endPerfect: e.perfect && e.mode !== 'placement' && e.mode !== 'nivelamento', endCombo: e.combo > 0, endComboT: '+' + e.combo + ' XP de combo', onEndNext: () => this.nextPost(), endIcon: e.pass ? 'trophy' : 'sprout', endIconBg: e.pass ? 'linear-gradient(145deg,#FFD66B,#FF8A3D)' : 'linear-gradient(145deg,#3DFFBE,#14B8A6)' };
  }

  vPost() {
    const it = this.state.postItem, p = this._p, E = this.E; if (!it) return {};
    const v = { postStreak: it.k === 'streak', postGoal: it.k === 'goal', postBadge: it.k === 'badge', postCert: it.k === 'cert', onPostNext: () => it.view ? this.setState({ screen: 'app', postItem: null }) : this.nextPost(), postBtn: it.view ? 'Voltar ao perfil' : 'Continuar' };
    if (v.postStreak) {
      const h = React.createElement, mon = E.monday(this.today()), tk = this.tk(), days = p.streak.days || [];
      v.rollEl = h('span', { style: { position: 'relative', display: 'inline-block', height: 72, overflow: 'hidden', verticalAlign: 'top' } },
        h('span', { key: 'o', style: { position: 'absolute', left: 0, right: 0, textAlign: 'center', animation: 'rollOut .45s .55s cubic-bezier(.16,1,.3,1) forwards' } }, it.from),
        h('span', { key: 'n', style: { display: 'inline-block', animation: 'rollIn .45s .55s cubic-bezier(.16,1,.3,1) both' } }, it.to));
      v.week = ['S', 'T', 'Q', 'Q', 'S', 'S', 'D'].map((l, i) => { const d = new Date(mon); d.setDate(d.getDate() + i); const k = E.dkey(d), on = days.indexOf(k) >= 0, today = k === tk; return { l, on, off: !on, today, bg: on ? 'hsl(28 90% 52%)' : 'transparent', fg: on ? '#fff' : MUT, bd: today ? 'hsl(28 90% 52%)' : 'hsl(0 0% 90%)', anim: today ? 'fillIn .5s .9s cubic-bezier(.34,1.56,.64,1) both' : 'none' }; });
      v.streakTitle = it.to === 1 ? 'Ofensiva iniciada!' : it.to + ' dias de ofensiva!';
      v.streakSub = it.used ? 'Usamos ' + it.used + ' congelamento para proteger sua ofensiva.' : 'Volte amanhã para continuar.';
      v.hasMilestone = !!it.milestone; v.milestoneT = it.milestone ? 'Marco de ' + it.milestone.d + ' dias: +' + it.milestone.t + ' Takitos' : '';
    }
    if (v.postGoal) { v.goalT = 'Meta diária batida!'; v.goalS = it.goal + ' XP hoje. É assim que o hábito se forma.'; }
    if (v.postBadge) { v.bNome = it.b.nome; v.bSub = it.b.sub; v.bIcon = it.b.icon; v.bG = it.b.g; }
    if (v.postCert) { const c = it.c; v.cNome = c.nome || p.name; v.cTrilha = c.trilha; v.cData = c.data; v.onShare = () => this.shareCert(c); v.onPrintCert = () => this.viewCert(c, it.view ? null : 'post'); }
    return v;
  }
  openPop(key, btn, hasSkip) {
    const c = this.pathRef.current; if (!c || !btn) return this.setState({ popNode: key, popUp: false });
    const NEED = (hasSkip ? 262 : 206) + 12, BAR = 84, TOP = 92;
    const cr = c.getBoundingClientRect(), br = btn.getBoundingClientRect();
    const below = cr.bottom - BAR - br.bottom, above = br.top - cr.top - TOP;
    const canDown = c.scrollHeight - c.clientHeight - c.scrollTop, canUp = c.scrollTop;
    let up = false, dy = 0;
    if (below >= NEED) up = false;
    else if (below + canDown >= NEED) dy = NEED - below;
    else if (above >= NEED) up = true;
    else if (above + canUp >= NEED) { up = true; dy = -(NEED - above); }
    else { up = above > below; }
    this.setState({ popNode: key, popUp: up });
    if (dy) c.scrollBy({ top: dy, behavior: 'smooth' });
  }

  // ---------- feedback ----------
  openReport(ctx) {
    const cat = ctx.tipo === 'questao' ? 'incorreta' : ctx.tipo === 'fase' ? 'dificuldade' : 'bug';
    this.setState({ rep: { ctx, cat, text: '', files: [], sending: false, done: null, err: '' }, popNode: null });
  }
  repSet(patch) { this.setState(s => ({ rep: Object.assign({}, s.rep, patch) })); }
  addRepFiles(list) {
    [].slice.call(list || []).forEach(f => {
      const id = Math.random().toString(36).slice(2), base = { id, nome: f.name, tamanho: f.size, tipo: f.type || '', thumb: null };
      this.setState(s => ({ rep: Object.assign({}, s.rep, { files: s.rep.files.concat([base]) }) }));
      if (!/^image\//.test(f.type)) return;
      const rd = new FileReader();
      rd.onload = () => { const img = new Image(); img.onload = () => { const k = Math.min(1, 240 / Math.max(img.width, img.height)), cv = document.createElement('canvas'); cv.width = Math.round(img.width * k); cv.height = Math.round(img.height * k); cv.getContext('2d').drawImage(img, 0, 0, cv.width, cv.height); const t = cv.toDataURL('image/jpeg', .72); const k2 = Math.min(1, 1100 / Math.max(img.width, img.height)), cv2 = document.createElement('canvas'); cv2.width = Math.round(img.width * k2); cv2.height = Math.round(img.height * k2); cv2.getContext('2d').drawImage(img, 0, 0, cv2.width, cv2.height); const full = cv2.toDataURL('image/jpeg', .8); this.setState(s => s.rep ? ({ rep: Object.assign({}, s.rep, { files: s.rep.files.map(x => x.id === id ? Object.assign({}, x, { thumb: t, full }) : x) }) }) : null); }; img.src = rd.result; };
      rd.readAsDataURL(f);
    });
  }
  sendReport() {
    const r = this.state.rep, p = this._p; if (!r || r.sending) return;
    if (!r.text.trim() && !r.files.length) return this.repSet({ err: 'Escreva o feedback ou adicione um anexo.' });
    const entry = { id: window.MiseFeedback.newId(), createdAt: new Date().toISOString(), categoria: r.cat, texto: r.text, ctx: r.ctx,
      anexos: r.files.map(f => ({ nome: f.nome, tamanho: f.tamanho, tipo: f.tipo, thumb: f.thumb, full: f.full || null })),
      user: { email: p.session ? p.session.email : null, nome: p.name, equipe: p.team, persona: p.persona }, app: { tela: this.state.screen + (this.state.sub ? '/' + this.state.sub : '/' + this.state.tab), versao: 'app-1.1' } };
    this.repSet({ sending: true, err: '' });
    window.MiseFeedback.send(entry, p.offlineSim).then(saved => { this.repSet({ sending: false, done: saved }); this.setState({ repTick: Date.now() }); });
  }
  flushReports() { if (!window.MiseFeedback) return; window.MiseFeedback.flush(this._p && this._p.offlineSim).then(n => { if (n) { this.toast(n + (n === 1 ? ' feedback pendente enviado' : ' feedbacks pendentes enviados'), 'cloud-upload'); this.setState({ repTick: Date.now() }); } }); }
  vReport() {
    const r = this.state.rep; if (!r) return { repOpen: false };
    const CATS = [['bug', 'Bug', 'bug'], ['dificuldade', 'Dificuldade', 'circle-help'], ['incorreta', 'Informação incorreta', 'triangle-alert'], ['outro', 'Outros', 'message-square']];
    const kb = n => n < 1024 ? n + ' B' : n < 1048576 ? Math.round(n / 1024) + ' KB' : (n / 1048576).toFixed(1) + ' MB';
    const ICON = { questao: 'circle-help', fase: 'map-pin', geral: 'message-square-text', tela: 'smartphone' };
    const d = r.done, n = r.text.length;
    return { repOpen: true, repForm: !d, repDone: !!d, repCtxIcon: ICON[r.ctx.tipo] || 'message-square-text', repCtxLabel: r.ctx.label, repCtxTitle: r.ctx.titulo, repHasCtxTitle: !!r.ctx.titulo,
      repCats: CATS.map(([id, t, icon]) => ({ t, icon, bd: r.cat === id ? RED : BD, bg2: r.cat === id ? REDT2 : '#fff', fg2: r.cat === id ? RED : INK, bg: r.cat === id ? '#fff' : 'transparent', fg: r.cat === id ? INK : MUT, sh: r.cat === id ? '0 1px 2px rgba(0,0,0,.08)' : 'none', onClick: () => this.repSet({ cat: id }) })),
      repText: r.text, onRepText: e => this.repSet({ text: e.target.value, err: '' }), repCount: n ? n.toLocaleString('pt-BR') + (n === 1 ? ' caractere' : ' caracteres') : '',
      repFileRef: this.repFileRef, onRepPick: () => this.repFileRef.current && this.repFileRef.current.click(), onRepFiles: e => { this.addRepFiles(e.target.files); e.target.value = ''; },
      repFiles: r.files.map(f => ({ nome: f.nome, size: kb(f.tamanho), hasThumb: !!f.thumb, noThumb: !f.thumb, thumb: f.thumb || '', icon: /pdf/.test(f.tipo) ? 'file-text' : /video/.test(f.tipo) ? 'file-video' : /image/.test(f.tipo) ? 'image' : 'paperclip', onRemove: () => this.repSet({ files: this.state.rep.files.filter(x => x.id !== f.id) }) })),
      repHasFiles: r.files.length > 0, repFileCount: r.files.length + (r.files.length === 1 ? ' anexo' : ' anexos'),
      repHasErr: !!r.err, repErr: r.err, repSending: r.sending, repIdle: !r.sending, onRepSend: () => this.sendReport(), onRepClose: () => { if (!r.sending) this.setState({ rep: null }); },
      repDoneId: d ? d.id : '', repSynced: !!(d && d.status === 'enviado'), repPending: !!(d && d.status !== 'enviado'), onRepAnother: () => this.openReport(r.ctx) };
  }
  vReportView() {
    const s = this.state, f = (window.MiseFeedback ? window.MiseFeedback.list() : []).find(x => x.id === s.repViewId);
    if (!f) return { rvNone: true, rvSome: false };
    const CAT = { bug: ['Bug', 'bug'], dificuldade: ['Dificuldade', 'circle-help'], incorreta: ['Informação incorreta', 'triangle-alert'], conteudo: ['Informação incorreta', 'triangle-alert'], sugestao: ['Outros', 'message-square'], outro: ['Outros', 'message-square'] }[f.categoria] || ['Outros', 'message-square'];
    const kb = n => n < 1024 ? n + ' B' : n < 1048576 ? Math.round(n / 1024) + ' KB' : (n / 1048576).toFixed(1) + ' MB';
    const ICON = { questao: 'circle-help', fase: 'map-pin', geral: 'message-square-text' };
    const imgs = f.anexos.filter(a => a.thumb || a.full), files = f.anexos.filter(a => !(a.thumb || a.full));
    const lightIdx = s.repLight, light = lightIdx != null ? imgs[lightIdx] : null;
    const dt = new Date(f.createdAt), meta = [['Protocolo', f.id], ['Enviado em', dt.toLocaleString('pt-BR', { day: '2-digit', month: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit' })], ['Tela', f.app && f.app.tela ? f.app.tela : '—']];
    if (f.ctx.trilha) meta.push(['Trilha', f.ctx.trilha]);
    if (f.ctx.unidade) meta.push(['Unidade', f.ctx.unidade]);
    return { rvNone: false, rvSome: true, rvCat: CAT[0], rvCatIcon: CAT[1], rvOk: f.status === 'enviado', rvPend: f.status !== 'enviado', rvCtxIcon: ICON[f.ctx.tipo] || 'message-square-text', rvCtxLabel: f.ctx.label, rvCtxTitle: f.ctx.titulo || '', rvHasCtxTitle: !!f.ctx.titulo,
      rvText: f.texto || '', rvHasText: !!(f.texto || '').trim(), rvNoText: !(f.texto || '').trim(), rvLen: (f.texto || '').length.toLocaleString('pt-BR') + ' caracteres',
      rvImgs: imgs.map((a, i) => ({ src: a.full || a.thumb, nome: a.nome, onOpen: () => this.setState({ repLight: i }) })), rvHasImgs: imgs.length > 0,
      rvFiles: files.map(a => ({ nome: a.nome, size: kb(a.tamanho), icon: /pdf/.test(a.tipo) ? 'file-text' : /video/.test(a.tipo) ? 'file-video' : 'paperclip' })), rvHasFiles: files.length > 0,
      rvAnexosT: f.anexos.length ? f.anexos.length + (f.anexos.length === 1 ? ' anexo' : ' anexos') : '', rvHasAnexos: f.anexos.length > 0,
      rvMeta: meta.map(([k, v]) => ({ k, v })),
      rvLight: !!light, rvLightSrc: light ? (light.full || light.thumb) : '', rvLightNome: light ? light.nome : '', rvLightPos: light ? (lightIdx + 1) + ' de ' + imgs.length : '', rvLightMulti: imgs.length > 1,
      onRvLightClose: () => this.setState({ repLight: null }), onRvPrev: e => { e.stopPropagation(); this.setState({ repLight: (lightIdx - 1 + imgs.length) % imgs.length }); }, onRvNext: e => { e.stopPropagation(); this.setState({ repLight: (lightIdx + 1) % imgs.length }); },
      onRvAgain: () => this.openReport(f.ctx) };
  }
  vReports() {
    const list = (window.MiseFeedback ? window.MiseFeedback.list() : []), CAT = { bug: 'Bug', dificuldade: 'Dificuldade', incorreta: 'Informação incorreta', conteudo: 'Informação incorreta', sugestao: 'Outros', outro: 'Outros' };
    return { repList: list.map(f => ({ id: f.id, cat: CAT[f.categoria] || 'Outros', onOpen: () => this.setState({ sub: 'reportView', repViewId: f.id }), ctx: f.ctx.label + (f.ctx.titulo ? ' · ' + f.ctx.titulo : ''), texto: f.texto || '(só anexo)', data: new Date(f.createdAt).toLocaleString('pt-BR', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' }), anexos: f.anexos.length ? f.anexos.length + (f.anexos.length === 1 ? ' anexo' : ' anexos') : '', hasAnexos: f.anexos.length > 0, ok: f.status === 'enviado', pend: f.status !== 'enviado' })),
      repListEmpty: !list.length, repPendCount: list.filter(x => x.status !== 'enviado').length, onRepNew: () => this.openReport({ tipo: 'geral', label: 'Feedback geral', titulo: '' }) };
  }

  viewCert(c, from) { this.setState({ screen: 'app', sub: 'cert', certView: c, certFrom: from || null, certFull: false }); }
  vCert() {
    const s = this.state, c = s.certView || {}, nome = c.nome || this._p.name || 'Colaborador', trilha = c.trilha || '', data = c.data || '';
    let hh = 0; (nome + trilha + data).split('').forEach(ch => { hh = (hh * 31 + ch.charCodeAt(0)) >>> 0; });
    return { cvNome: nome, cvTrilha: trilha, cvData: data, cvCodigo: 'TKA-' + String(hh % 1000000).padStart(6, '0'),
      cvDesc: 'Venceu o Desafio Mestre da trilha, uma simulação cronometrada e sem dicas com as questões mais difíceis' + (c.acc ? ', com ' + c.acc + '% de acerto' : '') + '. Domínio comprovado da trilha no Mise en Place.',
      cvFull: !!s.certFull, onCvFull: () => this.setState({ certFull: true }), onCvFullClose: () => this.setState({ certFull: false }),
      onCvPrint: () => this.openCert(c), onCvShare: () => this.shareCert(c) };
  }
  openCert(c) {
    this.setState({ certView: c }, () => setTimeout(() => { try { window.print(); } catch (x) {} }, 350));
  }
  shareCert(c) {
    const cv = document.createElement('canvas'); cv.width = 1200; cv.height = 800; const x = cv.getContext('2d');
    x.fillStyle = '#ffffff'; x.fillRect(0, 0, 1200, 800); x.fillStyle = '#df1c0d'; x.fillRect(0, 0, 1200, 14); x.fillRect(0, 786, 1200, 14);
    x.strokeStyle = 'hsl(0,0%,90%)'; x.lineWidth = 2; x.strokeRect(40, 40, 1120, 720);
    x.fillStyle = '#df1c0d'; x.font = '700 22px Poppins, sans-serif'; x.fillText('TAKEATHUB ACADEMY · CERTIFICADO', 90, 130);
    x.fillStyle = '#212121'; x.font = '800 64px Poppins, sans-serif'; x.fillText(c.nome || this._p.name, 90, 300);
    x.fillStyle = '#757575'; x.font = '400 28px Poppins, sans-serif'; x.fillText('concluiu o Desafio Mestre da trilha', 90, 370);
    x.fillStyle = '#212121'; x.font = '700 40px Poppins, sans-serif'; x.fillText(c.trilha, 90, 430);
    x.fillStyle = '#757575'; x.font = '400 24px Poppins, sans-serif'; x.fillText('Emitido em ' + c.data, 90, 680);
    const img = new Image(); img.onload = () => { x.drawImage(img, 980, 560, 130, 130); dl(); }; img.onerror = dl; img.src = (window.MISE_IMG && window.MISE_IMG['assets/mise-book.png']) || './assets/mise-book.png';
    function dl() { cv.toBlob(b => { const a = document.createElement('a'); a.href = URL.createObjectURL(b); a.download = 'certificado-takeathub-academy.png'; a.click(); }); }
    this.toast('Imagem do certificado gerada', 'share-2');
  }

  vFlash() {
    const f = this.state.flash; if (!f) return {};
    const left = Math.max(0, (f.end - this.state.now) / 1000);
    const mk = (side, val) => { const used = side === 'l' ? !!f.mL[val] : Object.values(f.mL).indexOf(val) >= 0, sel = side === 'l' ? f.selL === val : f.selR === val, bad = f.bad && (side === 'l' ? f.bad.l : f.bad.r) === val; return { text: val, onClick: () => this.tapFlash(side, val), bd: sel || bad ? RED : BD, bg: sel ? REDT2 : bad ? REDT : '#fff', fg: sel || bad ? RED : INK, anim: used ? 'pairOut .45s cubic-bezier(.16,1,.3,1) forwards' : bad ? 'shake .3s ease' : 'none', pe: used ? 'none' : 'auto' }; };
    return { flashPlaying: !f.done, flashDone: f.done, flashLeft: Math.ceil(left) + 's', flashW: (left / 60 * 100) + '%', flashScore: f.score, flL: f.left.map(x => mk('l', x)), flR: f.right.map(x => mk('r', x)),
      flashRec: f.rec, flashRecT: 'Recorde pessoal: ' + this._p.flashRecord, flashXp: '+' + (f.xp || 0) + ' XP', onFlashAgain: () => this.startFlash(), onFlashExit: () => this.goApp({ tab: 'practice' }), onFlashQuit: () => this.setState({ screen: 'app', flash: null }) };
  }

  vOverlays() {
    const s = this.state, p = this._p, E = this.E, C = this.C, v = {};
    v.tempOpen = !!s.temp; if (s.temp) Object.assign(v, { tempForm: s.temp.step === 'form', tempSent: s.temp.step === 'sent', tempLoading: !!s.temp.loading, tempIdle: !s.temp.loading, hasTempErr: !!s.temp.err, tempErr: s.temp.err || '', tempNome: s.temp.nome || '', tempMasc: s.temp.masc || '', tempPwd: s.temp.pwd || '', onTempGen: e => this.genTemp(e), onTempClose: () => !s.temp.loading && this.setState({ temp: null }), onTempLogin: () => this.setState({ temp: null, lg: Object.assign({}, s.lg, { pwd: '' }) }), stop: e => e.stopPropagation(), tempEmail: s.lg.email, onTempEmail: e => this.setState({ lg: Object.assign({}, s.lg, { email: e.target.value }) }) });
    v.firstOpen = !!s.first; if (s.first) { const f = s.first, set = k => e => this.setState({ first: Object.assign({}, this.state.first, { [k]: e.target.value, err: '' }) }); Object.assign(v, { fPwd: f.pwd, fPwd2: f.pwd2, fTeam: f.team, fBirth: f.birth, onFPwd: set('pwd'), onFPwd2: set('pwd2'), onFTeam: set('team'), onFBirth: set('birth'), fTeamDD: this.dd('fteam', f.team, C.TEAMS.map(t => ({ t, sel: f.team === t, onPick: () => this.setState({ first: Object.assign({}, this.state.first, { team: t }) }) }))),
        onFBirthMask: e => { const d = e.target.value.replace(/\D/g, '').slice(0, 8); const v = d.length > 4 ? d.slice(0, 2) + '/' + d.slice(2, 4) + '/' + d.slice(4) : d.length > 2 ? d.slice(0, 2) + '/' + d.slice(2) : d; this.setState({ first: Object.assign({}, this.state.first, { birth: v, err: '' }) }); }, hasFErr: !!f.err, fErr: f.err, onFirstSave: () => this.saveFirst(), fEmail: f.email }); }
    v.sheetOpen = !!s.sheet; v.onSheetClose = () => this.setState({ sheet: null });
    v.sheetTracks = s.sheet === 'tracks'; v.sheetStreak = s.sheet === 'streak'; v.sheetCoins = s.sheet === 'coins'; v.sheetUnit = s.sheet === 'unit';
    v.sheetCrowd = s.sheet === 'crowd' && !!s.crowd;
    if (v.sheetCrowd) Object.assign(v, { crowdTitle: s.crowd.title, crowdSub: s.crowd.list.length + (s.crowd.list.length === 1 ? ' pessoa está nesta fase' : ' pessoas estão nesta fase'),
      crowdList: s.crowd.list.map(m => ({ nome: m.me ? m.nome + ' (você)' : m.nome, team: m.team, av: this.E.av(m.nome, m.mold), bg: m.me ? 'hsl(6 91% 47% / .06)' : '#fff', bd: m.me ? 'hsl(6 91% 47% / .35)' : BD })) });
    if (v.sheetTracks) {
      const order = (C.PERSONAS.find(x => x.id === p.persona) || C.PERSONAS[0]).order, list = this.trackList();
      // Segunda tela: trilhas Operacionais × Dev (só para quem pode ver a Dev).
      const modo = s.trkModo || (p.activeTrack === 'DEV' ? 'dev' : 'op'), comDev = this.podeDev() && (this.temDev() || this.editaDev());
      const opList = list.filter(t => !t.dev);
      const sorted = modo === 'dev' && comDev ? list.filter(t => t.dev) : [opList[0]].concat(order.map(id => opList.find(t => t.id === id)).filter(Boolean)).concat(opList.filter(t => t.id !== 'ATD' && order.indexOf(t.id) < 0));
      const aba = (id, t) => ({ t, bg: modo === id ? '#fff' : 'transparent', fg: modo === id ? INK : MUT, sh: modo === id ? '0 1px 2px rgba(0,0,0,.08)' : 'none', onClick: () => this.setState({ trkModo: id }) });
      Object.assign(v, { trkComDev: comDev, trkModos: [aba('op', 'Operacional'), aba('dev', 'Dev')], trkDev: modo === 'dev' && comDev, trkOp: !(modo === 'dev' && comDev),
        trkDevVazia: modo === 'dev' && comDev && !this.temDev(), trkEditaDev: modo === 'dev' && this.editaDev(), onEditDev: () => this.setState({ sheet: null, sub: 'devEdit', devEd: { aberto: null, form: null, pedido: '', ia: null } }) });
      const recId = (order.find(id => E.trackPct(C, this.bank, this.atd, p, id) < 100)) || null;
      v.trackRows = sorted.map(t => { const pc = E.trackPct(C, this.bank, this.atd, p, t.id), sel = p.activeTrack === t.id, nU = this.units(t.id).length; return { nome: t.nome, icon: t.icon, pct: pc + '%', sub: t.id === 'ATD' ? (nU ? nU + ' unidades · personalizável pelo líder' : 'Aguardando o líder montar') : t.dev ? nU + ' módulos · montada pelo líder de Tecnologia' : nU + ' unidades', rec: t.id === recId, sel, bd: sel ? RED : BD, bg: sel ? REDT2 : '#fff', onClick: () => { this.upd(q => { q.activeTrack = t.id; }); this.setState({ sheet: null, bannerUnit: 0, popNode: null }, () => this.scrollToCurrent(true)); } }; });
    }
    if (v.sheetStreak) {
      const mon = E.monday(this.today()), tk = this.tk(), days = p.streak.days || [];
      v.sWeek = ['S', 'T', 'Q', 'Q', 'S', 'S', 'D'].map((l, i) => { const d = new Date(mon); d.setDate(d.getDate() + i); const k = E.dkey(d), on = days.indexOf(k) >= 0; return { l, n: d.getDate(), bg: on ? 'hsl(28 90% 52%)' : 'hsl(0 0% 95%)', fg: on ? '#fff' : MUT, bd: k === tk ? 'hsl(28 90% 52%)' : 'transparent' }; });
      v.sCount = E.streakNow(p, this.today()); v.sBest = 'Recorde: ' + (p.streak.best || 0) + ' dias'; v.sFreezes = p.streak.freezes + '/2 congelamentos';
      v.sMiles = [7, 30, 100, 365].map(d => ({ t: d + ' dias', done: (p.streak.best || 0) >= d, bg: (p.streak.best || 0) >= d ? 'hsl(28 90% 52% / .14)' : 'hsl(0 0% 95%)', fg: (p.streak.best || 0) >= d ? 'hsl(28 80% 40%)' : MUT }));
      v.sToday = this.today().toLocaleDateString('pt-BR', { weekday: 'long', day: '2-digit', month: 'long' });
      v.devTools = DEV_TOOLS;
      v.onAdvanceDay2 = () => { if (!DEV_TOOLS) return; this.upd(q => { q.dayOffset++; }); this.checkWeek(); this.toast('Agora é ' + this.today().toLocaleDateString('pt-BR', { weekday: 'long' }), 'calendar'); };
    }
    if (v.sheetCoins) {
      const k = this.tk(), dr = p.day[k] || { claimed: {} }, ms = E.missionsFor(C, k);
      v.cSaldo = p.takitos; v.cMissions = ms.map(m => ({ t: m.t, pct: Math.round(Math.min(m.meta, dr[m.m] || 0) / m.meta * 100) + '%', prog: Math.min(m.meta, dr[m.m] || 0) + '/' + m.meta, done: !!(dr.claimed && dr.claimed[m.k]), r: '+' + C.MISSION_REWARD }));
      v.cDone = ms.filter(m => dr.claimed && dr.claimed[m.k]).length + '/3 concluídas'; v.onCLoja = () => this.setState({ sheet: null, screen: 'app', sub: 'loja' }); v.onCAll = () => this.setState({ sheet: null, screen: 'app', tab: 'missions', sub: null });
    }
    if (v.sheetUnit) {
      const u = this.units()[s.bannerUnit] || this.units()[0];
      v.uTitle = u ? u.title : ''; v.uRegra = u && u.regra ? u.regra : ''; v.uHasRegra = !!(u && u.regra); v.uIsAtd = p.activeTrack === 'ATD';
      v.uLicoes = u ? u.nodes.filter(n => n.type === 'licao').map(n => ({ t: n.title, done: !!p.done[n.key] })) : [];
      v.uQs = u ? u.qs.length + ' questões nesta unidade' : '';
      const dm = u ? this.desempUnidades().find(x => x.unidade === u.title && x.tid === p.activeTrack) : null;
      v.uScore = dm ? 'Seu domínio neste módulo: ' + Math.round(dm.score * 100) + '%' : ''; v.uHasScore = !!dm;
    }
    v.chestOpen = !!s.chest; if (s.chest) { const rw = s.chest.reward; Object.assign(v, { chestTitle: rw.k === 'takitos' ? '+' + rw.n + ' Takitos' : rw.k === 'freeze' ? 'Congelamento de ofensiva' : 'XP em dobro por 15 min', chestSub: rw.k === 'takitos' ? 'Use na Loja do Hub.' : rw.k === 'freeze' ? 'Protege sua ofensiva num dia sem lição.' : 'Todo XP ganho nos próximos 15 minutos vale o dobro.', chestCoin: rw.k === 'takitos', chestIcon: rw.k === 'freeze' ? 'snowflake' : 'zap', chestNotCoin: rw.k !== 'takitos', onCollect: () => this.collectChest() }); }
    Object.assign(v, this.vBuy(), this.vReport());
    v.wrOpen = !!s.weekResult; if (s.weekResult) { const w = s.weekResult, L = C.LEAGUES; Object.assign(v, { wrFromG: L[w.from].g, wrToG: L[w.to].g, wrFromIcon: L[w.from].icon || 'trophy', wrToIcon: L[w.to].icon || 'trophy', wrChanged: w.from !== w.to, wrSame: w.from === w.to, wrTitle: w.res === 'up' ? 'Você subiu para a Liga ' + L[w.to].nome + '!' : w.res === 'down' ? 'Você caiu para a Liga ' + L[w.to].nome : 'Você se manteve na Liga ' + L[w.to].nome, wrText: 'Terminou a semana em ' + w.rank + 'º lugar.' + (w.res === 'up' ? ' +' + C.LEAGUE_RULES.premioPromocao + ' Takitos pela promoção.' : ''), onWrClose: () => { const up = w.res === 'up'; this.setState({ weekResult: null }); if (up) setTimeout(() => this.fly('coin', this.frameCenter(), 5), 60); } }); }
    v.exitAsk = s.exitAsk && s.screen === 'lesson'; v.onExitCancel = () => this.setState({ exitAsk: false }); v.onExitConfirm = () => this.setState({ exitAsk: false, screen: 'app', lesson: null, ex: null, fb: null });
    v.resetAsk = s.resetAsk; v.onResetCancel = () => this.setState({ resetAsk: false });
    v.onResetConfirm = () => { const d = this.defaults(), keep = { session: p.session, uid: p.uid, phone: p.phone, photo: p.photo, takitos: p.takitos, equipped: p.equipped, persona: p.persona, activeTrack: p.activeTrack, onboarded: p.onboarded, tkFila: p.tkFila || [], fsrsFila: p.fsrsFila, remembered: p.remembered, name: p.name, team: p.team, cargo: p.cargo, role: p.role }; this.E._uc = {}; this.save(Object.assign(d, keep)); this.setState({ resetAsk: false, sub: null, tab: 'learn' }); this.irDepoisDoLogin(); };
    return v;
  }
}
