// Integração com o TakeatHub (Supabase do HubProduto): login, perfil e feedback.
// A chave abaixo é a publishable/anon key — pública por definição (a mesma do front do Hub);
// a proteção dos dados é feita pelo RLS no banco.
import { createClient } from '@supabase/supabase-js';

const URL = import.meta.env.VITE_SUPABASE_URL || 'https://ggorwvqcqgzvcdzcmbov.supabase.co';
const KEY = import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY || 'sb_publishable_nPZK3oSdjl4aqXG9ltBARA_1gVYbeKu';

export const supabase = createClient(URL, KEY, {
  auth: { persistSession: true, autoRefreshToken: true, storageKey: 'mise-auth' },
});

// Mesmas regras de senha do Hub (src/lib/password-strength.ts).
export const REGRAS_SENHA = [
  ['Pelo menos 8 caracteres', s => s.length >= 8],
  ['letras maiúsculas e minúsculas', s => /[a-z]/.test(s) && /[A-Z]/.test(s)],
  ['um número', s => /\d/.test(s)],
  ['um caractere especial (!@#$…)', s => /[^A-Za-z0-9]/.test(s)],
];
export function erroSenha(s) {
  const falta = REGRAS_SENHA.filter(([, ok]) => !ok(s)).map(([t]) => t);
  return falta.length ? 'A senha precisa ter: ' + falta.join(', ') + '.' : '';
}
export function traduzirErroSenha(m) {
  const raw = (m || '').toLowerCase();
  if (raw.includes('weak') || raw.includes('pwned') || raw.includes('easy to guess')) return 'Essa senha apareceu em vazamentos conhecidos. Escolha uma senha única.';
  if (raw.includes('different from the old password')) return 'Escolha uma senha diferente da senha temporária.';
  return m || 'Não foi possível salvar a senha.';
}

// Corpo do erro de uma edge function (em não-2xx o supabase-js põe o corpo em error.context).
async function corpo(data, error) {
  if (data) return data;
  try { if (error && error.context && error.context.json) return await error.context.json(); } catch (e) {}
  return null;
}

export async function entrar(email, password) {
  const { data, error } = await supabase.auth.signInWithPassword({ email, password });
  if (error) {
    const offline = !navigator.onLine || /fetch|network/i.test(error.message || '');
    return { erro: offline ? 'Sem conexão. Conecte-se à internet para entrar.' : 'E-mail ou senha incorretos.' };
  }
  const uid = data.user.id;
  const [{ data: prof }, { data: roles }, { data: lid }] = await Promise.all([
    supabase.from('profiles').select('full_name, team, cargo, telefone, avatar_url, birth_date, force_password_change, onboarding_done, senha_temporaria_expira_em, moldura:moldura_id(asset)').eq('id', uid).maybeSingle(),
    supabase.from('user_roles').select('role').eq('user_id', uid),
    supabase.from('documentos_time_membros').select('team, cargo').eq('user_id', uid).eq('cargo', 'lider'),
  ]);
  if (prof && prof.senha_temporaria_expira_em && new Date(prof.senha_temporaria_expira_em).getTime() < Date.now()) {
    await supabase.auth.signOut();
    return { erro: 'Senha temporária expirada. Gere uma nova em "Esqueci minha senha".' };
  }
  const rs = (roles || []).map(r => r.role);
  const role = rs.includes('master') ? 'master' : rs.includes('admin') ? 'admin' : (lid && lid.length) ? 'lider' : 'analista';
  const perfil = prof || {};
  perfil.foto = perfil.avatar_url || (data.user.user_metadata && data.user.user_metadata.avatar_url) || null;
  perfil.molduraAsset = (perfil.moldura && perfil.moldura.asset) || null;
  return { user: data.user, perfil, role };
}

// Atualiza foto/moldura/equipe a cada abertura (quem trocou no Hub vê no Mise).
export async function perfilAtual() {
  const { data: s } = await supabase.auth.getSession();
  const user = s && s.session && s.session.user;
  if (!user) return null;
  const { data: prof } = await supabase.from('profiles').select('full_name, team, cargo, telefone, avatar_url, moldura:moldura_id(asset)').eq('id', user.id).maybeSingle();
  if (!prof) return null;
  return { nome: prof.full_name, team: prof.team, cargo: prof.cargo, telefone: prof.telefone, foto: prof.avatar_url || (user.user_metadata && user.user_metadata.avatar_url) || null, molduraAsset: (prof.moldura && prof.moldura.asset) || null };
}

export async function salvarPrimeiroAcesso(uid, { pwd, team, birthIso, teamDefinida }) {
  const { error: e1 } = await supabase.auth.updateUser({ password: pwd });
  if (e1) return { erro: traduzirErroSenha(e1.message) };
  const { error: e2 } = await supabase.from('profiles').update(Object.assign(teamDefinida ? {} : { team }, { birth_date: birthIso, force_password_change: false, senha_temporaria_expira_em: null })).eq('id', uid);
  if (e2) return { erro: 'Senha salva, mas não deu para salvar o perfil: ' + e2.message };
  return { ok: true };
}

export async function gerarSenhaTemporaria(email) {
  const { data, error } = await supabase.functions.invoke('reset-password', { body: { self_service: true, email } });
  const d = await corpo(data, error);
  if (error || !d || !d.ok) {
    const m = d && d.error;
    return { erro: m === 'nao_encontrado' ? 'E-mail não encontrado.' : m === 'sem_telefone' ? 'Não há WhatsApp cadastrado nesse perfil. Procure um administrador.' : m === 'email_invalido' ? 'Digite um e-mail válido.' : m === 'whatsapp_falhou' ? 'Não conseguimos entregar no seu WhatsApp. Confira o número com um administrador.' : 'Não foi possível enviar agora. Tente de novo ou procure um administrador.' };
  }
  return { nome: d.nome || '', masc: d.telefone_mascarado || '' };
}

export async function sair() { try { await supabase.auth.signOut(); } catch (e) {} }

// ---------- feedback: tabela mise_feedback + bucket privado mise-feedback ----------
function dataUrlParaBlob(u) {
  const [h, b] = u.split(','); const mime = (h.match(/:(.*?);/) || [])[1] || 'image/jpeg';
  const bin = atob(b); const arr = new Uint8Array(bin.length); for (let i = 0; i < bin.length; i++) arr[i] = bin.charCodeAt(i);
  return new Blob([arr], { type: mime });
}
export async function enviarFeedback(entry) {
  const { data: s } = await supabase.auth.getSession();
  const user = s && s.session && s.session.user;
  if (!user) return { ok: false, motivo: 'sem_sessao' };
  const anexos = [];
  for (const [i, a] of (entry.anexos || []).entries()) {
    const src = a.full || a.thumb;
    if (!src) { anexos.push({ nome: a.nome, tipo: a.tipo, tamanho: a.tamanho, path: null }); continue; }
    const path = user.id + '/' + entry.id + '-' + i + '.jpg';
    const { error } = await supabase.storage.from('mise-feedback').upload(path, dataUrlParaBlob(src), { upsert: true, contentType: 'image/jpeg' });
    anexos.push({ nome: a.nome, tipo: a.tipo, tamanho: a.tamanho, path: error ? null : path });
  }
  const { error } = await supabase.from('mise_feedback').upsert({
    id: entry.id, user_id: user.id, email: user.email, nome: entry.user && entry.user.nome, equipe: entry.user && entry.user.equipe,
    persona: entry.user && entry.user.persona, categoria: entry.categoria, texto: entry.texto || '', contexto: entry.ctx || {},
    tela: entry.app && entry.app.tela, versao: entry.app && entry.app.versao, anexos, criado_em: entry.createdAt,
  }, { onConflict: 'id', ignoreDuplicates: true });
  return error ? { ok: false, motivo: error.message } : { ok: true, at: Date.now() };
}

window.MiseHub = { supabase, enviarFeedback };

// ---------- progresso na nuvem (mise_progresso) + Takitos do Hub + ranking real ----------
export async function estadoNuvem() {
  const { data, error } = await supabase.rpc('mise_estado');
  if (error) throw error;
  return data; // { dados, atualizado_em, saldo }
}
export async function salvarNuvem(r) {
  const { error } = await supabase.rpc('mise_salvar', { p_dados: r.dados, p_xp_total: r.xpTotal, p_liga_semana: r.semana, p_liga_xp: r.ligaXp, p_liga_idx: r.ligaIdx, p_posicoes: r.posicoes, p_resumo: r.resumo || {} });
  if (error) throw error;
  return true;
}
export async function movimentarTakitos(delta, ref) {
  const { data, error } = await supabase.rpc('mise_takitos', { p_delta: delta, p_ref: ref });
  if (error) throw error;
  return data; // { ok, saldo, erro? }
}
export async function rankingSemana(semana) {
  const { data, error } = await supabase.rpc('mise_ranking', { p_semana: semana });
  if (error) throw error;
  return data || [];
}

// ---------- perguntas (mise_questoes) ----------
// As perguntas vivem no banco e são mantidas em dia com a wiki pela edge `mise-auto`.
// Lê só as publicadas, na ordem da trilha (a ordem preserva o mapa de fases). Paginado: o
// PostgREST corta em 1000 linhas sem avisar.
const CAMPOS_Q = 'id, trilha_id, trilha, unidade, licao, tipo, dificuldade, enunciado, opcoes, resposta, explicacao, fonte, ordem, modulo_chave, extra_de, novidade_desde';
export async function questoesNuvem() {
  const todas = [];
  for (let de = 0; ; de += 1000) {
    const { data, error } = await supabase.from('mise_questoes').select(CAMPOS_Q).eq('status', 'publicada')
      .order('trilha_id').order('ordem').range(de, de + 999);
    if (error) throw error;
    todas.push(...(data || []));
    if (!data || data.length < 1000) break;
  }
  return todas.map(q => ({
    id: q.id, trilha: q.trilha, unidade: q.unidade, licao: q.licao, tipo: q.tipo, dificuldade: q.dificuldade,
    enunciado: q.enunciado, opcoes: q.opcoes, resposta: q.resposta, explicacao: q.explicacao, fonte: q.fonte,
    modulo_chave: q.modulo_chave || null, extra_de: q.extra_de || null, novidade: !!q.novidade_desde, trilha_id: q.trilha_id,
  }));
}
