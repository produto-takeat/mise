// Revisão do dia com FSRS (o algoritmo do Anki, biblioteca ts-fsrs 6.0.0, MIT).
// Para cada pergunta respondida, o FSRS estima a chance de a pessoa ainda lembrar e marca a próxima revisão para quando
// ela cair a 90%. Errou = "esqueci" (Again); acertou = "lembrei" (Good). Só a 1ª resposta da pergunta no dia conta.
//
// Experimento (combinado com o Produto em 22/11/2026): as perguntas de cada pessoa se dividem em duas metades fixas,
// decididas pelo servidor (mise_fsrs_status devolve a lista da metade "controle"). Só a outra metade entra na revisão.
// Em cada Revisão do dia, 2 perguntas de checagem são sorteadas das duas metades entre as vistas pela 1ª vez há 14 dias
// ou mais — o acerto da checagem por metade mostra se a revisão faz lembrar mais.
//
// Estado no progresso (sincronizado no mise_progresso como o resto): p.fsrs[questaoId] =
//   { s: estabilidade, d: dificuldade, e: estado, n: repetições, l: lapsos, u: última revisão (ms), v: vence (ms), f: 1ª resposta (ms) }
// Fila de envio (só no aparelho, como a dos Takitos): p.fsrsFila = { r: [respostas], c: { id: cartão }, s: { id: sessão } }.
import { fsrs, generatorParameters, createEmptyCard, Rating } from 'ts-fsrs';

const DIA = 864e5;
let motor = null, retencaoAtual = null;
function m(retencao) {
  const r = retencao || 0.9;
  if (!motor || retencaoAtual !== r) {
    motor = fsrs(generatorParameters({ request_retention: r, enable_short_term: false, enable_fuzz: true, maximum_interval: 365 }));
    retencaoAtual = r;
  }
  return motor;
}

// Cartão do ts-fsrs <-> forma curta guardada no progresso.
function paraCard(c) {
  const card = createEmptyCard(new Date(c.u));
  return Object.assign(card, {
    due: new Date(c.v), stability: c.s, difficulty: c.d, state: c.e, reps: c.n, lapses: c.l,
    last_review: new Date(c.u), elapsed_days: 0, scheduled_days: Math.max(0, Math.round((c.v - c.u) / DIA)), learning_steps: 0,
  });
}
function deCard(card, f) {
  return { s: card.stability, d: card.difficulty, e: card.state, n: card.reps, l: card.lapses,
    u: card.last_review ? card.last_review.getTime() : Date.now(), v: card.due.getTime(), f };
}

// Chance de lembrar agora (0–1); pergunta nunca vista = null.
export function chance(c, agora, retencao) {
  if (!c) return null;
  try { const r = m(retencao).retrievability(paraCard(c), new Date(agora)); return typeof r === 'number' && isFinite(r) ? r : null; } catch (e) { return null; }
}

const mesmoDia = (a, b) => { const x = new Date(a), y = new Date(b); return x.getFullYear() === y.getFullYear() && x.getMonth() === y.getMonth() && x.getDate() === y.getDate(); };

// Aplica uma resposta. Devolve null se a pergunta já teve resposta contada hoje.
// { cartao, chancePrevista, diasDesde }
export function responder(c, acerto, agora, retencao) {
  if (c && c.u && mesmoDia(c.u, agora)) return null;
  const antes = c ? chance(c, agora, retencao) : null;
  const diasDesde = c ? Math.max(0, (agora - c.u) / DIA) : null;
  const card = c ? paraCard(c) : createEmptyCard(new Date(agora));
  const res = m(retencao).next(card, new Date(agora), acerto ? Rating.Good : Rating.Again);
  return { cartao: deCard(res.card, c && c.f ? c.f : agora), chancePrevista: antes, diasDesde };
}

// Quem já respondia antes do FSRS (meia-vida em p.hl) começa com uma revisão na data da última resposta:
// "esqueci" se a pergunta está em Meus erros, "lembrei" se não. Não mexe em quem já tem cartão.
export function iniciarDeHl(fsrsAtual, hl, errors, retencao) {
  const out = Object.assign({}, fsrsAtual || {});
  Object.keys(hl || {}).forEach(id => {
    if (out[id] || !hl[id] || !hl[id].t) return;
    const r = responder(null, !(errors && errors[id]), hl[id].t, retencao);
    if (r) out[id] = r.cartao;
  });
  return out;
}

// Monta a Revisão do dia: até cfg.por_dia perguntas da metade "revisao" que venceram (menor chance de lembrar
// primeiro) + até cfg.checagem perguntas de checagem, metade de cada metade quando dá.
// qOk(id) diz se a pergunta ainda existe no banco do aparelho. rnd = Math.random (injetável nos testes).
export function revisaoDoDia(fsrsAtual, controle, agora, cfg, qOk, rnd) {
  const r = rnd || Math.random, ret = cfg.retencao || 0.9;
  const ids = Object.keys(fsrsAtual || {}).filter(id => qOk(id));
  const hoje = id => mesmoDia(fsrsAtual[id].u, agora);
  const vencidas = ids.filter(id => !controle.has(id) && !hoje(id))
    .map(id => ({ id, ch: chance(fsrsAtual[id], agora, ret) }))
    .filter(x => fsrsAtual[x.id].v <= agora || (x.ch != null && x.ch <= ret))
    .sort((a, b) => a.ch - b.ch).slice(0, cfg.por_dia || 8).map(x => x.id);
  const limite = agora - (cfg.checagem_dias || 14) * DIA;
  const ja = new Set(vencidas);
  const elegivel = id => !ja.has(id) && !hoje(id) && fsrsAtual[id].f && fsrsAtual[id].f <= limite;
  const sortear = lista => { const a = lista.slice(); for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(r() * (i + 1)); [a[i], a[j]] = [a[j], a[i]]; } return a; };
  const comRev = sortear(ids.filter(id => elegivel(id) && !controle.has(id)));
  const semRev = sortear(ids.filter(id => elegivel(id) && controle.has(id)));
  // sempre em pares, uma de cada metade, para as duas receberem o mesmo número de checagens
  const n = cfg.checagem == null ? 2 : cfg.checagem, pares = Math.min(Math.floor(n / 2), comRev.length, semRev.length);
  const checagem = sortear(comRev.slice(0, pares).concat(semRev.slice(0, pares)));
  return { revisao: vencidas, checagem };
}

// Origem da resposta para a métrica, pelo modo da lição.
export function origemDe(modo, checagem) {
  if (checagem) return 'checagem';
  return ({ licao: 'licao', caso: 'caso', checkpoint: 'checkpoint', review: 'revisao', errors: 'erros', reforco: 'reforco', term: 'termo' })[modo] || 'outro';
}

// Modos que não entram no FSRS: avaliações com gabarito no servidor e nivelamentos.
export const FORA_DO_FSRS = ['placement', 'skip', 'mestre', 'nivelamento'];

export function uuid() {
  if (typeof crypto !== 'undefined' && crypto.randomUUID) return crypto.randomUUID();
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, ch => { const v = Math.random() * 16 | 0; return (ch === 'x' ? v : (v & 3 | 8)).toString(16); });
}

// Junta um registro na fila (respostas em ordem; cartão e sessão pelo id, o último vence).
export function enfileirar(fila, { resposta, questaoId, cartao, sessao }) {
  const f = { r: (fila && fila.r || []).slice(), c: Object.assign({}, fila && fila.c), s: Object.assign({}, fila && fila.s) };
  if (resposta) f.r.push(resposta);
  if (cartao && questaoId) f.c[questaoId] = cartao;
  if (sessao) f.s[sessao.id] = sessao;
  if (f.r.length > 2000) f.r = f.r.slice(-2000); // aparelho meses offline: guarda as mais novas
  return f;
}

// Lote para o servidor (até 300 respostas e 300 cartões por vez).
export function lote(fila) {
  const r = (fila && fila.r || []).slice(0, 300);
  const cIds = Object.keys(fila && fila.c || {}).slice(0, 300), sIds = Object.keys(fila && fila.s || {}).slice(0, 50);
  const iso = ms => (ms ? new Date(ms).toISOString() : null);
  return {
    respostas: r,
    cartoes: cIds.map(id => { const c = fila.c[id]; return { questao_id: id, estabilidade: c.s, dificuldade: c.d, estado: c.e, repeticoes: c.n, lapsos: c.l, primeira_resposta: iso(c.f), ultima_revisao: iso(c.u), proxima_revisao: iso(c.v) }; }),
    sessoes: sIds.map(id => fila.s[id]),
    tira: { r: r.map(x => x.id), c: cIds, s: sIds },
  };
}
// Tira da fila o que o servidor recebeu (comparando pelo conteúdo: o que mudou depois do envio continua na fila).
export function semEnviados(fila, enviado, lt) {
  const ids = new Set(enviado.r);
  const c = Object.assign({}, fila.c), s = Object.assign({}, fila.s);
  enviado.c.forEach((id, i) => { if (c[id] && c[id].u === Date.parse(lt.cartoes[i].ultima_revisao)) delete c[id]; });
  enviado.s.forEach((id, i) => { if (s[id] && JSON.stringify(s[id]) === JSON.stringify(lt.sessoes[i])) delete s[id]; });
  return { r: (fila.r || []).filter(x => !ids.has(x.id)), c, s };
}
export const filaVazia = f => !f || (!(f.r || []).length && !Object.keys(f.c || {}).length && !Object.keys(f.s || {}).length);
