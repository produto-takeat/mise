-- Mise · feedbacks enviados pelo app (Supabase do TakeatHub, ggorwvqcqgzvcdzcmbov).
-- Idempotente. Aplicar manualmente no SQL Editor do PROD.

create table if not exists public.mise_feedback (
  id          text primary key,                 -- id gerado no app (FB-XXXXXX), garante envio sem duplicar
  user_id     uuid not null default auth.uid() references auth.users(id) on delete cascade,
  email       text,
  nome        text,
  equipe      text,
  persona     text,
  categoria   text,                             -- incorreta | dificuldade | bug | sugestao ...
  texto       text not null default '',
  contexto    jsonb not null default '{}'::jsonb, -- questão / fase / tela de origem
  tela        text,
  versao      text,
  anexos      jsonb not null default '[]'::jsonb, -- [{nome,tipo,tamanho,path}] no bucket mise-feedback
  status      text not null default 'novo',     -- novo | em_analise | resolvido | descartado
  criado_em   timestamptz not null default now(),
  recebido_em timestamptz not null default now()
);
create index if not exists mise_feedback_criado_idx on public.mise_feedback (criado_em desc);

alter table public.mise_feedback enable row level security;

drop policy if exists "mise_feedback insere o proprio" on public.mise_feedback;
create policy "mise_feedback insere o proprio" on public.mise_feedback
  for insert to authenticated with check (user_id = auth.uid());

drop policy if exists "mise_feedback le o proprio ou admin" on public.mise_feedback;
create policy "mise_feedback le o proprio ou admin" on public.mise_feedback
  for select to authenticated using (
    user_id = auth.uid() or public.has_role(auth.uid(), 'admin') or public.has_role(auth.uid(), 'master')
  );

drop policy if exists "mise_feedback admin atualiza" on public.mise_feedback;
create policy "mise_feedback admin atualiza" on public.mise_feedback
  for update to authenticated using (public.has_role(auth.uid(), 'admin') or public.has_role(auth.uid(), 'master'));

-- Anexos (imagens) — bucket privado, pasta por usuário: {user_id}/{arquivo}
insert into storage.buckets (id, name, public) values ('mise-feedback', 'mise-feedback', false)
on conflict (id) do nothing;

drop policy if exists "mise_feedback anexos upload" on storage.objects;
create policy "mise_feedback anexos upload" on storage.objects
  for insert to authenticated with check (bucket_id = 'mise-feedback' and (storage.foldername(name))[1] = auth.uid()::text);

drop policy if exists "mise_feedback anexos upsert" on storage.objects;
create policy "mise_feedback anexos upsert" on storage.objects
  for update to authenticated using (bucket_id = 'mise-feedback' and (storage.foldername(name))[1] = auth.uid()::text);

drop policy if exists "mise_feedback anexos leitura" on storage.objects;
create policy "mise_feedback anexos leitura" on storage.objects
  for select to authenticated using (
    bucket_id = 'mise-feedback' and (
      (storage.foldername(name))[1] = auth.uid()::text
      or public.has_role(auth.uid(), 'admin') or public.has_role(auth.uid(), 'master')
    )
  );
