// Service worker do Mise: app 100% offline (cache-first para arquivos do próprio app).
const CACHE = 'mise-v8';
const CORE = ['./', './index.html', './manifest.webmanifest', './legacy/lucide.min.js', './legacy/mise-img.js', './legacy/icons.js', './legacy/engine.js', './legacy/config.js', './legacy/bank.js', './legacy/atendimento.js', './legacy/feedback.js', './assets/mise-book.png', './assets/mise-avatar.png', './assets/takeat-mark.png', './assets/itens/congelamento.svg', './assets/itens/xp-dobro.svg', './assets/intro/cabeca.webp', './assets/intro/capa-esq.webp', './assets/intro/capa-dir.webp', './assets/intro/paginas-esq.webp', './assets/intro/paginas-dir.webp', './assets/intro/patas.webp', './assets/intro/piscada.webp', './assets/intro/olhos-fechados.webp', './assets/intro/takeathub-esq.webp', './assets/intro/takeathub-dir.webp', './src/assets/takitos.png'];
// cache:'reload' fura o cache HTTP do navegador, senão a instalação pode guardar a versão velha de legacy/*.
self.addEventListener('install', e => { e.waitUntil(caches.open(CACHE).then(c => c.addAll(CORE.map(u => new Request(u, { cache: 'reload' })))).then(() => self.skipWaiting())); });
self.addEventListener('activate', e => { e.waitUntil(caches.keys().then(ks => Promise.all(ks.filter(k => k !== CACHE).map(k => caches.delete(k)))).then(() => self.clients.claim())); });
self.addEventListener('fetch', e => {
  const r = e.request;
  if (r.method !== 'GET' || new URL(r.url).origin !== location.origin) return;
  if (r.mode === 'navigate') {
    e.respondWith(fetch(r).then(res => { caches.open(CACHE).then(c => c.put('./index.html', res.clone())); return res; }).catch(() => caches.match('./index.html')));
    return;
  }
  // Arquivos com hash (assets/index-*) nunca mudam: cache-first. Os sem hash (legacy/*, imagens) saem do
  // cache na hora e são atualizados em segundo plano, para a próxima abertura já vir com a versão nova.
  const comHash = /\/assets\/[^/]+-[A-Za-z0-9_-]{8}\.(js|css)$/.test(new URL(r.url).pathname);
  const rede = () => fetch(r, { cache: 'no-cache' }).then(res => { if (res.ok) { const cp = res.clone(); caches.open(CACHE).then(c => c.put(r, cp)); } return res; });
  e.respondWith(caches.match(r).then(hit => {
    if (hit && !comHash) e.waitUntil(rede().catch(() => {}));
    return hit || rede();
  }));
});
